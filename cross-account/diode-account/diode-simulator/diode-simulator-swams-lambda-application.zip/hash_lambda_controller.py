import json
import tomorrow
import boto3
import hashlib
import os
from botocore.errorfactory import ClientError
import logging

logger = logging.getLogger()

NUM_INVOKER_THREADS = 200
REGION = "us-east-1"
LAMBDA_CALCULATOR = os.getenv("LAMBDA_CALCULATOR", None)


class Hashes:
    # simple class to hold values from multi-thread hash computation and error state
    def __init__(self, blocknum=0, value="", md5="", errornum=0, retrycount=0):
        self.blocknum = blocknum
        self.value = value
        self.md5 = md5
        self.errornum = errornum
        self.retrycount = retrycount


def lambda_handler(event, context):
    logger.setLevel(_get_logging_level_from_string(log_level=os.getenv("LOG_LEVEL")))
    logger.debug(event)
    '''
    Event looks like this:
    {
        "s3Bucket": "mybucket",
        "s3Key": "myfile.tar",
        "blocksize": "512", (can be either 128, 256, or 512)
        "algorithm": 'SHA256' (can be SHA256, SHA384, or SHA512)
    }
    '''
    # hard code the bucket and object name for testing purposes
    s3Bucket = event['s3Bucket']
    s3Key = event['s3Key']
    # passed_blocksize = int(event['blocksize'])
    hash_algorithm = event.get('algorithm', '')
    if hash_algorithm not in ['SHA256', 'SHA384', 'SHA512']:
        hash_algorithm = 'SHA256'

    try:
        # numbers below represent mapping for human ease to actual bytes e.g. 128*1024*1024,
        # 256*1024*1024, 512*1024*1024
        blocksize = {
            "128": 134217728,
            "256": 268435456,
            "512": 536870912
        }[event['blocksize']]
    except KeyError:
        logger.info("Block size must be one of: 128, 256, or 512 in MB using default value: 256")
        blocksize = 268435456  # can be 134217728 or 268435456 or 536870912

    logger.info(f"Values being used for computations: bucket={s3Bucket} "
                f"object={s3Key} blocksize={blocksize} algorithm={hash_algorithm}")
    hashes = process_hashgeneration(s3_bucket=s3Bucket, s3_key=s3Key,
                                    blocksize=blocksize, hash_algorithm=hash_algorithm)
    return hashes


def process_hashgeneration(s3_bucket="", s3_key="", blocksize=268435456, hash_algorithm="SHA256"):
    # go get the size of the S3 object
    s3_client = boto3.client("s3")
    try:
        total_bytes = s3_client.get_object(Bucket=s3_bucket, Key=s3_key)["ContentLength"]
    except ClientError as ce:
        error_text = f"Error trying to read content length of object {s3_key} exception: {ce}"
        logger.error(error_text)
        response = {
            "errnum": str('-1'),
            "errortext": error_text
        }
        return response

    # TODO: enforce max of 10,000 chunks (s3 limit)
    start_bytes = list(range(0, total_bytes, blocksize))
    stop_bytes = [min(total_bytes - 1, start_byte + (blocksize - 1)) for start_byte in start_bytes]
    # list of range tuples = [(1,(start1,stop1)), ..., (N, (start-N, stop-N))]
    # change the enumeration index to start at 1 since s3 multipart part numbers begin at 1.
    ranges = list(enumerate(list(zip(start_bytes, stop_bytes)), 1))

    """
    The following generates JSON that looks like this:
    [
        {
            'bucket': 'bucket',
            'key': 'key',
            'start_byte': '0',
            'stop_byte': '536870911',
            'block_num': '1',
            'hash_algorithm': 'SHA256'

        },
        {'bucket':
            'bucket', 'key': 'key',
            'start_byte': '536870912',
            'stop_byte': '1073741823',
            'block_num': '2',
            'hash_algorithm': 'SHA256'
        },
        {...}
    ]
    Generate the above JSON object for the data set
    payloads = [
        {
            "bucket": bucket,
            "key": key,
            "start_byte": str(r[1][0]),
            "stop_byte": str(r[1][1]),
            "block_num": str(r[0]),
            "hash_algorithm": 'SHA256'
        } for r in ranges]
    print ("payloads: %s" % payloads)
    """
    results = []
    # spawn sets of NUM_INVOKER_THREADS lambdas to compute the hashes
    for r in ranges:
        p = {
            "bucket": s3_bucket,
            "key": s3_key,
            "start_byte": str(r[1][0]),
            "stop_byte": str(r[1][1]),
            "block_num": str(r[0]),
            "hash_algorithm": hash_algorithm
        }
        # print(p)
        result = invoke_hash_calculator(payload=p)
        results.append(result)

    # sort the results by blocknum - this will force a wait on all the lambdas
    # results = [r.wait() for r in results] - this is another way to force block on results
    hashed_result_sorted = sorted(results, key=lambda h: h.blocknum)

    # for r in hashed_result_sorted:
    #    print(r.blocknum, r.sha256, r.errornum)

    # compute the hash of all the hashes
    hash_of_hashes = ''
    # also compute if any errors were encountered
    # check that each one came back with errnum = 0
    errors = 0
    for hash in hashed_result_sorted:
        hash_of_hashes = hash_of_hashes + hash.value
        errors = errors + hash.errornum

    if hash_algorithm == 'SHA384':
        hash_sum = hashlib.sha384(str(hash_of_hashes).encode('utf-8')).hexdigest()
    elif hash_algorithm == 'SHA512':
        hash_sum = hashlib.sha512(str(hash_of_hashes).encode('utf-8')).hexdigest()
    else:
        hash_sum = hashlib.sha256(str(hash_of_hashes).encode('utf-8')).hexdigest()

    hashes_for_payload = [
        {
            "block": str(hash.blocknum),
            "value": hash.value
        } for hash in hashed_result_sorted]

    if errors > 0:
        error_text = str(errors) + " errors encountered computing hashes of portions of the object."
    else:
        error_text = ""

    # now build our resulting json
    full_hashes = {
        "blockSize": str(blocksize),
        "hashType": hash_algorithm,
        "totalBlocks": str(len(ranges)),
        "totalHash": hash_sum,
        "errnum": str(errors),
        "errortext": error_text,
        "Hash": hashes_for_payload
    }

    return full_hashes


@tomorrow.threads(NUM_INVOKER_THREADS)
def invoke_hash_calculator(payload=''):
    lambda_client = boto3.client("lambda")
    response = lambda_client.invoke(FunctionName=LAMBDA_CALCULATOR,
                                    Payload=json.dumps(payload),
                                    InvocationType="RequestResponse")
    # the response JSON looks like this:
    # { 'blocknum': block_num, 'sha256': readable_sha256hash, 'md5': readable_md5hash, 'errornum': 0 }

    hash_code = json.loads(response["Payload"].read())
    # hard code response for testing
    # result = Hashes(payload["block_num"], "sha256valueholder", "md5valueholder", 0, 0)
    result = Hashes(int(hash_code["blocknum"]), hash_code["value"], hash_code["md5"], int(hash_code["errornum"]))
    # print("blocknum %d hash computed." % int(hash_code["blocknum"]))
    return result


def _get_logging_level_from_string(log_level: str = 'info'):
    try:
        logging_level = {
            "critical": logging.CRITICAL,
            "error": logging.ERROR,
            "warning": logging.WARNING,
            "info": logging.INFO,
            "debug": logging.DEBUG
        }[log_level.strip().lower()]
    except (KeyError, Exception):
        logging_level = logging.INFO
    return logging_level


"""
JSON returned from this LAMBDA looks like this as an example (actual hash total value is not correct for this example):
{
  "blockSize": "536870912",
  "hashType": "SHA256",
  "totalBlocks": "3",
  "totalHash": "17564c15f23bc4234b4b4c6106bbb5e4bbee829580f9fac408a0afebf071f0e6",
  "errnum": "0",
  "Hash": [
    {
      "block": "1",
      "value": "826c4f634bb5c8d0bf1c2c804cf83612fcf98c9c1984eb45e102a4944dad80c6"
    },
    {
      "block": "2",
      "value": "841eaa5f23b5e4c41fd2ef40c075eb437b71b9147f8681978eebd2b404c9e9e2"
    },
    {
      "block": "3",
      "value": "55b77c4ca359ff48a68036e6725b6990ccc86e3f2084cde224ce49a28d86fc12"
    }
  ]
}
"""

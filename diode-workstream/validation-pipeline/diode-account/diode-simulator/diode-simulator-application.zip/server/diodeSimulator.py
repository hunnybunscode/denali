"""
The Diode Test Harness is provided to you as “Beta Materials” and your use of the Beta Materials
is governed by your agreement with AWS.  In particular, please note that your use of the Beta
Materials is subject to the Universal and Beta Service Participation sections of the AWS Service
Terms (http://aws.amazon.com/service-terms/) and is confidential, as is all associated documentation.
You may not discuss the features or functionality of the Beta Materials with any party
(individual or business) that is not authorized by Amazon Web Services.  You may not transfer the
Beta Materials outside of your AWS account nor may you otherwise distribute the Beta Materials to
any party.
"""
import os
import sys
import json
import time
import uuid
import re
import base64
import logging.handlers
import threading
import configparser
import hashlib
from botocore.exceptions import ClientError
from threading import RLock
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from random import seed, randint
from CDSDataValidator import CDSValidator
path = os.path.abspath(os.path.join(os.path.dirname(__file__), '../common_utils'))
if path not in sys.path:
    sys.path.insert(1, path)
import general_utils as generalutils
from rate_limit import RateLimiter, Bucket, Period as Per
path = os.path.abspath(os.path.join(os.path.dirname(__file__), '../CDSManifest'))
if path not in sys.path:
    sys.path.insert(1, path)
del path
from ManifestGenerator import ManifestGenerator

__VERSION__ = '3.9.4'

# The following variables are all settable via the CloudFormation Script at install and/or by editing the properties
# file on the EC2 instance - these are all default values that will get overwritten by the properties file values
HARNESS_LISTENER_PORT = 8080
RANDOM_FAILURES = False      # set to True to have random failures generated for transfers
DYNAMO_TRANSFER_TABLE = 'diode-simulator-transfers'
DYNAMO_MAPPING_TABLE = 'diode-simulator-mappings'
DYNAMO_MANIFEST_TABLE = 'diode-simulator-manifests'
SQS_QUEUE_NAME = 'diode-simulator-transfers'
S3_LOW_BUCKET = "diodesimulator-low"
S3_HIGH_BUCKET = "diodesimulator-high"
MANIFEST_STORAGE_BUCKET = "diodesimulator-manifests"
# The following will get updated based on property file setup during install
S3_DNS_SUFFIX = 'somebucket.s3.amazonaws.com'
CROSSACCOUNTROLEARN = None
CROSSACCOUNTHIGHBUCKET = None
MAXFILESIZEMB = 1024  # 1024 is 1GB, 2048 is 2GB
MAXINFLIGHTMBBYTES = 2*MAXFILESIZEMB
NUM_MOVER_THREADS = 1
NUM_MANIFEST_GENERATOR_THREADS = 1
TPS = 1.0  # Default Diode TPS rating, used to be 0.25
CLOUDWATCH_EVENTS_SOURCE = 'diode.simulator'    # The source value for the generated cloudwatch events on CDS status
AWS_REGION = 'us-east-1'
ALLBUCKETSACCESS = False
SWAMSHASHCONTROLLERLAMBDA = None

# End of user customized values

# All of the following values are only settable by modifying this code and should be done only if absolutely necessary
PROPERTY_FILE = '/home/ec2-user/diodeSimulator/diode_simulator.properties'  # file name to use if none passed at startup
LOG_FILENAME = '/home/ec2-user/diodeSimulator/diodeSimulator.log'
LOGGER = logging.getLogger('diode_simulator')

ALLOWED_FILE_SUFFIX_DIR = '/home/ec2-user/diodeSimulator/allowed_file_suffixes'
XSD_DIRECTORY = '/home/ec2-user/diodeSimulator/XSDs'

# Convert MB in flight to Bytes in flight
# MAXINFLIGHTBYTES = MAXINFLIGHTMBBYTES * 1024 * 1024
# Since our rate limiter wants intervals in whole numbers as seconds and
# default TPS is 1 (used to be 0.25) we adjust as show below
# for higher rates like 1 or 2 TPS use tps_rate_of(1 or 2, Per.Second)
# TPS_limiter = RateLimiter(per_second=TPS_rate_of(TPS*4, Per.SECOND*4))
# These are set up in initialization code - the following are the definitions
# of our rate limiter objects
# The limiter is the global limiter used to check when createTransfer requests
# come in
# TPS_rate_of = None
# TPS_limiter_Per_Mapping = None

MOVER_THREAD_KEEP_RUNNING = True
MANIFEST_GENERATOR_THREAD_KEEP_RUNNING = True

MAPPING_ID_REGEX_PATTERN = '[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}'
MAPPING_ID_REGEX = re.compile(MAPPING_ID_REGEX_PATTERN)
AWS_ACCOUNT_NUM = "123456789012"

seed(time.time())
session = generalutils.get_session(region=AWS_REGION)
WEBROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '../wwwroot'))
SOFTWARE_ARTIFACTS_MANIFEST_TAG = 'x-amz-software-artifact-manifest-s3-key'

# The following are globals to support the multiple mappings and limits at mapping level
# setup variables to track mapping information, TPS, totalMB in flight per mapping
mapping_dictionary = None
TPS_limiter_Per_Mapping = None
# The following dictionary contains the in flight data by mapping id
total_MB_in_flight = {}

# Lock for controlling total_MB_in_flight access
TOTALBYTESINFLIGHTLOCK = RLock()


# HTTPRequestHandler class
class DiodeSimulatorEndpointServerRequestHandler(BaseHTTPRequestHandler):

    # GET
    def do_GET(self):
        LOGGER.debug("in GET")
        # dump some information from the user
        LOGGER.debug(self.client_address)
        LOGGER.debug(self.requestline)
        LOGGER.info(f"path passed={self.path}")

        try:
            # Check the file extension required and
            # set the right mime type
            send_reply = False
            mimetype = ''

            if self.path == "/":
                self.path = "index.txt"
            else:
                LOGGER.error(f"requested (and ignoring) by {self.client_address} to "
                             f"look for file {WEBROOT}{os.sep}{self.path}")
                self.send_error(404, 'Bad Request')
                return
            if not self.path.startswith(".."):
                (send_reply, mimetype) = filetype_from_suffix(self.path)
            LOGGER.info("looking for file %s" % WEBROOT + os.sep + self.path)
            if send_reply:
                # Open the static file requested and send it
                f = open(WEBROOT + os.sep + self.path, "rb")
                self.send_response(200)
                self.send_header('Content-type', mimetype)
                self.end_headers()
                self.wfile.write(f.read())
                f.close()
            else:
                self.send_error(404, 'File Not Found: %s' % self.path)
            return
        except IOError:
            self.send_error(404, 'File Not Found: %s' % self.path)
        # # Send response status code
        # self.send_response(200)
        #
        # # Send headers
        # self.send_header('Content-type', 'text/html')
        # self.end_headers()
        #
        # # Send message back to client
        # message = "Diode Simulator!\n"
        # # Write content as utf-8 data
        # self.wfile.write(bytes(message, "utf8"))
        # return

    def do_POST(self):
        LOGGER.debug("in POST")
        LOGGER.info(f"Client_address={self.client_address}")
        LOGGER.debug(f"Client address={self.client_address}, client_request={self.requestline}")
        LOGGER.debug(self)
        # content_len = int(self.headers.getheader('content-length', 0))
        # diode_api = self.getheader('x-amz-target')
        diode_api = self.headers['x-amz-target']
        LOGGER.info(f"Simulator api call requested x-amz-target={diode_api}")
        if diode_api == "AWSDiodeFrontendService.CreateTransfer":
            # _generate_throttling_exception_response(self, _get_body_contents(self))
            # _generate_failed_to_get_length_of_file_exception_response(self, _get_body_contents(self))
            _handle_create_transfer_request(self)
        elif diode_api == "AWSDiodeFrontendService.DescribeTransfer":
            _handle_describe_transfer_request(self)
        elif diode_api == "AWSDiodeFrontendService.ListAccountMappings":
            _handle_list_account_mappings_request(self)
        elif diode_api == "AWSDiodeFrontendService.ListTransfers":
            _handle_list_transfers_request(self)
        elif diode_api == "AWSDiodeFrontendService.ListTags":
            _handle_list_tags_request(self)
        elif diode_api == "AWSDiodeFrontendService.CreateAccountMapping":
            _handle_create_accountmapping_request(self)
        elif diode_api == "AWSDiodeFrontendService.GetAccountMappingPin":
            _handle_get_accountmappingpin_request(self)
        elif diode_api == "AWSDiodeFrontendService.AcceptAccountMapping":
            _handle_accept_accountmapping_request(self)
        elif diode_api == "AWSDiodeFrontendService.DeleteAccountMapping":
            _handle_delete_accountmapping_request(self)
        elif diode_api == "AWSDiodeFrontendService.CreateTransferManifest":
            _handle_create_transfer_manifest_request(self)
        elif diode_api == "AWSDiodeFrontendService.DescribeTransferManifest":
            _handle_describe_transfer_manifest_request(self)
        elif diode_api == "AWSDiodeFrontendService.GetTransferManifest":
            _handle_get_transfer_manifest_request(self)
        else:
            # not supported request
            LOGGER.info(f"Requested API call {diode_api} not supported.")
            _generate_invalidrequest_exception_response(self)


def filetype_from_suffix(file_name):
    send_reply = False
    mimetype = ''
    if file_name.endswith(".html") or file_name.endswith(".txt"):
        mimetype = 'text/html'
        send_reply = True
    if file_name.endswith(".jpg"):
        mimetype = 'image/jpg'
        send_reply = True
    if file_name.endswith(".gif"):
        mimetype = 'image/gif'
        send_reply = True
    if file_name.endswith(".js"):
        mimetype = 'application/javascript'
        send_reply = True
    if file_name.endswith(".css"):
        mimetype = 'text/css'
        send_reply = True

    return send_reply, mimetype


def update_bytes_in_flight(mapping_id, amount_bytes):
    """
    Updates the total bytes in flight variable, returns True if value is allowed or False if not
    :param mapping_id: the mapping id that bytes in flight needs to be checked/updated for
    :param amount_bytes: pass negative amount for reducing amount in flight, positive to add.
    We use one lock variable to lock any accesses to the values across all the mappings - this operation
    is small enough in time that the performance hit is negligible
    :return: True if new amount does not exceed max allowed (only possible on +amount)
    """
    """
        mapping_dictionary = {i['mappingId']: i for i in jsontext['accountMappingList']}
        mapping_dictionary now contains a dictionary with mapping id as key and all the mapping
        info as a value -> print(d['12346789-abcd-1234-abcd-123456789012']['mappingType']) results in:
        standard
        'receivingRegion': 'localhost', 'softwareArtifactsMaxFileSizeMB': Decimal('30720'),
        'mappingOwnerArn': 'arn:aws:iam::123456789012:root', 'sendingRegion': 'localhost',
        'maxInFlightMB': Decimal('200'),
        'mappingArn': 'arn:aws:diode:localhost:123456789012:account-mapping/12346789-abcd-1234-abcd-123456789012',
        'mappingAlias': 'myalias', 'mappingStatus': 'ACCEPTED',
        'softwareArtifactsMaxFilesInFlight': Decimal('2'),
        'roleArn': 'arn:localhost:iam::123456789012:role/diode-sender-role',
        'pin': '234567', 'TPS': Decimal('0.25'), 'mappingType': 'standard',
        'mappingId': '12346789-abcd-1234-abcd-123456789012',
        'maxFileSizeMB': Decimal('100'), 'dateMappingCreated': Decimal('1574460639.5099999904632568359375')}
        Remove the mappingId from the values of the dict since it is the key
    """
    if mapping_id not in mapping_dictionary:
        LOGGER.error(f"mapping id {mapping_id} not found in "
                     f"mapping_dictionary-signalling to not allow")
        return False
    # compute the proper value for max_in_flight_bytes_allowed depending on mapping type
    if mapping_dictionary[mapping_id]['mappingType'] == 'standard':
        max_in_flight_bytes_allowed = mapping_dictionary[mapping_id]['maxInFlightMB'] * 1024 * 1024
    else:
        max_in_flight_bytes_allowed = \
            mapping_dictionary[mapping_id]['softwareArtifactsMaxFilesInFlight'] * \
            (mapping_dictionary[mapping_id]['softwareArtifactsMaxFileSizeMB'] * 1024 * 1024)

    LOGGER.debug(f"mapping-id {mapping_id} max_in_flight_bytes_allowed={max_in_flight_bytes_allowed},"
                 f" max_in_flight_MB_allowed={max_in_flight_bytes_allowed/(1024*1024)}")
    # Obtain a lock on the accesses to global array
    with TOTALBYTESINFLIGHTLOCK:
        global total_MB_in_flight
        total_bytes_in_flight = total_MB_in_flight[mapping_id] * 1024 * 1024
        if total_bytes_in_flight + amount_bytes > max_in_flight_bytes_allowed:
            LOGGER.debug(f"Total Bytes in flight would exceed allowed "
                         f"{max_in_flight_bytes_allowed} bytes in flight.")
            return False
        total_bytes_in_flight = total_bytes_in_flight + amount_bytes
        if total_bytes_in_flight < 0:
            total_bytes_in_flight = 0
        # update value in global
        total_MB_in_flight[mapping_id] = total_bytes_in_flight / (1024 * 1024)
    LOGGER.debug(f"Total bytes for mapping id {mapping_id} in flight now: "
                 f"{total_bytes_in_flight}")
    return True


# return the body of the POST request as JSON
def _get_body_contents(self):
    content_len = int(self.headers.get('Content-Length'))
    content = self.rfile.read(content_len)
    post_body = json.loads(content)
    return post_body


def _handle_create_transfer_request(self):
    # entry_time = time.time()
    # 2 decimal place time value
    post_body = _get_body_contents(self)
    mapping_id = post_body["mappingId"].casefold()
    description = post_body["description"]
    s3bucket = post_body["s3Bucket"]
    s3key = post_body["s3Key"]
    requestid = post_body["clientRequestToken"]  # idempotency token from SDK
    tags = post_body.get("tags", None)
    includeS3ObjectTags = post_body.get("includeS3ObjectTags", False)
    # Verify the mapping id is valid format and known
    if re.match(MAPPING_ID_REGEX, mapping_id):
        mapping_information = mapping_dictionary.get(mapping_id, None)
        if mapping_information is None:
            # could not find the mapping in our table
            if mapping_information is None or mapping_information['mappingStatus'] != 'ACCEPTED':
                _generate_mapping_id_doesnotexist_exception_response(self, post_body)
                return
            LOGGER.error(f"mapping id {mapping_id} not found in in-memory table.")
            _generate_mapping_id_doesnotexist_exception_response(self, post_body)
            return
    else:
        _generate_bad_mapping_id_exception_response(self, post_body)
        return

    # ensure the sending and receiving bucket names are not the same since we now support
    # multiple high side buckets as an option
    receiving_bucket = mapping_information['receivingBucket']
    if s3bucket == receiving_bucket:
        LOGGER.error(f"Specified same bucket name for sending ({s3bucket}) and "
                     f"receiving ({receiving_bucket}) transfer.")
        _generate_invalidrequest_exception_response(self, post_body)
        return
    # mapping is good, it is allowed mapping id so do the transfer
    # determine if this mapping is a software or standard mapping
    LOGGER.debug(f"mapping information for this request={mapping_information}")
    mapping_type = mapping_information['mappingType']
    LOGGER.debug(f"mapping id {mapping_id} is type {mapping_type}")
    if mapping_type == 'software':
        # make sure the manifest tag is in the list of tags
        if tags is None:
            _generate_no_manifest_for_software_mapping_id_exception_response(self, post_body)
            return
        # go read the tag and make sure it exists
        manifest_name = tags.get(SOFTWARE_ARTIFACTS_MANIFEST_TAG, None)
        if manifest_name is None:
            _generate_no_manifest_for_software_mapping_id_exception_response(self, post_body)
            return
        # so we have a manifest filename specified, and we are a Software mapping
        maxfilesizemb = mapping_information['softwareArtifactsMaxFileSizeMB']
    else:
        maxfilesizemb = mapping_information['maxFileSizeMB']

    LOGGER.debug("checking TPS limits")
    # check if we have not exceeded TPS limits for this mapping
    if not TPS_limiter_Per_Mapping[mapping_id].reduce():
        # exceeded limits
        _generate_throttling_exception_response(self, post_body)
        return
    LOGGER.debug(f"TPS limits are good for mapping id {mapping_id}")
    # check size of S3 object and make sure it does not exceed largest allowed size
    obj_size_bytes: int = get_size_s3_object(s3bucket, s3key)
    if obj_size_bytes == -1:
        _generate_failed_to_get_length_of_file_exception_response(self, post_body)
        return
    if obj_size_bytes/(1024*1024) > maxfilesizemb:
        _generate_length_of_file_exception_response(self, post_body)
        return

    # make sure we do not exceed bytes allowed in flight and update if we do not exceed the limit
    if not update_bytes_in_flight(mapping_id, obj_size_bytes):
        _generate_throttling_exception_response(self, post_body)
        return

    # generate a transfer id
    transfer_id = str(uuid.uuid4())
    transaction_id = str(uuid.uuid4())
    # generate time of request
    date_sent = generalutils.get_current_time_in_diode_format()
    # setup values we need in multiple places below
    mapping_arn = mapping_information['mappingArn']
    mapping_owner_arn = mapping_information['mappingOwnerArn']
    s3_uri = f"https://{s3bucket}.{S3_DNS_SUFFIX}/{s3key}"
    transfer_arn = generalutils.make_transfer_arn_prefix(AWS_ACCOUNT_NUM) + transfer_id

    # if includeS3ObjectTags:
    #     LOGGER.error(f"includeS3ObjectTags support is not supported-will process as a transfer without this option.")

    # put the record in dynamodb transfers table
    dynamo = generalutils.get_dynamodb_client(generalutils.get_session(region=AWS_REGION))
    fields = {'dateSent': date_sent, 'dateReceived': '0.0', 'mappingId': mapping_id,
              'mappingArn': mapping_arn, 'mappingOwnerArn': mapping_owner_arn, 's3Uri': s3_uri,
              'transactionId': transaction_id,
              'includeS3ObjectTags': includeS3ObjectTags,
              'sourceRegion': 'localhost', 'transferArn': transfer_arn, 'status': 'IN_TRANSIT',
              'description': description, 'fileSizeInBytes': obj_size_bytes,
              'subject': s3key, 'version': 3}
    if tags is not None:
        fields['tags'] = tags

    # insert the record in dynamo - we use an update
    dyn_expression = "SET %s" % ", ".join(["#{name}=:{name}".format(name=name) for name in fields.keys()])
    dyn_expression_attribute_names = {"#%s" % k: k for k in fields.keys()}
    dyn_expression_attribute_values = {":%s" % k: v for k, v in fields.items()}
    dynamo.meta.client.update_item(
        TableName=DYNAMO_TRANSFER_TABLE,
        Key={'transferId': transfer_id},
        UpdateExpression=dyn_expression,
        ExpressionAttributeNames=dyn_expression_attribute_names,
        ExpressionAttributeValues=dyn_expression_attribute_values,
    )
    LOGGER.debug(f"Transfer id {transfer_id} added to dynamodb transfers table")
    # Now put a msg on our SQS queue to trigger our transfer thread to handle it
    sqs = generalutils.get_sqs_client(generalutils.get_session(region=AWS_REGION))
    queue = sqs.get_queue_by_name(QueueName=SQS_QUEUE_NAME)

    # Create a new message
    msg_as_json = {'mappingId': mapping_id, 'mappingArn': mapping_arn,
                   'transferId': transfer_id,
                   'bucket': s3bucket, 'key': s3key, 's3Uri': s3_uri,
                   'transferArn': transfer_arn, 'size': obj_size_bytes,
                   'includeS3ObjectTags': includeS3ObjectTags
                   }

    response = queue.send_message(MessageBody=json.dumps(msg_as_json))
    LOGGER.debug(f"SQS message queued for internal processing {response}")
    LOGGER.info("simulator harness internal transfer sqs message queued transfer id %s." % transfer_id)
    jsontext = {'transfer': {'status': 'IN_TRANSIT',
                             'description': description,
                             'fileSizeInBytes': obj_size_bytes,
                             'dateSent': date_sent,
                             'mappingId': mapping_id,
                             'mappingArn': mapping_arn,
                             'transferId': transfer_id,
                             'dateReceived': 0.0,
                             's3Uri': s3_uri,
                             'transferArn': transfer_arn
                             }
                }
    response_as_json = json.dumps(jsontext, cls=generalutils.DecimalEncoder)
    LOGGER.debug(response_as_json)
    self.send_response(200)
    set_aws_content_headers(self, content_length=len(response_as_json))
    self.send_header('x-amzn-requestid', requestid)
    self.end_headers()
    self.wfile.write(bytes(response_as_json, "utf8"))

    # Generate CloudWatch IN_TRANSIT event
    cloudwatch_events = generalutils.get_cloudwatch_events_client(generalutils.get_session(region=AWS_REGION))

    json_detail = {'mappingId': mapping_id, 's3Uri': s3_uri, 's3Key': s3key,
                   's3Bucket': s3bucket, 'fileSize': obj_size_bytes, 'dateReceived': 0.0,
                   'description': description, 'transferId': transfer_id,
                   'dateSent': date_sent, 'status': 'IN_TRANSIT'}
    response = cloudwatch_events.put_events(Entries=[
        {
            'Detail': json.dumps(json_detail, cls=generalutils.DecimalEncoder),
            'DetailType': 'Diode Transfer Status',
            'Resources': [
                mapping_arn, transfer_arn
            ],
            'Source': CLOUDWATCH_EVENTS_SOURCE
        }]
    )
    LOGGER.debug("completed generate cloudwatch event response=%s" % response)
    return


def _generate_invalidrequest_exception_response(self):
    # Build the create transfer throttling exception response
    # _ = post_body
    jsontext = {'__type': 'InvalidRequestException', 'message': 'Invalid request or unsupported command'}
    response_as_json = json.dumps(jsontext)
    LOGGER.debug(response_as_json)
    self.send_response(400)
    set_aws_content_headers(self, content_length=len(response_as_json))
    self.end_headers()
    self.wfile.write(bytes(response_as_json, "utf8"))
    return


def _generate_throttling_exception_response(self, post_body):
    # post_body = self.rfile.read(content_len)
    # 2 decimal place time value
    requestid = post_body["clientRequestToken"]  # idempotency token from SDK
    # Build the create transfer throttling exception response
    jsontext = {'__type': 'ThrottlingException', 'message': 'Rate exceeded'}
    response_as_json = json.dumps(jsontext)
    LOGGER.debug(response_as_json)
    self.send_response(400)
    set_aws_content_headers(self, content_length=len(response_as_json))
    self.send_header('x-amzn-requestid', requestid)
    self.end_headers()
    self.wfile.write(bytes(response_as_json, "utf8"))
    return


def _generate_failed_to_get_length_of_file_exception_response(self, post_body):
    # post_body = self.rfile.read(content_len)
    # 2 decimal place time value
    # mapping_id = post_body["mappingId"]
    # description = post_body["description"]
    s3bucket = post_body["s3Bucket"]
    s3key = post_body["s3Key"]
    requestid = post_body["clientRequestToken"]  # idempotency token from SDK

    # Build the create transfer file not found exception response
    jsontext = {'__type': 'ResourceNotFoundException',
                'message': f"Failed to get the length of the customer file "
                           f"https://{s3bucket}.{S3_DNS_SUFFIX}/{s3key}"}
    response_as_json = json.dumps(jsontext)
    LOGGER.debug(response_as_json)
    self.send_response(400)
    set_aws_content_headers(self, content_length=len(response_as_json))
    self.send_header('x-amzn-requestid', requestid)
    self.end_headers()
    self.wfile.write(bytes(response_as_json, "utf8"))
    return


def _generate_length_of_file_exception_response(self, post_body):
    # post_body = self.rfile.read(content_len)
    # 2 decimal place time value
    mapping_id = post_body["mappingId"]
    max_file_size_bytes = mapping_dictionary[mapping_id]['maxFileSizeMB'] * 1024 * 1024
    # description = post_body["description"]
    s3bucket = post_body["s3Bucket"]
    s3key = post_body["s3Key"]
    requestid = post_body["clientRequestToken"]  # idempotency token from SDK

    # Build the create transfer file not found exception response
    jsontext = {'__type': 'InvalidRequestException',
                'message': f'The size of the S3 object '
                           f'https://{s3bucket}.{S3_DNS_SUFFIX}/{s3key} exceeds'
                           f' the maximum supported transfer size of {max_file_size_bytes} bytes'
                }

    response_as_json = json.dumps(jsontext)
    LOGGER.debug(response_as_json)
    self.send_response(400)
    set_aws_content_headers(self, content_length=len(response_as_json))
    self.send_header('x-amzn-requestid', requestid)
    self.end_headers()
    self.wfile.write(bytes(response_as_json, "utf8"))
    return


def _generate_bad_mapping_id_exception_response(self, post_body):
    # Build the create transfer file not found exception response
    mapping_id = post_body["mappingId"]
    requestid = post_body["clientRequestToken"]  # idempotency token from SDK
    jsontext = {'__type': 'ValidationException', 'message':
                '1 validation error detected: Value \'%s\' at \'mappingId\' failed to satisfy constraint: '
                'Member must satisfy regular expression '
                'pattern: %s' % (mapping_id, MAPPING_ID_REGEX_PATTERN)}
    response_as_json = json.dumps(jsontext)
    LOGGER.debug(response_as_json)
    self.send_response(400)
    set_aws_content_headers(self, content_length=len(response_as_json))
    self.send_header('x-amzn-requestid', requestid)
    self.end_headers()
    self.wfile.write(bytes(response_as_json, "utf8"))
    return


def _generate_mapping_id_doesnotexist_exception_response(self, post_body):
    # Build the create transfer file not found exception response
    mapping_id = post_body["mappingId"]
    requestid = post_body.get("clientRequestToken", None)  # idempotency token from SDK
    jsontext = {'__type': 'ResourceNotFoundException', 'message': f'AccountMapping {mapping_id} does not exist'}
    response_as_json = json.dumps(jsontext)
    LOGGER.debug(response_as_json)
    self.send_response(400)
    set_aws_content_headers(self, content_length=len(response_as_json))
    self.send_header('Content-length', len(response_as_json))
    if requestid is not None:
        self.send_header('x-amzn-requestid', requestid)
    self.end_headers()
    self.wfile.write(bytes(response_as_json, "utf8"))
    return


def _generate_no_manifest_for_software_mapping_id_exception_response(self, post_body):
    # Build the create transfer file not found exception response
    mapping_id = post_body["mappingId"]
    requestid = post_body["clientRequestToken"]  # idempotency token from SDK
    jsontext = {'__type': 'ValidationException', 'message': f'1 validation error detected: Value {mapping_id} '
                                                            f'at \'mappingId\' requires a manifest filename to be '
                                                            f'supplied using a tag '
                                                            f'named {SOFTWARE_ARTIFACTS_MANIFEST_TAG}'}
    response_as_json = json.dumps(jsontext)
    LOGGER.debug(response_as_json)
    self.send_response(400)
    set_aws_content_headers(self, content_length=len(response_as_json))
    self.send_header('x-amzn-requestid', requestid)
    self.end_headers()
    self.wfile.write(bytes(response_as_json, "utf8"))
    return


def _generate_create_mapping_id_exception_response(self, post_body, field, message):
    # Build the create transfer file not found exception response
    requestid = post_body.get("clientRequestToken", None)  # idempotency token from SDK
    jsontext = {'__type': 'ValidationException',
                'message': f'1 validation error detected: Value at \'{field}\' failed to satisfy constraint: {message}'}
    response_as_json = json.dumps(jsontext)
    LOGGER.debug(response_as_json)
    self.send_response(400)
    set_aws_content_headers(self, content_length=len(response_as_json))
    if requestid is not None:
        self.send_header('x-amzn-requestid', requestid)
    self.end_headers()
    self.wfile.write(bytes(response_as_json, "utf8"))
    return


# *********************************************** SWAMS Addins *****************************
"""
Making request for OperationModel(name=CreateTransferManifest) with params: {'url_path': '/', 'query_string': '', 
'method': 'POST', 'headers': {'X-Amz-Target': 'AWSDiodeFrontendService.CreateTransferManifest', 
'Content-Type': 'application/x-amz-json-1.1', 
'User-Agent': 'aws-cli/2.2.39 Python/3.8.8 Darwin/21.4.0 exe/x86_64 prompt/off command/diode.create-transfer-manifest'}, 
'body': b'{"mappingId": "346c575a-27b2-441a-a6e2-fb055d00f9f0", 
"manifestTemplate": "{\\"originator\\": \\"AWS\\", \\"product\\": \\"PRODUCTNAME\\", \\"version\\": \\"1.0.1\\", \\"arch\\": \\"64-bit\\", \\"virus_scan\\": {\\"vendor\\": \\"McAfee\\", \\"version\\": \\"VSE8.88\\", \\"signature_date\\": \\"2019-01-17T09:00:00Z\\", \\"result\\": \\"clean\\"}, \\"mediaType\\": \\"application/octet-stream\\"}\\n", 
"payloadS3Bucket": "tonydahb-junk", 
"payloadS3Key": "test.csv", 
"manifestFormat": "TDF"}', 
'url': 'https://diode.us-east-1.amazonaws.com/', 
'context': {'client_region': 'us-east-1', 
'client_config': <botocore.config.Config object at 0x7fee37bb7bb0>, 
'has_streaming_input': False, 'auth_type': None}}
"""


def _handle_create_transfer_manifest_request(self):
    func_name = 'CreateTransferManifest'
    post_body = _get_body_contents(self)
    requestid = post_body.get("clientRequestToken", None)  # idempotency token from SDK
    mapping_id = post_body.get("mappingId").casefold()
    manifest_template = post_body.get("manifestTemplate")
    payload_s3_bucket = post_body.get("payloadS3Bucket")
    payload_s3_key = post_body.get("payloadS3Key")
    hash_type = post_body.get("hashType", 'sha256')
    # place the SWAMS names for these two fields as other call names, so we can reuse
    # error code for standard diode commands
    post_body['s3Bucket'] = payload_s3_bucket
    post_body['s3Key'] = payload_s3_key
    manifest_format = post_body.get("manifestFormat", 'TDF')

    # Verify the mapping id is valid format and known
    if re.match(MAPPING_ID_REGEX, mapping_id):
        mapping_information = mapping_dictionary.get(mapping_id, None)
        if mapping_information is None:
            # could not find the mapping in our table
            if mapping_information is None or mapping_information['mappingStatus'] != 'ACCEPTED':
                _generate_create_transfer_manifest_request_exception_response(self, post_body)
                return
            LOGGER.error(f"mapping id {mapping_id} not found in in-memory table.")
            _generate_create_transfer_manifest_request_exception_response(self, post_body)
            return
    else:
        _generate_create_transfer_manifest_request_exception_response(self, post_body)
        return
    mapping_type = mapping_information['mappingType']
    if mapping_type == 'standard':
        _generate_create_transfer_manifest_request_exception_response(self, post_body)
        return

    # mapping is good, it is allowed mapping id so create the manifest request
    obj_size_bytes: int = get_size_s3_object(payload_s3_bucket, payload_s3_key)
    if obj_size_bytes == -1:
        LOGGER.debug(f"Unable to get size of object at s3://{payload_s3_bucket}/{payload_s3_key}.")
        _generate_failed_to_get_length_of_file_or_file_not_found_exception_response(self, post_body)
        return

    maxfilesizemb = mapping_information['softwareArtifactsMaxFileSizeMB']
    if obj_size_bytes/(1024*1024) > maxfilesizemb:
        _generate_length_of_file_exception_response(self, post_body)
        return

    # make sure we do not exceed bytes allowed in flight and update if we do not exceed the limit
    if not update_bytes_in_flight(mapping_id, obj_size_bytes):
        _generate_throttling_exception_response(self, post_body)
        return

    # generate time of request
    # date_sent = generalutils.get_current_time_in_diode_format()
    # call the method in the ManifestGenerator Class to add this job
    transfer_manifest_id = manifest_generation_processors[0].\
        create_transfer_manifest(mapping_dictionary=mapping_dictionary,
                                 mapping_id=mapping_id,
                                 manifest_template=manifest_template,
                                 payload_s3_bucket=payload_s3_bucket,
                                 payload_s3_key=payload_s3_key,
                                 payload_size_bytes=obj_size_bytes,
                                 manifest_format=manifest_format,
                                 hash_type=hash_type)
    if transfer_manifest_id is None:
        LOGGER.debug(f"Manifest generator refused to create entry due to limits exceeded.")
        _generate_too_many_requests_in_flight_filesizes_response(self, post_body)
        return

    jsontext = {'transferManifestId': transfer_manifest_id}
    response_as_json = json.dumps(jsontext, cls=generalutils.DecimalEncoder)
    LOGGER.debug(response_as_json)
    self.send_response(200)
    set_aws_content_headers(self, content_length=len(response_as_json))
    if requestid is not None:
        self.send_header('x-amzn-requestid', requestid)
    self.end_headers()
    self.wfile.write(bytes(response_as_json, "utf8"))
    return


def _generate_create_transfer_manifest_request_exception_response(self, post_body, func_name=''):
    mapping_id = post_body.get("mappingId").casefold()
    # Build the create transfer throttling exception response
    msg = f'{func_name} AccountMapping {mapping_id} does not exist or user is not authorized ' \
          f'to access the account mapping'
    _swams_exception_response(self, msg=msg.strip(), post_body=post_body)
    return


def _generate_failed_to_get_length_of_file_or_file_not_found_exception_response(self, post_body):
    msg = f"Diode did not have sufficient permissions to access the payload. " \
          f"Verify that the required permissions are granted and create the manifest again."
    _swams_exception_response(self, msg=msg, post_body=post_body)
    return


def _swams_exception_response(self, msg='none', post_body={}):
    requestid = post_body.get("clientRequestToken", None)  # idempotency token from SDK
    # Build the create transfer throttling exception response
    jsontext = {'__type': 'AccessDeniedException', 'message': msg}
    response_as_json = json.dumps(jsontext)
    LOGGER.debug(response_as_json)
    self.send_response(400)
    set_aws_content_headers(self, content_length=len(response_as_json))
    if requestid is not None:
        self.send_header('x-amzn-requestid', requestid)
    self.end_headers()
    self.wfile.write(bytes(response_as_json, "utf8"))
    return


def _generate_too_many_requests_in_flight_filesizes_response(self, post_body):
    msg = f"Exceeded allowed simultaneous manifest requests."
    requestid = post_body.get("clientRequestToken", None)  # idempotency token from SDK
    # Build the throttling exception response
    jsontext = {'__type': 'ResourceLimitExceededException', 'message': msg}
    response_as_json = json.dumps(jsontext)
    LOGGER.debug(response_as_json)
    self.send_response(400)
    set_aws_content_headers(self, content_length=len(response_as_json))
    if requestid is not None:
        self.send_header('x-amzn-requestid', requestid)
    self.end_headers()
    self.wfile.write(bytes(response_as_json, "utf8"))
    return


def _handle_describe_transfer_manifest_request(self):
    func_name = 'DescribeTransferManifest'
    post_body = _get_body_contents(self)
    transfer_manifest_id = post_body["transferManifestId"]
    mapping_id = post_body["mappingId"]
    requestid = str(uuid.uuid4())
    if re.match(MAPPING_ID_REGEX, mapping_id):
        mapping_information = mapping_dictionary.get(mapping_id, None)
        if mapping_information is None:
            # could not find the mapping in our table
            if mapping_information is None or mapping_information['mappingStatus'] != 'ACCEPTED':
                _generate_create_transfer_manifest_request_exception_response(self,
                                                                              post_body,
                                                                              func_name=func_name)
                return
            LOGGER.error(f"mapping id {mapping_id} not found in in-memory table.")
            _generate_create_transfer_manifest_request_exception_response(self,
                                                                          post_body,
                                                                          func_name=func_name)
            return
    else:
        _generate_create_transfer_manifest_request_exception_response(self,
                                                                      post_body,
                                                                      func_name=func_name)
        return
    mapping_type = mapping_information['mappingType']
    if mapping_type == 'standard':
        _generate_create_transfer_manifest_request_exception_response(self,
                                                                      post_body,
                                                                      func_name=func_name)
        return
    transfer_manifest_status = manifest_generation_processors[0].describe_transfer_manifest(
        transfer_manifest_id=transfer_manifest_id, mapping_id=mapping_id)
    if transfer_manifest_status is None:
        LOGGER.info('Did not find transferManifestId %s' % str(transfer_manifest_id))
        jsontext = {'__type': 'ResourceNotFoundException', 'message': f'transferManifestId {transfer_manifest_id} does not exist.'}
        response_as_json = json.dumps(jsontext)
        LOGGER.debug(response_as_json)
        self.send_response(400)
        set_aws_content_headers(self, content_length=len(response_as_json))
        self.send_header('x-amzn-requestid', requestid)
        self.end_headers()
        self.wfile.write(bytes(response_as_json, "utf8"))
        return

    # normal response for query
    response_as_json = json.dumps(transfer_manifest_status, cls=generalutils.DecimalEncoder)
    LOGGER.debug(response_as_json)
    self.send_response(200)
    set_aws_content_headers(self, content_length=len(response_as_json))
    if requestid is not None:
        self.send_header('x-amzn-requestid', requestid)
    self.end_headers()
    self.wfile.write(bytes(response_as_json, "utf8"))


def _handle_get_transfer_manifest_request(self):
    func_name = 'GetTransferManifest'
    post_body = _get_body_contents(self)
    transfer_manifest_id = post_body.get("transferManifestId", '')
    mapping_id = post_body.get("mappingId", '')
    request_id = str(uuid.uuid4())
    LOGGER.info(f"_handle_get_transfer_manifest_request processing get request "
                f"for manifest-id {transfer_manifest_id} and mapping-id {mapping_id}")
    if re.match(MAPPING_ID_REGEX, mapping_id):
        mapping_information = mapping_dictionary.get(mapping_id, None)
        if mapping_information is None:
            # could not find the mapping in our table
            if mapping_information is None or mapping_information['mappingStatus'] != 'ACCEPTED':
                _generate_create_transfer_manifest_request_exception_response(self, post_body, func_name=func_name)
                return
            LOGGER.error(f"mapping id {mapping_id} not found in in-memory table.")
            _generate_create_transfer_manifest_request_exception_response(self, post_body, func_name=func_name)
            return
    else:
        _generate_create_transfer_manifest_request_exception_response(self, post_body, func_name=func_name)
        return
    mapping_type = mapping_information['mappingType']
    if mapping_type == 'standard':
        _generate_create_transfer_manifest_request_exception_response(self, post_body, func_name=func_name)
        return
    transfer_manifest_response = manifest_generation_processors[0].get_transfer_manifest(
        transfer_manifest_id=transfer_manifest_id, mapping_id=mapping_id)
    if transfer_manifest_response is None:
        LOGGER.error('Did not find transferManifestId %s' % str(transfer_manifest_id))
        jsontext = {'__type': 'ResourceNotFoundException',
                    'message': f'transferManifestId {transfer_manifest_id} does not exist.'}
        response_as_json = json.dumps(jsontext)
        LOGGER.debug(response_as_json)
        self.send_response(400)
        set_aws_content_headers(self, content_length=len(response_as_json))
        self.send_header('x-amzn-requestid', request_id)
        self.end_headers()
        self.wfile.write(bytes(response_as_json, "utf8"))
        return

    # normal response for request
    response_as_json = json.dumps(transfer_manifest_response, cls=generalutils.DecimalEncoder)
    LOGGER.debug(response_as_json)
    self.send_response(200)
    set_aws_content_headers(self, content_length=len(response_as_json))
    self.send_header('x-amzn-requestid', request_id)
    self.end_headers()
    self.wfile.write(bytes(response_as_json, "utf8"))


# End of SWAMS core handlers - other additions are present in the code base to support
# SWAMS functionality.


def _handle_describe_transfer_request(self):
    post_body = _get_body_contents(self)
    transferid = post_body["transferId"]
    LOGGER.debug(transferid)
    requestid = str(uuid.uuid4())
    # grab all the transfer requests from the DB
    # get all the transfers in our dict and convert to json array
    jsontext = {}
    dynamo = generalutils.get_dynamodb_client(generalutils.get_session(region=AWS_REGION))
    transferinfojson = generalutils.get_transfer_record_in_table(dynamo, DYNAMO_TRANSFER_TABLE, transferid)
    if transferinfojson is None:
        LOGGER.info('did not find transferid %s' % str(transferid))
        jsontext = {'__type': 'ResourceNotFoundException', 'message': f'TransferId {transferid} does not exist.'}
        response_as_json = json.dumps(jsontext)
        LOGGER.debug(response_as_json)
        self.send_response(400)
        set_aws_content_headers(self, content_length=len(response_as_json))
        self.send_header('x-amzn-requestid', requestid)
        self.end_headers()
        self.wfile.write(bytes(response_as_json, "utf8"))
    else:
        LOGGER.info("found transfer id %s" % str(transferid))
        jsontext['transfer'] = transferinfojson
        response_as_json = json.dumps(jsontext, cls=generalutils.DecimalEncoder)
        LOGGER.debug(response_as_json)
        self.send_response(200)
        set_aws_content_headers(self, content_length=len(response_as_json))
        self.send_header('x-amzn-requestid', requestid)
        self.end_headers()
        self.wfile.write(bytes(response_as_json, "utf8"))
    return


def _handle_list_account_mappings_request(self):
    requestid = str(uuid.uuid4())  # post_body["clientRequestToken"]  # idempotency token from SDK
    post_body = _get_body_contents(self)
    nexttoken = post_body.get('nextToken', None)
    scanparams = {}
    if nexttoken is not None:
        s = base64.b64decode(nexttoken)
        nexttoken = json.loads(s)
        scanparams['ExclusiveStartKey'] = nexttoken
    maxresults = post_body.get('maxResults', 0)
    maxresults = min(maxresults, 100)
    if maxresults != 0:
        scanparams['Limit'] = maxresults
    # get all the account mappings in our dict and convert to json array
    dynamo = generalutils.get_dynamodb_client(generalutils.get_session(region=AWS_REGION))
    jsontext = generalutils.get_all_mappings_table(dynamo, DYNAMO_MAPPING_TABLE, **scanparams)
    response_as_json = json.dumps(jsontext, cls=generalutils.DecimalEncoder)
    LOGGER.debug(response_as_json)
    self.send_response(200)
    set_aws_content_headers(self, content_length=len(response_as_json))
    self.send_header('x-amzn-requestid', requestid)
    self.end_headers()
    self.wfile.write(bytes(response_as_json, "utf8"))
    return


def _handle_list_transfers_request(self):
    requestid = str(uuid.uuid4())  # post_body["clientRequestToken"]  # idempotency token from SDK
    # get all the transfers in our dict and convert to json array
    post_body = _get_body_contents(self)
    nexttoken = post_body.get('nextToken', None)
    scanparams = {}
    if nexttoken is not None:
        s = base64.b64decode(nexttoken)
        nexttoken = json.loads(s)
        scanparams['ExclusiveStartKey'] = nexttoken
    maxresults = post_body.get('maxResults', 0)
    maxresults = min(maxresults, 100)
    if maxresults != 0:
        scanparams['Limit'] = maxresults

    dynamo = generalutils.get_dynamodb_client(generalutils.get_session(region=AWS_REGION))
    jsontext = generalutils.get_all_transfers_table(dynamo, DYNAMO_TRANSFER_TABLE, **scanparams)
    response_as_json = json.dumps(jsontext, cls=generalutils.DecimalEncoder)
    LOGGER.debug(response_as_json)
    self.send_response(200)
    set_aws_content_headers(self, content_length=len(response_as_json))
    self.send_header('x-amzn-requestid', requestid)
    self.end_headers()
    self.wfile.write(bytes(response_as_json, "utf8"))

    return


def _handle_list_tags_request(self):
    requestid = str(uuid.uuid4())  # post_body["clientRequestToken"]  # idempotency token from SDK
    post_body = _get_body_contents(self)
    resource_arn = post_body["resource"]
    # we can return tags for a mapping or a transfer so see which is wanted
    # mapping ARN: arn:aws:diode:us-east-1:560654321127:account-mapping/eafc2143-35a4-4874-a037-3154fc5c606e
    # transfer ARN: arn:aws:diode:us-east-1:560654321127:transfer/801244e3-c73d-4efd-ba0b-bb7c904ddbc0
    # get the transferid from the ARN resource since we only support tags request on transfers
    # transferArn = 'arn:aws:diode:localhost:' + AWS_ACCOUNT_NUM + ':transfer/' + transferId
    # check if list-tags is called on a transfer ARN
    transfer_id = generalutils.get_transfer_id_from_transfer_arn(resource_arn, AWS_ACCOUNT_NUM)
    if transfer_id:
        LOGGER.debug(f'resource_arn={resource_arn}, transfer id from resource arn={transfer_id}')
        dynamo = generalutils.get_dynamodb_client(generalutils.get_session(region=AWS_REGION))
        transferinfojson = generalutils.get_transfer_tags_in_table(dynamo, DYNAMO_TRANSFER_TABLE, transfer_id)
        if transferinfojson is None:
            LOGGER.info('did not find transferid %s' % str(transfer_id))
            jsontext = {'__type': 'ResourceNotFoundException',
                        'message': ('TransferId %s does not exist.' % transfer_id)}
            response_as_json = json.dumps(jsontext)
            LOGGER.debug(response_as_json)
            self.send_response(400)
            set_aws_content_headers(self, content_length=len(response_as_json))
            self.send_header('x-amzn-requestid', requestid)
            self.end_headers()
            self.wfile.write(bytes(response_as_json, "utf8"))
        else:
            LOGGER.info(f"list tags request found transfer id {transfer_id} in requested arn of {resource_arn}")
            # jsontext['transfer'] = transferinfojson
            response_as_json = json.dumps(transferinfojson, cls=generalutils.DecimalEncoder)
            LOGGER.debug(response_as_json)
            self.send_response(200)
            set_aws_content_headers(self, content_length=len(response_as_json))
            self.send_header('x-amzn-requestid', requestid)
            self.end_headers()
            self.wfile.write(bytes(response_as_json, "utf8"))
    # check if list tags is called on a mapping ARN
    mapping_id = generalutils.get_mapping_id_from_mapping_arn(resource_arn, AWS_ACCOUNT_NUM)
    if mapping_id:
        LOGGER.debug(f'resource_arn={resource_arn}, mapping id from resource arn={mapping_id}')
        dynamo = generalutils.get_dynamodb_client(generalutils.get_session(region=AWS_REGION))
        mappinginfojson = generalutils.get_mapping_tags_in_table(dynamo, DYNAMO_TRANSFER_TABLE, mapping_id)
        if mappinginfojson is None:
            LOGGER.info('did not find mappingid %s' % str(mapping_id))
            jsontext = {'__type': 'ResourceNotFoundException',
                        'message': ('AccountMapping %s does not exist' % mapping_id)}
            response_as_json = json.dumps(jsontext)
            LOGGER.debug(response_as_json)
            self.send_response(400)
            set_aws_content_headers(self, content_length=len(response_as_json))
            self.send_header('x-amzn-requestid', requestid)
            self.end_headers()
            self.wfile.write(bytes(response_as_json, "utf8"))
        else:
            LOGGER.info(f"list tags request found mapping id {mapping_id} in requested arn of {resource_arn}")
            # jsontext['transfer'] = transferinfojson
            response_as_json = json.dumps(mappinginfojson, cls=generalutils.DecimalEncoder)
            LOGGER.debug(response_as_json)
            self.send_response(200)
            set_aws_content_headers(self, content_length=len(response_as_json))
            self.send_header('x-amzn-requestid', requestid)
            self.end_headers()
            self.wfile.write(bytes(response_as_json, "utf8"))
    # we got here then it was a bad arn we only support account-mapping and transfer ARNs
    _generate_invalidrequest_exception_response(self)
    return


def _handle_create_accountmapping_request(self):
    post_body = _get_body_contents(self)
    roleArn = post_body.get("roleArn", "")
    alias = post_body.get("alias", "")
    requestid = post_body["clientRequestToken"]  # idempotency token from SDK
    senderAccountId = post_body.get("senderAccountId", AWS_ACCOUNT_NUM)
    remoteRegion = post_body["remoteRegion"]
    deliveryS3BucketName = post_body.get("deliveryS3BucketName", S3_HIGH_BUCKET)
    transferProfile = post_body.get('transferProfile', 'CDS_1')
    mappingId = str(uuid.uuid4())

    # verify values - they must match for the simulator harness
    if roleArn != f"arn:localhost:iam::{AWS_ACCOUNT_NUM}:role/diode-receiver-role":
        _generate_create_mapping_id_exception_response(self, post_body, 'roleArn',
                                                       'must have value of \'arn:localhost:iam::' + AWS_ACCOUNT_NUM +
                                                       ':role/diode-receiver-role\'')
        return
    if senderAccountId != AWS_ACCOUNT_NUM:
        _generate_create_mapping_id_exception_response(self, post_body, 'senderAccountId',
                                                       'must have value of :' + AWS_ACCOUNT_NUM)
        return
    if remoteRegion != 'localhost':
        _generate_create_mapping_id_exception_response(self, post_body, 'remoteRegion',
                                                       'must have value of :localhost')
        return

    if transferProfile not in ['TSABI_CDS', 'NCDSMO_CDS_1', 'CDS_1', 'CDS_2', 'CDS_3']:
        _generate_create_mapping_id_exception_response(self, post_body, 'transferProfile',
                                                       'must be CDS_1, CDS_2 or CDS_3')
    # following were legacy names that were replaced, yet SDK still permitted
    if transferProfile == 'TSABI_CDS':
        transferProfile = 'CDS_1'
    if transferProfile == "NCDSMO_CDS_1":
        transferProfile = 'CDS_2'

    if deliveryS3BucketName != S3_HIGH_BUCKET:
        LOGGER.info(f"create-account-mapping request with high side bucket desired of {deliveryS3BucketName}")
        if not ALLBUCKETSACCESS:
            LOGGER.error(f"rejecting request for high side bucket named {deliveryS3BucketName} "
                         f"because ALLBUCKETACCESS was not enabled during CF setup.")
            _generate_create_mapping_id_exception_response(self, post_body, 'deliveryS3BucketName',
                                                           'must have value of :\'' + S3_HIGH_BUCKET + '\'')
            return
    # ensure delivery bucket exists
    try:
        s3resource = generalutils.get_s3_client(generalutils.get_session(region=AWS_REGION))
        s3resource.meta.client.head_bucket(Bucket=deliveryS3BucketName)
    except ClientError:
        # does not exist
        LOGGER.error(f"specified destination bucket {deliveryS3BucketName} does not exist")
        _generate_create_mapping_id_exception_response(self, post_body, 'deliveryS3BucketName',
                                                       'bucket does not exist.')
        return

    """ 
    {'roleArn': 'arn:aws-iso-b:iam::444455556666:role/my-diode-receiver-role', 
    'alias': 'my-account-mapping-alias', 
    'clientRequestToken': '2d6e96b6-f6c7-45ff-8155-0434c657d945', 
    'senderAccountId': '123456789012', 
    'remoteRegion': 'us-east-1', 
    'deliveryS3BucketName': 'my-high-side-delivery-bucket-name'}

    """
    # insert the mapping id record
    # first generate a pin for the record
    pin = ''.join(["%s" % randint(0, 9) for _ in range(0, 6)])
    dynamo = generalutils.get_dynamodb_client(generalutils.get_session(region=AWS_REGION))
    generalutils.insert_mapping_record_in_table(dbclient=dynamo, table_name=DYNAMO_MAPPING_TABLE,
                                                mapping_id=mappingId, alias=alias,
                                                account_num=senderAccountId, mapping_status='PENDING_ACCEPTANCE',
                                                pin=pin, maxfilesizemb=MAXFILESIZEMB,
                                                tps=TPS, maxinflightmbbytes=MAXINFLIGHTMBBYTES,
                                                mapping_type='standard',
                                                delivery_bucket=deliveryS3BucketName,
                                                transfer_profile=transferProfile)
    mappingEntry = generalutils.get_mapping_record_in_table(dynamo, DYNAMO_MAPPING_TABLE, mappingId)
    accountMapping = {'accountMapping': mappingEntry}
    accountMapping_as_json = json.dumps(accountMapping, cls=generalutils.DecimalEncoder)

    LOGGER.debug(accountMapping_as_json)
    self.send_response(200)
    set_aws_content_headers(self, content_length=len(accountMapping_as_json))
    self.send_header('x-amzn-requestid', requestid)
    self.end_headers()
    self.wfile.write(bytes(accountMapping_as_json, "utf8"))
    return


def _handle_get_accountmappingpin_request(self):
    post_body = _get_body_contents(self)
    mappingId = post_body["mappingId"]
    # make sure mapping id is in a pending state
    dynamo = generalutils.get_dynamodb_client(generalutils.get_session(region=AWS_REGION))
    mappingEntry = generalutils.get_mapping_record_in_table(dynamo, DYNAMO_MAPPING_TABLE, mappingId)
    if mappingEntry.get('mappingStatus', None) is None:
        _generate_mapping_id_doesnotexist_exception_response(self, post_body)
        return
    accountMapping = {'mappingPin': mappingEntry['pin']}
    accountMapping_as_json = json.dumps(accountMapping, cls=generalutils.DecimalEncoder)

    LOGGER.debug(accountMapping_as_json)
    self.send_response(200)
    set_aws_content_headers(self, content_length=len(accountMapping_as_json))
    self.end_headers()
    self.wfile.write(bytes(accountMapping_as_json, "utf8"))
    return


def _handle_accept_accountmapping_request(self):
    global mapping_dictionary, TPS_limiter_Per_Mapping

    post_body = _get_body_contents(self)
    mappingId = post_body["mappingId"]
    roleArn = post_body["roleArn"]
    alias = post_body.get("alias", None)
    pin = post_body["pin"]

    if roleArn != 'arn:localhost:iam::' + AWS_ACCOUNT_NUM + ':role/diode-sender-role':
        _generate_create_mapping_id_exception_response(self, post_body, 'roleArn',
                                                       'must have value of \'arn:localhost:iam::' + AWS_ACCOUNT_NUM +
                                                       ':role/diode-sender-role\'')
        return
    dynamo = generalutils.get_dynamodb_client(generalutils.get_session(region=AWS_REGION))
    mappingEntry = generalutils.get_mapping_record_in_table(dynamo, DYNAMO_MAPPING_TABLE, mappingId)
    if mappingEntry.get('mappingStatus', None) is None or mappingEntry['mappingStatus'] != 'PENDING_ACCEPTANCE':
        _generate_mapping_id_doesnotexist_exception_response(self, post_body)
        return
    if mappingEntry['pin'] != pin:
        _generate_mapping_id_doesnotexist_exception_response(self, post_body)
        return
    if alias is not None and mappingEntry['mappingAlias'] != alias:
        _generate_create_mapping_id_exception_response(self, post_body, 'mappingAlias',
                                                       'must have value of \'' + mappingEntry['mappingAlias'] + '\'')
        return
    # all is good so accept it - remove the pin - we don't want to update the pin
    mappingEntry.pop('pin', None)
    mappingEntry["roleArn"] = roleArn   # rewrite the role to a receiver role
    mappingEntry["mappingStatus"] = 'ACCEPTED'
    LOGGER.debug(f"mappingEntry to update dynamodb={mappingEntry}")
    response = generalutils.update_mapping_record_in_table(dynamo, DYNAMO_MAPPING_TABLE, mappingEntry)
    status = response['ResponseMetadata']['HTTPStatusCode']
    LOGGER.debug(f"HTTPStatusCode={status}from mapping update {response}")
    if status != 200:
        _generate_invalidrequest_exception_response(self)
        return

    # dynamo.meta.client.update_item(TableName=DYNAMO_MAPPING_TABLE, Key={'mappingId': mappingId},
    # UpdateExpression = 'REMOVE pin')
    mappingEntry = generalutils.get_mapping_record_in_table(dynamo, DYNAMO_MAPPING_TABLE, mappingId)
    LOGGER.debug(f"mappingEntry re-read from dynamodb={mappingEntry}")
    accountMapping = {'accountMapping': mappingEntry}
    accountMapping_as_json = json.dumps(accountMapping, cls=generalutils.DecimalEncoder)

    # update in memory table since we have a new mapping that has been accepted
    TPS_limiter_Per_Mapping[mappingId] = setup_tps_rate_limiter_bucket(tps=mappingEntry['TPS'])
    # remove mapping id from mapping entry to store in in-memory table
    mappingEntry_no_mapping_id = mappingEntry
    mappingEntry_no_mapping_id.pop('mappingId', None)

    # update the global MB in flight array to add this - we need to get a lock on this puppy
    # and set it to zero since it is a new mapping and nothing is in flight yet.
    with TOTALBYTESINFLIGHTLOCK:
        global total_MB_in_flight
        total_MB_in_flight[mappingId] = 0
    # we add to the mapping dictionary after all other operations have completed
    mapping_dictionary[mappingId] = mappingEntry_no_mapping_id
    LOGGER.info(f"mapping id {mappingId} added to in memory mapping_dictionary")
    LOGGER.debug(f"updated mapping_dictionary={mapping_dictionary}")

    LOGGER.debug(f"New account mapping record created/accepted {accountMapping_as_json}")
    self.send_response(200)
    set_aws_content_headers(self, content_length=len(accountMapping_as_json))
    self.end_headers()
    self.wfile.write(bytes(accountMapping_as_json, "utf8"))
    return


def _handle_delete_accountmapping_request(self):
    post_body = _get_body_contents(self)
    mappingId = post_body["mappingId"]

    dynamo = generalutils.get_dynamodb_client(generalutils.get_session(region=AWS_REGION))
    mappingEntry = generalutils.get_mapping_record_in_table(dynamo, DYNAMO_MAPPING_TABLE, mappingId)
    if mappingEntry.get('mappingStatus', None) is None or mappingEntry['mappingStatus'] != 'ACCEPTED':
        _generate_mapping_id_doesnotexist_exception_response(self, post_body)
        return
    # all is good so delete it - change its status to DELETED
    mappingEntry["mappingStatus"] = 'DELETED'
    generalutils.update_mapping_record_in_table(dynamo, DYNAMO_MAPPING_TABLE, mappingEntry)
    mappingEntry = generalutils.get_mapping_record_in_table(dynamo, DYNAMO_MAPPING_TABLE, mappingId)
    accountMapping = {'accountMapping': mappingEntry}
    accountMapping_as_json = json.dumps(accountMapping, cls=generalutils.DecimalEncoder)

    # update the in memory tables to reflect this mapping as deleted
    deleted_mapping_id = mapping_dictionary.pop(mappingId)
    _ = TPS_limiter_Per_Mapping.pop(mappingId)
    # update the global MB in flight array to remove this mapping counter
    with TOTALBYTESINFLIGHTLOCK:
        global total_MB_in_flight
        _ = total_MB_in_flight.pop(mappingId)
    LOGGER.info(f"In memory tables updated to support deletion of account mapping {deleted_mapping_id}")

    LOGGER.debug(f"Account mapping record deleted {accountMapping_as_json}")
    self.send_response(200)
    set_aws_content_headers(self, content_length=len(accountMapping_as_json))
    self.end_headers()
    self.wfile.write(bytes(accountMapping_as_json, "utf8"))
    return


def get_size_s3_object(bucket, object_name):
    s3resource = generalutils.get_s3_client(generalutils.get_session(region=AWS_REGION))
    try:
        response = s3resource.meta.client.head_object(Bucket=bucket, Key=object_name)
    except Exception as e:
        LOGGER.info(f"Could not find object with name {object_name}, may not exist - exception {e}.")
        return -1
    return_code = response['ResponseMetadata']['HTTPStatusCode']
    if return_code == 200:
        return response['ContentLength']
    else:
        LOGGER.info(f"response on size query of S3 object is {return_code}")
        return -1


def mark_transfer_succeeded(transfer_id=None, event=None,
                            hash_algorithm=None, hash_value=None):
    if transfer_id is None or event is None:
        LOGGER.error(f"mark_transfer_succeeded transfer_id and/or event arguments not provided.")
        return
    dynamo = generalutils.get_dynamodb_client(generalutils.get_session(region=AWS_REGION))
    table = dynamo.Table(DYNAMO_TRANSFER_TABLE)
    LOGGER.debug("mark_transfer_succeeded event passed=%s" % event)
    try:
        response = table.get_item(
            Key={
                'transferId': transfer_id}
        )
    except ClientError as e:
        LOGGER.error(e.response['Error']['Message'])
        return
    item = response['Item']
    previousstatus = item['status']
    date_received = generalutils.get_current_time_in_diode_format()
    _ = table.update_item(
        Key={
            'transferId': transfer_id
        },
        UpdateExpression="set #status = :s, dateReceived = :d",
        ExpressionAttributeNames={'#status': 'status'},
        ExpressionAttributeValues={':s': 'SUCCEEDED',
                                   ':d': date_received},
        ReturnValues="UPDATED_NEW"
    )
    # generate an event from this action to simulate cloudwatch events
    generate_cloudwatch_event(event=event, previous_status=previousstatus,
                              hash_algorithm=hash_algorithm, hash_value=hash_value)
    return


def mark_transfer_rejected(transfer_id=None, event=None):
    if transfer_id is None or event is None:
        LOGGER.error(f"mark_transfer_rejected transfer_id and/or event arguments not provided.")
        return
    dynamo = generalutils.get_dynamodb_client(generalutils.get_session(region=AWS_REGION))
    table = dynamo.Table(DYNAMO_TRANSFER_TABLE)
    LOGGER.debug("mark_transfer_rejected event passed=%s" % event)
    try:
        response = table.get_item(
            Key={
                'transferId': transfer_id}
        )
    except ClientError as e:
        LOGGER.error(e.response['Error']['Message'])
        return
    item = response['Item']
    previous_status = item['status']
    date_received = generalutils.get_current_time_in_diode_format()
    _ = table.update_item(
        Key={
            'transferId': transfer_id
        },
        UpdateExpression="set #status = :s, dateReceived = :d, errorMessage = :e",
        ExpressionAttributeNames={'#status': 'status'},
        ExpressionAttributeValues={
            ':s': 'REJECTED',
            ':d': date_received,
            ':e': 'Transfer failed inspection'},
        ReturnValues="UPDATED_NEW"
    )
    # generate an event from this action to simulate cloudwatch events
    generate_cloudwatch_event(event=event, previous_status=previous_status)
    return


def mark_transfer_failed(transfer_id=None, event=None, optional_msg=None):
    if transfer_id is None or event is None:
        LOGGER.error(f"mark_transfer_failed transfer_id and/or event arguments not provided.")
        return
    dynamo = generalutils.get_dynamodb_client(generalutils.get_session(region=AWS_REGION))
    table = dynamo.Table(DYNAMO_TRANSFER_TABLE)
    LOGGER.debug("mark_transfer_failed event passed=%s" % event)
    try:
        response = table.get_item(
            Key={
                'transferId': transfer_id}
        )
    except ClientError as e:
        LOGGER.info(e.response['Error']['Message'])
        return
    item = response['Item']
    previous_status = item['status']
    date_received = generalutils.get_current_time_in_diode_format()
    msg = 'failure error - details in simulator harness'
    if optional_msg is not None:
        msg = optional_msg
    _ = table.update_item(
        Key={
            'transferId': transfer_id
        },
        UpdateExpression="set #status = :s, dateReceived = :d, errorMessage = :e",
        ExpressionAttributeNames={'#status': 'status'},
        ExpressionAttributeValues={
            ':s': 'FAILED',
            ':d': date_received,
            ':e': msg},
        ReturnValues="UPDATED_NEW"
    )
    # generate an event from this action to simulate cloudwatch events
    generate_cloudwatch_event(event=event, previous_status=previous_status)
    return


def set_aws_content_headers(self, content_length=None):
    self.send_header('Content-type', 'application/x-amz-json-1.1')
    if content_length:
        self.send_header('Content-length', int(content_length))


def generate_cloudwatch_event(event=None, previous_status=None, hash_algorithm=None, hash_value=None):
    """
    {"version":"0",
        "id":"5c13d51a-a895-d306-fba7-43617299aa8e",
        "detail-type":"Diode Transfer Status",
        "source":"diode.simulator",
        "account":"550654321126",
        "time":"2019-06-01T17:49:26Z",
        "region":"us-east-1",
        "resources":
            [   "arn:aws:diode:localhost:123456789012:account-mapping/12346789-abcd-1234-abcd-123456789012",
                "arn:aws:diode:localhost:123456789012:transfer/7f2c0242-a1fd-4cfc-bb64-9664ccf896df"
            ],
        "detail":{
            "mappingId":"12346789-abcd-1234-abcd-123456789012",
            "s3Uri":"https://tonydahb-largefiles.s3.amazonaws.com/100mb.txt",
            "s3Key":"100mb.txt",
            "s3Bucket":"tonydahb-largefiles",
            "fileSize":105001050,
            "dateReceived":"2019-06-01T13:49:26",
            "description":"test",
            "transferId":"7f2c0242-a1fd-4cfc-bb64-9664ccf896df",
            "dateSent":"2019-06-01T13:49:23",
            "status":"SUCCEEDED",
            "previousStatus":"IN_TRANSIT"
        }
    }
    :return: nothing
    """
    # go read the dynamo record for all the details
    dynamo = generalutils.get_dynamodb_client(generalutils.get_session(region=AWS_REGION))
    table = dynamo.Table(DYNAMO_TRANSFER_TABLE)
    try:
        response = table.get_item(
            Key={
                'transferId': event['transferId']}
        )
    except ClientError as e:
        LOGGER.error(e.response['Error']['Message'])
        return
    item = response['Item']
    LOGGER.debug(json.dumps(item, indent=4, cls=generalutils.DecimalEncoder))
    cloudwatch_events = generalutils.get_cloudwatch_events_client(generalutils.get_session(region=AWS_REGION))
    json_detail = {'mappingId': item['mappingId'],
                   's3Uri': event['s3Uri'],
                   's3Key': event['key'],
                   's3Bucket': event['bucket'],
                   'fileSize': int(event['size']),
                   'dateReceived': item['dateReceived'],
                   'description': item['description'],
                   'transferId': event['transferId'],
                   'dateSent': item['dateSent'],
                   'status': item['status'],
                   'previousStatus': previous_status}
    # add in the hash code calculations if computed
    if hash_algorithm is not None and hash_value is not None:
        json_detail['fileHashAlgorithm'] = hash_algorithm
        json_detail['fileComputedHash'] = hash_value
    response = cloudwatch_events.put_events(Entries=[
        {
            'Detail': json.dumps(json_detail, cls=generalutils.DecimalEncoder),
            'DetailType': 'Diode Transfer Status',
            'Resources': [
                event['mappingArn'], event['transferArn']
            ],
            'Source': CLOUDWATCH_EVENTS_SOURCE
        }]
    )
    LOGGER.debug("completed generate cloudwatch event response=%s" % response)
    LOGGER.debug(f"generated cloudwatch event detail="
                 f"{json.dumps(json_detail, cls=generalutils.DecimalEncoder)}")
    return


def random_transfer_failure():
    """
    Use a random number to see if a failure should occur, return True if a failure should occur, False otherwise
    If Global RANDOM_FAILURES is False then always return False
    :return: True if a failure should occur, False otherwise
    """
    failure_random_value = randint(0, 4000)
    if RANDOM_FAILURES and failure_random_value < 1000:
        LOGGER.info("CDS-random transfer failures option is enabled and one is being generated due to random value...")
        return True
    return False


def get_remaining_calls_to_createTransfer(mapping_id):
    """
    Returns how many actual additional calls can be made against the API before a throttling exception will occue
    :return: number of calls that can be made
    """
    return TPS_limiter_Per_Mapping.get(mapping_id, None).get('per_second')
    # return TPS_limiter.get('per_second')


def simulator_cds_handler():
    """
    Query for jobs waiting transfer of data from SQS and
    do the transfer from S3 to S3 then update the dynamodb record to reflect the status of the transfer.
    :return: runs continuously until told to stop by setting global variable MOVER_THREAD_KEEP_RUNNING to False
    """
    # declare a cDSValidator instance for this cds_handler
    cds_validator = CDSValidator(aws_region=AWS_REGION, logger=LOGGER,
                                 xsd_directory=XSD_DIRECTORY,
                                 suffixes_directory=ALLOWED_FILE_SUFFIX_DIR)
    s3 = generalutils.get_s3_client(generalutils.get_session(region=AWS_REGION))
    sqs = generalutils.get_sqs_client(generalutils.get_session(region=AWS_REGION))
    # Get the queue
    queue = sqs.get_queue_by_name(QueueName=SQS_QUEUE_NAME)
    global MOVER_THREAD_KEEP_RUNNING

    while MOVER_THREAD_KEEP_RUNNING:
        try:
            # long poll SQS - wait up to 10 seconds
            received_sqs_event_messages = queue.receive_messages(MaxNumberOfMessages=1,
                                                                 WaitTimeSeconds=10)
            num_messages = len(received_sqs_event_messages)
            if num_messages > 0:
                # process a message
                for message in received_sqs_event_messages:
                    LOGGER.debug(message)
                    event = json.loads(message.body)
                    transfer_id = event.get('transferId', None)
                    s3key = event.get('key', None)
                    s3bucket = event.get('bucket', None)
                    mapping_id = event.get('mappingId', None)
                    if not transfer_id or not s3key or not s3bucket or not mapping_id:
                        LOGGER.error(f"CDS - Bad message received from the queue - "
                                     f"one or more critcal fields missing {message}")
                        message.delete()
                        continue
                    try:
                        delivery_bucket = mapping_dictionary[mapping_id]['receivingBucket']
                        if delivery_bucket == 'N/A':
                            delivery_bucket = S3_HIGH_BUCKET
                        LOGGER.debug(f"CDS delivery bucket for {transfer_id} transfer is {delivery_bucket}")
                        transfer_profile = mapping_dictionary[mapping_id].get("transferProfile", "CDS_1")
                        LOGGER.debug(f"CDS Transfer profile for mapping id {mapping_id} is {transfer_profile}")
                        if mapping_dictionary[mapping_id]['mappingType'] == 'standard':
                            handle_standard_transfer(event, s3, s3bucket, s3key,
                                                     mapping_id, transfer_profile,
                                                     transfer_id,
                                                     delivery_bucket=delivery_bucket,
                                                     cds_validator=cds_validator)
                        else:
                            # we are handling a software artifacts transfer
                            handle_software_artifacts_transfer(event, s3, s3bucket, s3key,
                                                               mapping_id, transfer_profile,
                                                               transfer_id,
                                                               delivery_bucket=delivery_bucket,
                                                               cds_validator=cds_validator)
                    except Exception as e:
                        LOGGER.info(f"CDS transfer handler thread had an exception {e}")
                    message.delete()
        except Exception as e:
            LOGGER.info(f"CDS thread had an exception {e}")


def handle_standard_transfer(event, s3, s3bucket, s3key, mapping_id, transfer_profile,
                             transfer_id, delivery_bucket=S3_HIGH_BUCKET, cds_validator=None):
    # get true object size, so we can update the bytes in flight properly
    actual_obj_size = int(event['size'])
    obj_size_bytes = get_size_s3_object(s3bucket, s3key)
    includeS3ObjectTags = event.get('includeS3ObjectTags', False)
    if obj_size_bytes == -1:
        update_bytes_in_flight(mapping_id, -actual_obj_size)
        mark_transfer_failed(transfer_id=transfer_id, event=event)
        LOGGER.error(f"CDS - object {s3key} failed to obtain size.")
        return
    allowed = cds_validator.validate_standard_transfer(s3bucket=s3bucket, s3key=s3key,
                                                       mapping_id=mapping_id,
                                                       transfer_profile=transfer_profile)
    if not allowed:
        mark_transfer_rejected(transfer_id=transfer_id, event=event)
        LOGGER.info(f"CDS - object {s3key} rejected.")
    else:
        # try to move the file
        # induce a random failure?
        if random_transfer_failure():
            mark_transfer_failed(transfer_id=transfer_id, event=event)
            LOGGER.info(f"CDS - random failure triggered for transfer_id {transfer_id} and key {s3key}")
        else:
            s3resource = s3
            if CROSSACCOUNTROLEARN and CROSSACCOUNTHIGHBUCKET:
                # get modified cross account s3 resource and name of bucket in other account
                delivery_bucket = CROSSACCOUNTHIGHBUCKET
                s3resource = generalutils.get_assumed_s3_role(generalutils.get_session(region=AWS_REGION),
                                                              role_arn=CROSSACCOUNTROLEARN)
            # ensure destination bucket exists
            try:
                s3resource.meta.client.head_bucket(Bucket=delivery_bucket)
            except ClientError:
                # does not exist
                LOGGER.error(f"destination bucket {delivery_bucket} "
                             f"does not exist-failing transfer id {transfer_id}")
                mark_transfer_failed(transfer_id=transfer_id, event=event,
                                     optional_msg='failure error destination bucket problem')
                return

            # Calculate HASH384
            hash_algorithm = "SHA384"
            hash_value = hashlib.sha384()
            # Loop through and read 64MB at a time of the file and compute the hash
            read_block_size_hashes = 67108864   # 64MiB reads at a time
            start_bytes = list(range(0, obj_size_bytes, read_block_size_hashes))
            stop_bytes = [min(obj_size_bytes - 1, start_byte +
                              (read_block_size_hashes - 1)) for start_byte in start_bytes]
            # list of range tuples = [(1,(start1,stop1)), ..., (N, (start-N, stop-N))]
            # change the enumeration index to start at 1 since s3 multipart part numbers begin at 1.
            ranges = list(enumerate(list(zip(start_bytes, stop_bytes)), 1))
            LOGGER.debug(f"CDS - calculating hash384 value for standard diode transfer.")
            try:
                for r in ranges:
                    startrange = r[1][0]
                    endrange = r[1][1]
                    bytes_read = s3resource.meta.client.get_object(Bucket=s3bucket, Key=s3key,
                                                                   Range="bytes=%d-%d" % (startrange, endrange))["Body"].read()
                    hash_value.update(bytes_read)
                readable_hash_value = hash_value.hexdigest()
                LOGGER.info(f"CDS - object {s3key} SHA384 hash calculated as {readable_hash_value}")
            except Exception as e:
                readable_hash_value = None
                LOGGER.error(f"CDS - object {s3key} SHA384 hash unable to be calculated - exception {e}")
            # now start the actual transfer
            transfer_start_time = time.time()
            move_ok = generalutils.copy_s3_object(s3resource=s3resource,
                                                  source_bucket=s3bucket,
                                                  destination_bucket=delivery_bucket,
                                                  src_object_name=s3key,
                                                  mapping_id=mapping_id,
                                                  dst_object_name=None,
                                                  include_s3_tags=includeS3ObjectTags,
                                                  logger=LOGGER)
            transfer_duration = time.time() - transfer_start_time
            if move_ok:
                mark_transfer_succeeded(transfer_id=transfer_id, event=event,
                                        hash_algorithm=hash_algorithm, hash_value=readable_hash_value)
                LOGGER.info(f"CDS - object {s3key} successfully transferred, "
                            f"transfer duration = {transfer_duration} seconds.")
            else:
                mark_transfer_failed(transfer_id=transfer_id, event=event)
    update_bytes_in_flight(mapping_id, -actual_obj_size)


def handle_software_artifacts_transfer(event, s3, s3bucket, s3key, mapping_id, transfer_profile,
                                       transfer_id, delivery_bucket=S3_HIGH_BUCKET,
                                       cds_validator=None):
    """
    This method handle software artifacts type transfers. This is a Diode
    whitelist only service, but it is supported in the simulator. This simulator
    does not validate the manifest against the payload (ensure hashes match)
    or does it verify the manifest against the XSD for manifest files. This
    code will leave a payload in the destination bucket if the manifest
    fails to copy for some reason (there is no cleanup of the destination for
    a partial fail).
    :param event:
    :param s3: s3 client
    :param s3bucket: the bucket the payload and manifest reside
    :param s3key: the object name of the payload
    :param mapping_id: the mapping id associated with this transfer
    :param transfer_profile: the transfer profile of this mapping
    :param transfer_id: the transfer id associated with this transfer
    :param delivery_bucket:
    :param cds_validator:
    :return: nothing is returned, message is deleted off the queue regardless
    """
    LOGGER.info(f"CDS - software artifacts event={event}")
    actual_obj_size = int(event['size'])
    obj_size_bytes = get_size_s3_object(s3bucket, s3key)
    includeS3ObjectTags = event.get('includeS3ObjectTags', False)
    if obj_size_bytes == -1:
        update_bytes_in_flight(mapping_id, -actual_obj_size)
        mark_transfer_failed(transfer_id=transfer_id, event=event)
        LOGGER.error(f"CDS - object {s3key} failed to obtain size.")
        return
    # need to get manifest from tags in the dynamodb record for the transfer
    dynamo = generalutils.get_dynamodb_client(generalutils.get_session(region=AWS_REGION))
    transfer_tags_json = generalutils.get_transfer_tags_in_table(dynamo, DYNAMO_TRANSFER_TABLE, transfer_id)
    LOGGER.info(f"CDS - transfer tags={transfer_tags_json}")
    tags = transfer_tags_json.get('tags', None)
    if tags:
        manifest_name = tags.get(SOFTWARE_ARTIFACTS_MANIFEST_TAG, None)
        # manifest_name = transfer_tags_json.get(SOFTWARE_ARTIFACTS_MANIFEST_TAG, None)
        if not manifest_name:
            LOGGER.info(f"CDS - Unable to obtain manifest name from transfer id {transfer_id} "
                        f"tag of {SOFTWARE_ARTIFACTS_MANIFEST_TAG}")
            update_bytes_in_flight(mapping_id, -obj_size_bytes)
            return
    else:
        # uh oh tags for payload is missing...
        LOGGER.info(f"CDS - Unable to obtain manifest name from transfer id {transfer_id} ")
        update_bytes_in_flight(mapping_id, -obj_size_bytes)
        return

    # Make sure both the payload and the manifest file exist - by doing quick size check on manifest
    if get_size_s3_object(s3bucket, manifest_name) == -1:
        mark_transfer_failed(transfer_id=transfer_id, event=event)
    else:
        allowed = cds_validator.validate_software_artifacts_transfer(s3bucket=s3bucket,
                                                                     s3key=s3key,
                                                                     manifest_key=manifest_name,
                                                                     mapping_id=mapping_id,
                                                                     transfer_profile=transfer_profile)
        if not allowed:
            mark_transfer_rejected(transfer_id=transfer_id, event=event)
            LOGGER.info(f"CDS - object {s3key}, manifest: {manifest_name} rejected.")
            update_bytes_in_flight(mapping_id, -obj_size_bytes)
            return
        # handle the simulation of a software artifacts transfer
        LOGGER.info(f"CDS - Software Artifacts transfer bucket: {s3bucket}, "
                    f"payload: {s3key}, manifest: {manifest_name}")
        s3resource = s3
        if CROSSACCOUNTROLEARN and CROSSACCOUNTHIGHBUCKET:
            delivery_bucket = CROSSACCOUNTHIGHBUCKET
            s3resource = generalutils.get_assumed_s3_role(generalutils.get_session(region=AWS_REGION),
                                                          role_arn=CROSSACCOUNTROLEARN)
        # ensure destination bucket exists
        try:
            s3resource.meta.client.head_bucket(Bucket=delivery_bucket)
        except ClientError:
            # does not exist
            LOGGER.error(f"destination bucket {delivery_bucket} "
                         f"does not exist-failing transfer id {transfer_id}")
            mark_transfer_failed(transfer_id=transfer_id, event=event,
                                 optional_msg='failure error destination bucket problem')
            return
        transfer_start_time = time.time()
        if generalutils.copy_s3_object_manifest(s3resource=s3resource,
                                                source_bucket=s3bucket,
                                                destination_bucket=delivery_bucket,
                                                src_payload_name=s3key,
                                                src_manifest_name=manifest_name,
                                                mapping_id=mapping_id,
                                                transfer_id=transfer_id,
                                                include_s3_tags=includeS3ObjectTags,
                                                logger=LOGGER):
            transfer_duration = time.time() - transfer_start_time
            mark_transfer_succeeded(transfer_id, event)
            LOGGER.info(f"CDS - object {s3key} and manifest {manifest_name} successfully "
                        f"transferred, transfer duration = {transfer_duration} seconds.")
        else:
            mark_transfer_failed(transfer_id=transfer_id, event=event)
    update_bytes_in_flight(mapping_id, -obj_size_bytes)
    return


def setup_tps_rate_limiter_bucket(tps=1.0):
    transfers_per_sec = float(tps)
    # setup rate limiter with proper values based on value of tps
    if transfers_per_sec < 1:
        per_second_multiplier = 1 / transfers_per_sec
    else:
        per_second_multiplier = 1

    tps_rate_of = Bucket.builder()

    # TPS_rate_of = Bucket.builder()
    # TPS_limiter = RateLimiter(per_second=TPS_rate_of(TPS * per_second_multiplier, Per.SECOND * per_second_multiplier))
    # Since our rate limiter wants intervals in whole numbers as seconds and
    # default TPS is 1 (used to be 0.25) we adjust as
    # show below for higher rates like 1 or 2 TPS use tps_rate_of(1 or 2, Per.Second)
    # TPS_limiter = RateLimiter(per_second=TPS_rate_of(TPS*4, Per.SECOND*4))
    # Name of our rate limiter bucket is 'mappingId'
    tps_limiter_rate_limiter = RateLimiter(mappingId=tps_rate_of(transfers_per_sec * per_second_multiplier,
                                                                 Per.SECOND * per_second_multiplier))
    return tps_limiter_rate_limiter


def setup_mapping_tracker():
    """
    Read all the mappings in the table and build our dictionary with limits for each mapping and the
    type of mapping (standard or software).  Throttles are now based on mapping limits.
    This code must also deal with the paged results from the method it calls so it will spit out a warning if more
    than 200 mappings are in the system-this is a simulator and should not have 200 mappings.
    TODO add support for reading paged mappings to support as many as in the system
    :return:
    """
    dynamo = generalutils.get_dynamodb_client(generalutils.get_session(region=AWS_REGION))
    scanparams = {'Limit': 200}
    mappingsjson = generalutils.get_all_mappings_table(dynamo, DYNAMO_MAPPING_TABLE, **scanparams)
    if mappingsjson.get('nextToken', None) is not None:
        LOGGER.info('Found more than 200 mappings - only the first 200 will be used - this is a simulator!!')
    mapping_dict = {}
    for mapping in mappingsjson['accountMappingList']:
        if mapping['mappingStatus'] == 'ACCEPTED':
            mapping_dict[mapping['mappingId']] = mapping
    # mapping_dictionary = {i['mappingId']: i for i in jsontext['accountMappingList']}
    # mapping_dictionary now contains a dictionary with mapping id as key and all the mapping
    # info as a value -> print(d['12346789-abcd-1234-abcd-123456789012']['mappingType']) results in:
    # standard
    # 'receivingRegion': 'localhost', 'softwareArtifactsMaxFileSizeMB': Decimal('30720'),
    # 'mappingOwnerArn': 'arn:aws:iam::123456789012:root', 'sendingRegion': 'localhost',
    # 'maxInFlightMB': Decimal('200'),
    # 'mappingArn': 'arn:aws:diode:localhost:123456789012:account-mapping/12346789-abcd-1234-abcd-123456789012',
    # 'mappingAlias': 'myalias', 'mappingStatus': 'ACCEPTED',
    # 'softwareArtifactsMaxFilesInFlight': Decimal('2'),
    # 'roleArn': 'arn:localhost:iam::123456789012:role/diode-sender-role',
    # 'pin': '234567', 'TPS': Decimal('0.25'), 'mappingType': 'standard',
    # 'mappingId': '12346789-abcd-1234-abcd-123456789012',
    # 'maxFileSizeMB': Decimal('100'), 'dateMappingCreated': Decimal('1574460639.5099999904632568359375')}
    # Remove the mappingId from the values of the dict since it is the key
    for v in mapping_dict.values():
        v.pop('mappingId', None)

    # Build a TPS Dictionary with the mappingIds as the key
    tps_limiter = {}
    for mappingId in mapping_dict:
        tps_limiter[mappingId] = setup_tps_rate_limiter_bucket(tps=mapping_dict[mappingId]['TPS'])

    # Build a total MB in flight array with mappingId as the key and a value
    # of 0 for each id (0 MB in flight to start)
    sum_MB_in_flight = {mappingId: 0 for mappingId in mapping_dict}

    LOGGER.info(f"mapping tracker built - total of {len(mapping_dict)} active mappings in table.")
    return mapping_dict, tps_limiter, sum_MB_in_flight


def setup_properties_from_file(prop_file):
    global HARNESS_LISTENER_PORT, RANDOM_FAILURES, DYNAMO_TRANSFER_TABLE, \
        DYNAMO_MAPPING_TABLE, DYNAMO_MANIFEST_TABLE, SQS_QUEUE_NAME, S3_LOW_BUCKET, \
        S3_HIGH_BUCKET, MANIFEST_STORAGE_BUCKET, MAXFILESIZEMB, MAXINFLIGHTMBBYTES, \
        NUM_MOVER_THREADS, TPS, CLOUDWATCH_EVENTS_SOURCE, AWS_REGION, ALLOWED_FILE_SUFFIX_DIR, \
        CROSSACCOUNTROLEARN, CROSSACCOUNTHIGHBUCKET, S3_DNS_SUFFIX, ALLBUCKETSACCESS, SWAMSHASHCONTROLLERLAMBDA

    config = configparser.RawConfigParser()
    try:
        config.read(prop_file)
        HARNESS_LISTENER_PORT = generalutils.environment_value_as_type(config.get('diodeSimulator',
                                                                                  'HARNESS_LISTENER_PORT'),
                                                                       type=int, default=8080)
        RANDOM_FAILURES = generalutils.environment_value_as_type(config.get('diodeSimulator', 'RANDOM_FAILURES'),
                                                                 type=bool, default=False)
        DYNAMO_TRANSFER_TABLE = config.get('diodeSimulator', 'DYNAMO_TRANSFER_TABLE')
        DYNAMO_MAPPING_TABLE = config.get('diodeSimulator', 'DYNAMO_MAPPING_TABLE')
        DYNAMO_MANIFEST_TABLE = config.get('diodeSimulator', 'DYNAMO_MANIFEST_TABLE')
        SQS_QUEUE_NAME = config.get('diodeSimulator', 'SQS_QUEUE_NAME')
        S3_LOW_BUCKET = config.get('diodeSimulator', 'S3_LOW_BUCKET')
        S3_HIGH_BUCKET = config.get('diodeSimulator', 'S3_HIGH_BUCKET')
        MANIFEST_STORAGE_BUCKET = config.get('diodeSimulator', 'MANIFEST_STORAGE_BUCKET')
        MAXFILESIZEMB = generalutils.environment_value_as_type(config.get('diodeSimulator', 'MAXFILESIZEMB'),
                                                               type=int, default=100)
        NUM_MOVER_THREADS = generalutils.environment_value_as_type(config.get('diodeSimulator', 'NUM_MOVER_THREADS'),
                                                                   type=int, default=1)
        TPS = generalutils.environment_value_as_type(config.get('diodeSimulator', 'TPS'), type=float, default=1.0)
        CLOUDWATCH_EVENTS_SOURCE = generalutils.environment_value_as_type(config.get('diodeSimulator',
                                                                                     'CLOUDWATCH_EVENTS_SOURCE'),
                                                                          type=str, default=CLOUDWATCH_EVENTS_SOURCE)
        AWS_REGION = generalutils.environment_value_as_type(config.get('diodeSimulator', 'AWS_REGION'), type=str,
                                                            default=AWS_REGION)
        MAXINFLIGHTMBBYTES = generalutils.environment_value_as_type(config.get('diodeSimulator', 'MAXINFLIGHTMBBYTES'),
                                                                    type=int, default=MAXINFLIGHTMBBYTES)
        S3_DNS = config.get('diodeSimulator', 'S3_DNS', fallback=S3_DNS_SUFFIX)
        # get the suffix (eliminate the bucket name and dot after it)
        S3_DNS_SUFFIX = S3_DNS.partition('.')[2]
        CROSSACCOUNTROLEARN = config.get('diodeSimulator', 'CROSSACCOUNTROLEARN', fallback=None)
        CROSSACCOUNTHIGHBUCKET = config.get('diodeSimulator', 'CROSSACCOUNTHIGHBUCKET', fallback=None)
        ALLBUCKETSACCESS = generalutils.environment_value_as_type(config.get('diodeSimulator',
                                                                             'ALLBUCKETSACCESS'),
                                                                  type=bool, default=False)
        ALLOWED_FILE_SUFFIX_DIR = generalutils.environment_value_as_type(config.get('diodeSimulator',
                                                                                    'ALLOWED_FILE_SUFFIX_DIR'),
                                                                         type=str)
        SWAMSHASHCONTROLLERLAMBDA = config.get('diodeSimulator', 'SWAMSHASHCONTROLLERLAMBDA', fallback=None)
        return True
    except configparser.Error as e:
        LOGGER.error(f"Error reading property file {prop_file}: {e}")
    return False


def setup_simulator_globals(property_filename=PROPERTY_FILE):
    global mapping_dictionary, TPS_limiter_Per_Mapping, total_MB_in_flight, \
        MOVER_THREAD_KEEP_RUNNING

    # configure globals from properties in properties file
    if not setup_properties_from_file(property_filename):
        return False

    LOGGER.info(f"Server starting up with the following properties:")
    LOGGER.info(f"HARNESS_LISTENER_PORT={HARNESS_LISTENER_PORT}")
    LOGGER.info(f"RANDOM_FAILURES={RANDOM_FAILURES}")
    LOGGER.info(f"DYNAMO_TRANSFER_TABLE={DYNAMO_TRANSFER_TABLE}")
    LOGGER.info(f"DYNAMO_MAPPING_TABLE={DYNAMO_MAPPING_TABLE}")
    LOGGER.info(f"DYNAMO_MANIFEST_TABLE={DYNAMO_MANIFEST_TABLE}")
    LOGGER.info(f"SQS_QUEUE_NAME={SQS_QUEUE_NAME}")
    LOGGER.info(f"S3_LOW_BUCKET={S3_LOW_BUCKET}")
    LOGGER.info(f"S3_HIGH_BUCKET={S3_HIGH_BUCKET}")
    LOGGER.info(f"MANIFEST_STORAGE_BUCKET={MANIFEST_STORAGE_BUCKET}")
    LOGGER.info(f"MAXFILESIZEMB(Individual object)={MAXFILESIZEMB}")
    LOGGER.info(f"NUM_MOVER_THREADS={NUM_MOVER_THREADS}")
    LOGGER.info(f"MAXINFLIGHTMBBYTES (in Transit)={MAXINFLIGHTMBBYTES}MB; Bytes in "
                f"Transit {MAXINFLIGHTMBBYTES * 1024 * 1024}")
    LOGGER.info(f"AWS_REGION={AWS_REGION}")
    LOGGER.info(f"Supported file suffix dir={ALLOWED_FILE_SUFFIX_DIR}")
    LOGGER.info(f"XSDs dir={XSD_DIRECTORY}")
    LOGGER.info(f"TPS={TPS}")
    LOGGER.info(f"S3_DNS_SUFFIX={S3_DNS_SUFFIX}")
    LOGGER.info(f"ALLBUCKETSACCESS={ALLBUCKETSACCESS}")
    LOGGER.info(f"SWAMSHASHCONTROLLERLAMBDA={SWAMSHASHCONTROLLERLAMBDA}")

    # setup Global variables to track mapping information, TPS, totalMB in flight per mapping
    mapping_dictionary, TPS_limiter_Per_Mapping, total_MB_in_flight = setup_mapping_tracker()
    LOGGER.debug(f"mapping_dictionary = {mapping_dictionary}")

    for mapping_id_log in mapping_dictionary:
        LOGGER.info(f"Mapping id: {mapping_id_log} type: "
                    f"{mapping_dictionary[mapping_id_log]['mappingType']} and "
                    f"is {mapping_dictionary[mapping_id_log]['mappingStatus']}")

    MOVER_THREAD_KEEP_RUNNING = True
    return True


if __name__ == "__main__":
    from sys import argv

    # Log levels are CRITICAL, ERROR, WARNING, INFO, DEBUG
    __LOG_LEVEL__ = logging.INFO

    LOGGER.setLevel(__LOG_LEVEL__)
    # Setup logging to proper file with rotations, add the log message handler to the logger
    handler = logging.handlers.RotatingFileHandler(LOG_FILENAME,
                                                   maxBytes=(1024 * 1024 * 4),
                                                   backupCount=2)
    # put timestamp and other info in log messages
    formatter = logging.Formatter('%(asctime)s : %(levelname)s : %(message)s')
    handler.setFormatter(formatter)
    LOGGER.addHandler(handler)

    LOGGER.info(f"Diode Simulator {__VERSION__} starting up.")
    # see if an argument of a property file has been provided
    if len(argv) == 2:
        property_file = argv[1]
        LOGGER.info(f"Using property file {property_file}.")
    else:
        property_file = PROPERTY_FILE
        LOGGER.error(f"Requires argument of property file to use, defaulting to {property_file}.")
        print(f"Requires argument of property file to use, defaulting to {property_file}.")

    if not setup_simulator_globals(property_filename=property_file):
        exit(1)

    httpd = None
    cds_threads = None
    manifest_generation_processors = None

    try:
        # Create a web server and define the handler to manage the
        # incoming request
        server_address = ('', HARNESS_LISTENER_PORT)
        # The following uses the python 3.9 threading mixin to support multi-threading connections
        httpd = ThreadingHTTPServer(server_address, DiodeSimulatorEndpointServerRequestHandler)

        # Start the indicated number of CDS threads
        cds_threads = []
        for i in range(0, NUM_MOVER_THREADS):
            cds_thread = threading.Thread(target=simulator_cds_handler, args=())
            cds_threads.append(cds_thread)
            cds_thread.start()
            LOGGER.info(f"Started cds thread number {i}")

        # start up a manifest generator thread
        manifest_generation_processors = []
        for i in range(0, NUM_MANIFEST_GENERATOR_THREADS):
            manifest_class = ManifestGenerator(aws_region=AWS_REGION,
                                               logger=LOGGER,
                                               manifest_bucket=MANIFEST_STORAGE_BUCKET,
                                               cloudwatch_events_source=CLOUDWATCH_EVENTS_SOURCE,
                                               dynamo_swams_table=DYNAMO_MANIFEST_TABLE,
                                               lambda_controller_arn=SWAMSHASHCONTROLLERLAMBDA)

            manifest_generation_processors.append(manifest_class)
            LOGGER.info(f"Started manifest generator handler number {i}")

        httpd.serve_forever()

    except KeyboardInterrupt:
        LOGGER.info("interrupted at keyboard with ctrl-c ^C received, shutting down the web server")
    finally:
        if httpd:
            httpd.socket.close()
        MOVER_THREAD_KEEP_RUNNING = False
        MANIFEST_GENERATOR_THREAD_KEEP_RUNNING = False
        wait_threads = 10
        LOGGER.info(f"Sleeping for {wait_threads} seconds to allow CDS and manifest generation "
                    "threads to finalize")
        time.sleep(wait_threads)
        if cds_threads:
            for i in range(0, NUM_MOVER_THREADS):
                cds_threads[i].join()
                LOGGER.info(f"mover thread number {i} stopped.")
        if manifest_generation_processors:
            for i in range(0, NUM_MANIFEST_GENERATOR_THREADS):
                manifest_generation_processors[i].shutdown()
                LOGGER.info(f"manifest generator thread number {i} stopped.")

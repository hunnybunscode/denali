import os
import sys
path = os.path.abspath(os.path.join(os.path.dirname(__file__), '../common_utils'))
if path not in sys.path:
    sys.path.insert(1, path)
import general_utils as generalutils
import lxml.etree as ET

__VERSION__ = 1.2


class CDSValidator:

    def __init__(self, aws_region='us-east-1', logger=None,
                 xsd_directory='/home/ec2-user/diodeSimulator/XSDs',
                 suffixes_directory='/home/ec2-user/diodeSimulator/allowed_file_suffixes'):
        self.aws_region = aws_region
        self.logger = logger
        self.xsd_directory = xsd_directory
        self.allowed_file_suffixes_directory = suffixes_directory
        self.logger.info(f"CDSValidator {__VERSION__}-class instantiated")

    def validate_standard_transfer(self, s3bucket=None, s3key=None, mapping_id='',
                                   transfer_profile='CDS_1'):
        allowed_file_suffixes = self._get_suffixes_for_mapping(mapping_id=mapping_id,
                                                               transfer_profile=transfer_profile)
        is_suffix_allowed = self._is_allowed_suffix(object_name=s3key,
                                                    allowed_file_suffixes=allowed_file_suffixes)
        suffix = self._get_suffix(object_name=s3key)
        # short circuit xml checking if not xml
        if suffix.lower() != 'xml':
            return is_suffix_allowed
        # handle XML case by checking against an xsd if one is present
        valid = self._validate_xml_against_xsd(s3bucket=s3bucket, s3key=s3key, mapping_id=mapping_id)
        return valid

    def validate_software_artifacts_transfer(self, s3bucket=None, s3key=None,
                                             manifest_key=None, mapping_id='',
                                             transfer_profile='CDS_1'):
        if manifest_key is None:
            return False
        manifest_suffix = self._get_suffix(manifest_key).lower()
        if manifest_suffix == 'xml':
            self.logger.info(f"CDSValidator-checking validity of manifest "
                             f"file {manifest_key} with suffix xml, allowed=True")
            valid = self.validate_tdf_manifest_against_xsd(s3bucket=s3bucket, s3key=manifest_key,
                                                           transfer_profile=transfer_profile)
            self.logger.debug(f"CDSValidator-Validation of manifest for "
                              f"transfer_profile {transfer_profile} against TDF XSD, valid={valid}")
            return valid
        else:
            self.logger.error(f"CDSValidator-manifest key={manifest_key} does not "
                              f"have a suffix of xml")
            return False

    def _get_suffixes_for_mapping(self, mapping_id=None, transfer_profile='CDS_1'):
        """
        If a mapping specific file is not found, then the default allowed types will
        be returned for the provided provided transfer profile. If this is not found
        then the base default_allowed_file_suffixes file will be used.
        if the mapping id is not passed then
        an empty set will be returned in effect failing all transfers since it is
        invalid to not provide a mapping id.
        This code will re-read the file suffixes for each validate request, future will
        look to cache the values but for now we did not want to have user have to restart
        the simulator if they changed the accepted file suffixes files.

        # True in list means that type is allowed, otherwise it is not allowed - will result in a reject
        # allowed_file_suffixes = {"txt": True, "jpg": True, "png": True}
        # allowed_file_suffixes = {} will mean no file suffixes will pass
        """
        if mapping_id is None:
            return {}
        allowed_file_suffixes_file = f"{self.allowed_file_suffixes_directory}/{mapping_id}"
        if not os.path.exists(allowed_file_suffixes_file):
            # see if a specific by transfer profile file exists
            allowed_file_suffixes_file = f"{self.allowed_file_suffixes_directory}/" \
                                         f"{transfer_profile.lower()}_default_allowed_file_suffixes"
            if not os.path.exists(allowed_file_suffixes_file):
                self.logger.debug(f"CDSValidator-transfer profile specific file not "
                                  f"found {allowed_file_suffixes_file}, checking for default_allowed_suffixes file.")
                allowed_file_suffixes_file = f"{self.allowed_file_suffixes_directory}/" \
                                             f"default_allowed_file_suffixes"
        self.logger.debug(f"CDSValidator-Mapping {mapping_id} using "
                          f"{allowed_file_suffixes_file} for supported file suffixes.")
        # read the file skipping comment lines
        allowed_file_suffixes = {}
        try:
            f = open(allowed_file_suffixes_file, "r")
            line_list = [line.rstrip('\n') for line in f]
            f.close()
            for key in line_list:
                if len(key.strip()) > 0 and not key.startswith("#") and key:
                    allowed_file_suffixes[key.strip()] = True
        except IOError as io:
            self.logger.error(f"CDSValidator-Reading file {allowed_file_suffixes_file} exception {io}")
        self.logger.debug(f"CDSValidator-Mapping {mapping_id} allowed suffixes={allowed_file_suffixes}")
        return allowed_file_suffixes

    def _simple_suffix_check(self, key=None, allowed_file_suffixes={}):
        allowed_suffix = self._is_allowed_suffix(object_name=key, allowed_file_suffixes=allowed_file_suffixes)
        return allowed_suffix

    def _is_allowed_suffix(self, object_name=None, allowed_file_suffixes={}):
        """
        minimal CDS service - all we do is check the suffix is in the allowed list
        :param object_name:
        :param allowed_file_suffixes: looks like this {'txt': True, 'jpg': True, 'png': True} for allowed suffixes
        :return: True if the file suffix is allowed, False if it is not allowed (aka rejected)
        """
        # simple suffix check for now
        if object_name is None:
            return False
        file_extension = self._get_suffix(object_name)
        allowed = allowed_file_suffixes.get(file_extension.lower(), False)
        self.logger.info(f"CDSValidator-checking validity of file {object_name} "
                         f"with suffix {file_extension}, allowed={allowed}")
        return allowed

    def _get_suffix(self, object_name):
        self.logger.info(f"CDSValidator-_get_suffix entered object_name={object_name}.")
        filename, file_extension = os.path.splitext(object_name)
        file_extension = file_extension[1:]  # drop the .
        return file_extension

    def _validate_xml_against_xsd(self, s3bucket=None, s3key=None, mapping_id=''):
        # first see if there is an XSD for this mapping
        if s3bucket is None or s3key is None:
            self.logger.error(f"CDSValidator-S3bucket and/or key value passed "
                              f"validate_xml_against_xsd is None")
            return False
        xsd_filename = mapping_id + '.xsd'
        xsd_full_name = f"{self.xsd_directory}/{xsd_filename}"
        self.logger.info(f"CDSValidator-Looking for xsd file named {xsd_full_name}")
        if not os.path.exists(f"{self.xsd_directory}/{xsd_filename}"):
            # not found so treat as fine since that is our default behavior
            self.logger.info(f"CDSValidator-{xsd_filename} not found so NOT "
                             f"checking xml against xsd.")
            return True
        # go read the xml file from S3 into variable
        xml_data = generalutils.read_data_from_s3(bucket=s3bucket, key=s3key,
                                                  region=self.aws_region, logger=self.logger)
        if xml_data is None:
            self.logger.error(f"CDSValidator-Unable to read xml file {s3bucket}/{s3key}.")
            # a not found file will be triggered by a failure further upstream in simulator
            return True
        self.logger.info(f"CDSValidator-xml data read from {s3bucket}/{s3key}.")
        self.logger.debug(f"CDSValidator-xml data dump={xml_data}")
        try:
            xml_string = ET.fromstring(xml_data)
            tree = self._get_etree(xml_string)
            xml_root = tree.getroot()
            xsd_schema_doc = ET.parse(xsd_full_name)
            xsd_as_xml_schema = ET.XMLSchema(xsd_schema_doc)
            # use a more detailed output method below instead of valid = xsd_as_xml_schema.validate(xml_root)
            xsd_as_xml_schema.assertValid(xml_root)
            valid = True
        except Exception as ve:
            self.logger.error(f"CDSValidator-Validation failure {s3bucket}/{s3key}:{ve}")
            valid = False
        self.logger.info(f"CDSValidator-Validation of {s3bucket}/{s3key} against "
                         f"{xsd_filename} was {valid}")
        return valid

    def validate_tdf_manifest_against_xsd(self, s3bucket=None, s3key=None, transfer_profile='CDS_1'):

        # default to standard Software Artifacts cdux xsd file - since this is used for CDS_1 and CDS_2
        xsd_name = "cdsmanifest_tdf.xsd"
        xsd_full_name = f"{self.xsd_directory}/tdf_xsds/{xsd_name}"

        # check if RTB Software Transfer option and reset to proper name to use
        if transfer_profile == 'CDS_3':
            xsd_name = "dual_sign_schema.xsd"
            xsd_full_name = f"{self.xsd_directory}/software_transfer_xsds/{xsd_name}"

        self.logger.info(f"CDSValidator-Looking for xsd file named "
                         f"{xsd_full_name}, transfer_profile={transfer_profile}")
        if not os.path.exists(f"{xsd_full_name}"):
            # not found so treat as error
            self.logger.error(f"CDSValidator-{xsd_full_name} not found-should be there.")
            return False
        # go read the xml manifest file from S3 into variable
        xml_data = generalutils.read_data_from_s3(bucket=s3bucket, key=s3key,
                                                  region=self.aws_region, logger=self.logger)
        if xml_data is None:
            self.logger.error(f"CDSValidator-Unable to read xml manifest file {s3bucket}/{s3key}.")
            # a not found file will be triggered by a failure further upstream in simulator
            return False
        self.logger.info(f"CDSValidator-xml data read from {s3bucket}/{s3key}.")
        self.logger.debug(f"CDSValidator-xml data dump={xml_data}")
        try:
            xml_string = ET.fromstring(xml_data)
            tree = self._get_etree(xml_string)
            xml_root = tree.getroot()
            xsd_schema_doc = ET.parse(xsd_full_name)
            xsd_as_xml_schema = ET.XMLSchema(xsd_schema_doc)
            # use a more detailed output method below instead of valid = xsd_as_xml_schema.validate(xml_root)
            xsd_as_xml_schema.assertValid(xml_root)
            valid = True
        except Exception as ve:
            self.logger.error(f"CDSValidator-Validation failure {s3bucket}/{s3key}:{ve}")
            valid = False
        self.logger.info(f"CDSValidator-Validation of {s3bucket}/{s3key} against {xsd_name} was {valid}")
        return valid

    def _get_etree(self, doc, encoding=None):
        """Returns an ``etree._ElementTree`` instance."""
        self.logger.debug(f"CDSValidator-_get_etree entered.")
        if self._is_etree(doc):
            return doc
        elif self._is_element(doc):
            return ET.ElementTree(doc)
        else:
            parser = self._get_xml_parser(encoding=encoding)
            return ET.parse(doc, parser=parser)

    def _is_element(self, obj):
        """Returns ``True`` if `obj` is an lxml ``Element``."""
        self.logger.debug(f"CDSValidator-_is_element entered.")
        return isinstance(obj, ET._Element)  # noqa

    def _is_etree(self, obj):
        """Returns ``True`` if `obj` is an lxml ``ElementTree``."""
        self.logger.debug(f"CDSValidator-_is_etree entered.")
        return isinstance(obj, ET._ElementTree)  # noqa

    def _get_xml_parser(self, encoding=None):
        """Returns an ``etree.ETCompatXMLParser`` instance."""
        self.logger.debug(f"CDSValidator-_get_xml_parser entered.")
        parser = ET.ETCompatXMLParser(
            huge_tree=False,
            remove_comments=True,
            strip_cdata=True,
            ns_clean=False,
            no_network=True,
            remove_blank_text=False,
            remove_pis=True,
            resolve_entities=False,
            encoding=encoding
        )
        return parser

"""
The Diode Test Harness is provided to you as “Beta Materials” and your use of the Beta Materials
is governed by your agreement with AWS.  In particular, please note that your use of the Beta
Materials is subject to the Universal and Beta Service Participation sections of the AWS Service
Terms (http://aws.amazon.com/service-terms/) and is confidential, as is all associated documentation.
You may not discuss the features or functionality of the Beta Materials with any party
(individual or business) that is not authorized by Amazon Web Services.  You may not transfer the
Beta Materials outside of your AWS account nor may you otherwise distribute the Beta Materials to
any party.
"""
import os
import sys
import configparser
from random import seed
import time
path = os.path.abspath(os.path.join(os.path.dirname(__file__), '../common_utils'))
if path not in sys.path:
    sys.path.insert(1, path)
import general_utils as generalutils


DYNAMO_TRANSFER_TABLE = 'diode-simulator-transfers'
DYNAMO_MAPPING_TABLE = 'diode-simulator-mappings'
AWS_ACCOUNT_NUM = '123456789012'
PROPERTY_FILE = './diode_simulator.properties'  # file name to use if none passed at startup
REGION = ''
S3_HIGH_BUCKET = ''
seed(time.time())

# Setup variables to use for setting mapping limits for new mappings
MAXFILESIZEMB = 1024  # in MB 100 is default, 1024 is 1GB
TPS = 1.0  # Default Diode TPS rating, old limits used to be 0.25
MAXINFLIGHTMBBYTES = 2048

# All of the following values are only settable by modifying this code and should be done only if absolutely necessary
LOCAL_LOG_FILENAME = './diodeSimulator.log'
LOG_FILENAME = LOCAL_LOG_FILENAME


def setup_properties_from_file(property_file):
    global DYNAMO_TRANSFER_TABLE, DYNAMO_MAPPING_TABLE, REGION, MAXFILESIZEMB, \
        TPS, MAXINFLIGHTMBBYTES, S3_HIGH_BUCKET

    config = configparser.RawConfigParser()
    try:
        config.read(property_file)
        DYNAMO_TRANSFER_TABLE = config.get('diodeSimulator', 'DYNAMO_TRANSFER_TABLE')
        DYNAMO_MAPPING_TABLE = config.get('diodeSimulator', 'DYNAMO_MAPPING_TABLE')
        REGION = config.get('diodeSimulator', 'AWS_REGION')
        MAXFILESIZEMB = generalutils.environment_value_as_type(config.get('diodeSimulator', 'MAXFILESIZEMB'),
                                                               type=int, default=100)
        TPS = generalutils.environment_value_as_type(config.get('diodeSimulator', 'TPS'),
                                                     type=float, default=1.0)
        MAXINFLIGHTMBBYTES = generalutils.environment_value_as_type(config.get('diodeSimulator', 'MAXINFLIGHTMBBYTES'),
                                                                    type=int, default=MAXINFLIGHTMBBYTES)
        S3_HIGH_BUCKET = config.get('diodeSimulator', 'S3_HIGH_BUCKET')
    except configparser.Error as e:
        print(f"error reading property file {property_file} - error: {e}")
    return


if __name__ == "__main__":
    from sys import argv

    # see if an argument of a property file has been provided
    if len(argv) == 2:
        propertyFile = argv[1]
    else:
        propertyFile = PROPERTY_FILE
    setup_properties_from_file(propertyFile)

    # Create the transfers table
    dynamo = generalutils.get_dynamodb_client(generalutils.get_session(region=REGION))

    print("populating some preliminary mappings to use...")
    # populate the mappings table with some mappings 2 accepted, 1 deleted, 1 pending with a pin
    generalutils.insert_mapping_record_in_table(dbclient=dynamo, table_name=DYNAMO_MAPPING_TABLE,
                                                mapping_id='12346789-abcd-1234-abcd-123456789012',
                                                alias='myalias1-standard', account_num=AWS_ACCOUNT_NUM,
                                                mapping_status='ACCEPTED', pin='234567',
                                                maxfilesizemb=MAXFILESIZEMB, tps=TPS,
                                                maxinflightmbbytes=MAXINFLIGHTMBBYTES,
                                                mapping_type='standard', delivery_bucket=S3_HIGH_BUCKET)
    generalutils.insert_mapping_record_in_table(dbclient=dynamo, table_name=DYNAMO_MAPPING_TABLE,
                                                mapping_id='6aa5455a-be47-45bd-b3e4-b21b8fe8a123',
                                                alias='xml-only-with-xsd', account_num=AWS_ACCOUNT_NUM,
                                                mapping_status='ACCEPTED', pin='345678',
                                                maxfilesizemb=MAXFILESIZEMB, tps=TPS,
                                                maxinflightmbbytes=MAXINFLIGHTMBBYTES,
                                                mapping_type='standard', delivery_bucket=S3_HIGH_BUCKET)
    generalutils.insert_mapping_record_in_table(dbclient=dynamo, table_name=DYNAMO_MAPPING_TABLE,
                                                mapping_id='6aa5455a-be47-45bd-b3e4-b21b8fe8a789',
                                                alias='myalias3-standard', account_num=AWS_ACCOUNT_NUM,
                                                mapping_status='DELETED', pin='456789',
                                                maxfilesizemb=MAXFILESIZEMB, tps=TPS,
                                                maxinflightmbbytes=MAXINFLIGHTMBBYTES,
                                                mapping_type='standard', delivery_bucket=S3_HIGH_BUCKET)
    # create a software artifacts mapping entry
    generalutils.insert_mapping_record_in_table(dbclient=dynamo, table_name=DYNAMO_MAPPING_TABLE,
                                                mapping_id='6aa5455a-be47-45bd-b3e4-b21b8fe8aabc',
                                                alias='myalias-software-artifacts', account_num=AWS_ACCOUNT_NUM,
                                                mapping_status='ACCEPTED', pin='345678',
                                                maxfilesizemb=MAXFILESIZEMB, tps=TPS,
                                                maxinflightmbbytes=MAXINFLIGHTMBBYTES,
                                                mapping_type='software', delivery_bucket=S3_HIGH_BUCKET)
    # create a standard mapping that shows pending acceptance
    # dynamo = generalutils.get_dynamodb_client(generalutils.get_session())
    generalutils.insert_mapping_record_in_table(dbclient=dynamo, table_name=DYNAMO_MAPPING_TABLE,
                                                mapping_id='12346789-abcd-1234-abcd-123456789014',
                                                alias="myalias4-standard", account_num=AWS_ACCOUNT_NUM,
                                                mapping_status='PENDING_ACCEPTANCE', pin='123456',
                                                maxfilesizemb=MAXFILESIZEMB, tps=TPS,
                                                maxinflightmbbytes=MAXINFLIGHTMBBYTES,
                                                mapping_type='standard', delivery_bucket=S3_HIGH_BUCKET)

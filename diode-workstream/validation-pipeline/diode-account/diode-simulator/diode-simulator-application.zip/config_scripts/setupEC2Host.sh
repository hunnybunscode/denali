#!/bin/sh

# This script sets up the software to run on the EC2 host.
# It's job is to load the /etc/init.d script into the system
# as well as configure the software and start it running.

MYDIR=$(cd $(dirname $0) && pwd)
HOMEDIR="/home/ec2-user"
# The following two values must match the same values in the create_configFile.sh
PROPSFILE="$HOMEDIR/diodeSimulator/diode_simulator.properties"
DIODEAWSCLICONFIG="diode-2017-12-01-1.3.1.json"

# Use System D for setup of our simulator
cp "${HOMEDIR}/diodeSimulator/config_scripts/diodesimulator_service" /etc/systemd/system/diodesimulator.service
systemctl daemon-reload
systemctl enable diodesimulator

echo "Setting ownership on files in $HOMEDIR"
chown ec2-user:ec2-user -R $HOMEDIR

echo "Initializing the dynamodb database mappings table"
python3 /home/ec2-user/diodeSimulator/config_scripts/dynamodb_setupdb.py $PROPSFILE

echo "Configuring the AWS CLI for ec2-user to access diode cli commands locally on simulator"
# Configure the AWS CLI for the user
su - ec2-user -c "aws configure add-model --service-name diode --service-model file:///${HOMEDIR}/diodeSimulator/${DIODEAWSCLICONFIG}"

# Start the service
echo "Starting the transfer service"
systemctl start diodesimulator

# Set up yum-cron to do security updates
echo "Configuring yum-cron"
systemctl stop yum-cron
# We have two edits and sed cannot write to same file it is processing so use a temp file for first edit
cp /etc/yum/yum-cron.conf /etc/yum/yum-cron.conf.original
sed 's/update_cmd = default/update_cmd = security/' /etc/yum/yum-cron.conf > /etc/yum/update-yum-cron.conf
sed 's/apply_updates = no/apply_updates = yes/' /etc/yum/update-yum-cron.conf > /etc/yum/yum-cron.conf
rm -f /etc/yum/update-yum-cron.conf
systemctl start yum-cron

echo "Completed setup of EC2 host, diode simulator process setup and running"
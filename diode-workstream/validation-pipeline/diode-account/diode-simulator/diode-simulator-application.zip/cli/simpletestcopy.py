import boto3
import os
import sys
from sys import argv
import configparser
path = os.path.abspath(os.path.join(os.path.dirname(__file__), '../common_utils'))
if path not in sys.path:
    sys.path.insert(1, path)
import general_utils as generalutils

AWS_REGION = 'us-east-1'

if __name__ == "__main__":
    # see if an argument of a property file has been provided
    if len(argv) != 4:
        print(f"Please provide 3 arguments : propertyfile sourcebucketname objectname")
        print("python3 simpletestcopy.py diodesimulator.properties 'bucketinotheraccount' 'fileinthatbucket'")
        exit(1)

    property_file = argv[1]
    source_bucket = argv[2]
    source_object_name = argv[3]

    config = configparser.RawConfigParser()
    config.read(property_file)
    AWS_REGION = config.get('diodeSimulator', 'AWS_REGION', fallback=AWS_REGION)
    S3_HIGH_BUCKET = config.get('diodeSimulator', 'S3_HIGH_BUCKET')

    s3 = generalutils.get_s3_client(generalutils.get_session(region=AWS_REGION))
    s3_result = s3.meta.client.list_objects_v2(Bucket=source_bucket)
    num_files = len(s3_result['Contents'])
    print(f"Number of files in {source_bucket}: {num_files}")

    copy_source = {'Bucket': source_bucket, 'Key': source_object_name}
    destination_name = f"testing/{source_object_name}"
    print(f"Source={copy_source}/{source_object_name}")
    print(f"destination_name={S3_HIGH_BUCKET}/{destination_name}")

    _ = s3.meta.client.copy(CopySource=copy_source, Bucket=S3_HIGH_BUCKET, Key=destination_name)





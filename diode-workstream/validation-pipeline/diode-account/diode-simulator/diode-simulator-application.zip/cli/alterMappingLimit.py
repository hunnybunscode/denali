"""
The Diode Test Harness is provided to you as “Beta Materials” and your use of the Beta Materials
is governed by your agreement with AWS.  In particular, please note that your use of the Beta
Materials is subject to the Universal and Beta Service Participation sections of the AWS Service
Terms (http://aws.amazon.com/service-terms/) and is confidential, as is all associated documentation.
You may not discuss the features or functionality of the Beta Materials with any party
(individual or business) that is not authorized by Amazon Web Services.  You may not transfer the
Beta Materials outside of your AWS account nor may you otherwise distribute the Beta Materials to
any party.
"""

__version__ = 1.0

import os
import boto3
import botocore.session
from botocore.exceptions import ClientError
import time
import json
import decimal
import configparser
import argparse

# Indicate to the interpreter where to find the AWS Diode SDK
SIMULATOR_ENDPOINT = None
MAPPING_ID = '12346789-abcd-1234-abcd-123456789012'
BUCKET_NAME = ''
OBJECT_NAME = ''
REGION = ''


def _get_session(region='us-east-1'):
    """Returns the current AWS session for deriving service clients."""
    return boto3.session.Session(region_name=region)
    # return boto3.session.Session()


def _get_dynamodb_client(aws_session):
    # return aws_session.resource('dynamodb', endpoint_url='http://localhost:8000')
    return aws_session.resource('dynamodb')


def _get_argparser():
    """Create and return an ``ArgumentParser`` instance for this application."""
    desc = "alterMappingLimit.py v{0}".format(__version__)
    sample_usage = "alterMappingLimit.py -i <template file (json or xml)> -v <xsd file to verify template with> " \
                   "-o <xml output file> -a <binary payload file incl. path> -k <private key file (pem format)>  " \
                   "-c <public certificate file (pem format)> -p <passphrase for private key> -b <block size, " \
                   "Choose from 125, 250, 500 (in MB). Default: 250> -d for detailed debugging and stack traces."
    parser = argparse.ArgumentParser(description=desc, epilog=sample_usage)

    # Please verify which arguments are required
    parser.add_argument(
        "-m",
        "--mappingId",
        default="",
        action="store",
        required=True,
        help="the mapping id"
    )

    parser.add_argument(
        "--tps",
        default=None,
        action="store",
        required=False,
        help="<TPS>"
    )

    parser.add_argument(
        "--maxfilesize",
        default=None,
        action="store",
        required=False,
        help="<Maximum file size allowed in MB - either 1024 or 2048>"
    )

    parser.add_argument(
        "--maxinflight",
        default=None,
        action="store",
        required=False,
        help="<Maximum MB allowed in flight>"
    )

    parser.add_argument(
        "--mappingtype",
        default=None,
        action="store",
        help="<Either standard or software>"
    )

    parser.add_argument(
        "--softwareartifactsmaxfiles",
        default=None,
        action="store",
        help="<Maximum number of artifacts in flight>"
    )

    parser.add_argument(
        "-d",
        "--debug",
        default=False,
        action="store_true",
        help="<set this flag for additional verbose output>"
    )

    return parser


if __name__ == '__main__':
    from sys import argv

    config = configparser.RawConfigParser()
    config.read("../diode_simulator.properties")
    REGION = config.get('diodeSimulator', 'AWS_REGION')
    DYNAMO_MAPPING_TABLE = config.get('diodeSimulator', 'DYNAMO_MAPPING_TABLE')

    generate_parser = _get_argparser()
    generate_args = generate_parser.parse_args()

    templatefile = generate_args.ifile
    xsdtemplatefile = generate_args.vfile
    xmloutputfile = generate_args.ofile
    archive = generate_args.afile
    privatekey = generate_args.kfile  # 'examplekey.key'
    cert = generate_args.cfile  # 'examplecert.pem'
    passphrase = generate_args.passphrase
    debugging = generate_args.debug

    # see if an argument of a bucket and object name has been provided
    # 'maxFileSizeMB': MAXFILESIZEMB,
    # 'TPS': decimal.Decimal(TPS),
    # 'maxInFlightMB': MAXINFLIGHTMBBYTES,
    # 'mappingType': mappingType,
    # 'softwareArtifactsMaxFileSizeMB': 30720,
    # 'softwareArtifactsMaxFilesInFlight': 2,

    if len(argv) == 4 or len(argv) == 5:
        MAPPING_ID = argv[1]
        MAXFILESIZEMB = argv[2]
        MAXINFLIGHTMBBYTES = argv[3]
        if len(argv) == 5:
            mappingType = argv[4]
    else:
        print("pass the mapping id low side bucket name and an s3 object name that exists in the bucket to transfer.")
        exit(1)

    dynamo = _get_dynamodb_client(_get_session(region=REGION))

"""
The Diode Test Harness is provided to you as “Beta Materials” and your use of the Beta Materials
is governed by your agreement with AWS.  In particular, please note that your use of the Beta
Materials is subject to the Universal and Beta Service Participation sections of the AWS Service
Terms (http://aws.amazon.com/service-terms/) and is confidential, as is all associated documentation.
You may not discuss the features or functionality of the Beta Materials with any party
(individual or business) that is not authorized by Amazon Web Services.  You may not transfer the
Beta Materials outside of your AWS account nor may you otherwise distribute the Beta Materials to
any party.
"""
import os
import sys
from random import seed
import time
path = os.path.abspath(os.path.join(os.path.dirname(__file__), '../common_utils'))
if path not in sys.path:
    sys.path.insert(1, path)
import general_utils as generalutils

DYNAMO_MAPPING_TABLE = 'diode-simulator-mappings'
AWS_ACCOUNT_NUM = '123456789012'
PROPERTY_FILE = './diode_simulator.properties'  # file name to use if none passed at startup
REGION = ''
seed(time.time())

# Setup variables to use for setting mapping limits for new mappings
MAXFILESIZEMB = 1024  # in MB 100 is default, 1024 is 1GB
TPS = 0.25  # Default Diode TPS rating
MAXINFLIGHTMBBYTES = 2048

# All of the following values are only settable by modifying this code and should be done only if absolutely necessary
PROPERTY_FILE = './diode_simulator.properties'  # file name to use if none passed at startup
LOCAL_LOG_FILENAME = './diodeSimulator.log'
LOG_FILENAME = LOCAL_LOG_FILENAME


def setup_properties_from_file(propertyfile):
    global DYNAMO_MAPPING_TABLE, REGION, MAXFILESIZEMB, TPS, MAXINFLIGHTMBBYTES

    config = configparser.RawConfigParser()
    try:
        config.read(propertyfile)
        DYNAMO_MAPPING_TABLE = config.get('diodeSimulator', 'DYNAMO_MAPPING_TABLE')
        REGION = config.get('diodeSimulator', 'AWS_REGION')
        MAXFILESIZEMB = generalutils.environment_value_as_type(config.get('diodeSimulator', 'MAXFILESIZEMB'),
                                                               type=int, default=100)
        TPS = generalutils.environment_value_as_type(config.get('diodeSimulator', 'TPS'),
                                                     type=float, default=0.25)
        MAXINFLIGHTMBBYTES = generalutils.environment_value_as_type(config.get('diodeSimulator', 'MAXINFLIGHTMBBYTES'),
                                                                    type=int, default=MAXINFLIGHTMBBYTES)
    except configparser.Error as e:
        print("error reading property file %s" % (str(e)))
    return


if __name__ == "__main__":
    from sys import argv

    # see if an agument of a property file has been provided
    if len(argv) == 2:
        propertyFile = argv[1]
    else:
        propertyFile = PROPERTY_FILE
    setup_properties_from_file(propertyFile)

    print("code not implemented, needs to take property file name, mapping id, maxfilesizeMB, TPS, and maxMBinflight and adjust the mapping to that")

    sys.exit(1)

Diode Simulator Service Version 3.0
Legal:
The Diode Test Harness is provided to you as “Beta Materials” and your use of the Beta Materials
is governed by your agreement with AWS.  In particular, please note that your use of the Beta
Materials is subject to the Universal and Beta Service Participation sections of the AWS Service
Terms (http://aws.amazon.com/service-terms/) and is confidential, as is all associated documentation.
You may not discuss the features or functionality of the Beta Materials with any party
(individual or business) that is not authorized by Amazon Web Services.  You may not transfer the
Beta Materials outside of your AWS account nor may you otherwise distribute the Beta Materials to
any party.

Version Release Notes: (located at the bottom of the file-please read!)


This software provides a minimalistic simulator of the AWS Diode service.  It is intended to be run after
successfully being deployed using the CloudFormation template provided.  The template sets up the following:

1: A minimal ec2 instance where the code is deployed and setup as a process to run after a reboot.  All the code is located
in the ec2-user's home directory.
2: Two S3 buckets named by the user of the template (suggest using userid-low and userid-high) to keep them straight.
3: A DynamoDB set of tables to track transfer requests and their status through the system
4: An SQS queue for the simulator to use to handle internal processing of simulated CDS events.
5: An SQS queue that will receive the CloudWatch events generated as a result of transfers that
can be used to drive external operations
6: CloudWatch logs are setup to grab the logs off the server so they can be reviewed.

This is intended to be a mock service of the Diode service and as such does not implement the full capabilities of the
service itself.  True testing of your workloads should be done against the real service.  As such the following are
not implemented in the test harness at this point:
    Limited APIs are supported (not the full Diode SDK) as outlined below:
        CreateTransfer
        DescribeTransfer
        ListAccountMappings
        ListTransfers
        CreateAccountMapping
        GetAccountMappingPin
        AcceptAccountMapping
        DeleteAccountMapping

    The system supports TPS limits and maximum file size limits


To install the simulator:

== Prerequisites ==
You must have an operational AWS account with a default VPC and a default subnet
that can reach the internet.

The default setup of the simulator supports logging into the simulator via EC2
Browser Console. If you wish to enable
    SSH direct access via ssh ec2 keys then please look through the YAML file
                            and uncomment the lines at the following locations:
        Lines 20-21 - the parameter for this to appear in the proper section.
        Lines 74-85 - enable fields to select the key and the ip range to allow access from
        Lines 434-438 - to enable port 22 for access to the host
        Line 631 - to add the key to the host when it is provisioned.
Recommend after the above edits that you save the yaml file with a new name and
then specify that file when using the CloudFormation console steps below.

Steps to use the CloudFormation template:
1 - Log in to the AWS Management Console:
https://console.aws.amazon.com/

2 - Create an S3 bucket to store the software itself. This bucket should be
private to your account and created in the region you with to use to run the simulator.
You will need to provide the name of this bucket when the CloudFormation template
is used to create the stack. The zip file specified in step 3 below must be
placed in the root of the bucket created in this step.
For more information, refer to the AWS Documentation for S3:
https://docs.aws.amazon.com/AmazonS3/latest/gsg/CreatingABucket.html

If you are using KMS to encrypt this bucket then you must login to the console
and add kms key access to the ec2 role created by the CF stack. Once this is done
login to the ec2 server created and complete the steps in lines 674-693 of the
diode-simulator-python.yaml file manually as the root user. It is recommended that
you not enable KMS on the software holding bucket for the initial install and then
after the install completes, delete the bucket.

3 - Upload the zip files called diode-simulator-application.zip and
diode-simulator-swams-lambda-application.zip, present in the
same archive as this README.txt, to the bucket created in step 2.  Do not rename
these zip files or you will need to enter the new names when running the CloudFormation
template (the template defaults to this name). The zip file must be placed
into the root of the bucket from step 2.

4 - In the AWS console, navigate to the CloudFormation service:
https://console.aws.amazon.com/cloudformation

5 - If this is your first time creating a CloudFormation stack, select the
Create New Stack button. If you have previously created CloudFormation stacks,
select the Create Stack button instead on the list of stacks.

6 - Select Upload a template to Amazon S3 and click the Browse button.

7 - Locate the file diode-simulator-python.yaml (should be in the same folder as this
README.txt); or if you saved it as a different name to use SSH access then select
use that named file in the step below.

8 - Select the diode-simulator-python.yaml file and then click Next.

9 - Enter a name for your stack e.g. DiodeSimulator.

10 - The rest of the fields are for configuring the settings the Simulator will use and/or need:

   - SoftwareDeploymentPackageBucketName: Place the name of the S3 bucket you created
   and stored the zip file in from steps 2 and 3.

   - SimulatorDeploymentPackageObjectKey: Leave the field as is, unless you renamed the zip
   file from step 3.

   - ManifestHashLambdaDeploymentPackageObjectKey: Leave the field as is, unless you renamed the zip
   file from step 3.

   - InstanceType: Select the type of EC2 instance you would like to run - a small instance is fine for the simulator.
   * The following two options will only appear if you uncommented the indicated
       lines in the pre-steps at the top.
   - KeyName: Specify the key pair to use for login to the instance. If no keys appear in the dropdown you should create
   a keypair within the EC2 service on the main console.

   - SimulatorAccessLocation: Specify the CIDR that will be allowed to access the ip address assigned to the simulator
        endpoint. The default is 127.0.0.1 which will prevent access from the world, please select a value here that
        provides access for the network where you wish to test.

11 - The remaining fields are specific to settings for the simulator.  Most can be left at their default values unless
you want to run higher workloads.  Most of the settings represent standard account limits for a new Diode account.

   - SimulatorListenPort: The port number you would like the simulator to listen on. Internally it runs on port 8080, but
    this allows you to choose a more known port. The simulator does not support https like the real Diode service.

   - SimulatorAccessLocation: Provide a CIDR that will permit access to the simulator from your network.

   - LowSideBucketName: Provide a name for the S3 bucket where you would like to place your files for the simulator to
   transfer. Unlike the real Diode service, you must use a single bucket for transfers. This bucket will be created by
   the CloudFormation template and therefore needs to not exist. If you would prefer you can leave the field blank and
   a bucket will automatically be named and created for your use.

   - HighSideBucketName: Provide a name for the S3 bucket where you would like the simulator to place your transferred
   files. This bucket will be created by the CloudFormation template and therefore needs to not exist. If you would
   prefer you can leave the field blank and a bucket will automatically be named and created for your use.

   - EnableAllBucketsAccess: Set this option to true to allow the simulator read access to all your S3 buckets if you
   wish to place test files and use them within transfer requests. If you only wish to use the bucket created under
   the LowSideBucketName for the source of files then leave this parameter false.

   - The other fields contain descriptions of what they represent and are based on limits explained in the Diode User Guide.

   - RandomTransferFailures: This field can be set to true if you would like the simulator to inject a failure in your
   transfers at random periods.

   - CloudWatchEventsSource: This is the source field in the events generated by the simulator. If you want to run multiple
   simulators in the same account this field should be unique for each one of them to avoid confusion. Do not use any value
   here that begins with aws as that is reserved for AWS services.

12 - Select Next

13 - Select Next again

14 - Click the checkbox next to "I acknowledge that AWS CloudFormation might
create IAM resources."

15 - Select Create

NOTE: The stack will complete in approximately one minute, but the EC2 instance setup typically takes about 3-4
minutes to complete. The outputs tab in the console will show key information fields for you. The SimulatorEndpoint
value is what you need to supply to Diode SDKs and command line utilities as your endpoint-url value when creating a Diode
client. You can test the service by executing a curl <SimulatorEndpoint> command.  You should see a simple html line
come back.

That's it!

Running the simulator:
The simulator runs as service under SystemD as such you should use appropriate SystemD commands to start/stop the service.

The service is setup to restart automatically upon an EC2 reboot. The commands to manually start and stop the service are:

Starting: sudo systemctl start diodesimulator
Stopping: sudo systemctl stop diodesimulator

The simulator logs all messages to CloudWatch logs as well as to a local log file in the /home/ec2-user directory.


Using the simulator:
The following notes detail some information about the simulator and its behavior as well how to use it with Diode
command line API. Note that in order to use the command line utilities you must install the Diode Service file which
is included in this zip file.  Place this on the host where the AWS CLI is installed and execute the following:
aws configure add-model \
--service-name diode \
--service-model file:///full_path/to/diode-2017-12-01-version.json

REPLACE version with the version of the json file e.g. 1.2.

To setup the Diode service from Boto3 please follow the directions in the AWS Diode Service Developer Guide p. 22-24.

To use the test harness amend your calls using the APIs with an additional endpoint-url attribute, examples follow:
The value for this endpoint-url attribute is available in the CloudFormation outputs section.

For the AWS CLI command - append an --endpoint-url http://ipofinstance:8080
aws diode create-transfer --s3-bucket <lowbucketname> --s3-key <objectname> \
    --mapping-id "12346789-abcd-1234-abcd-123456789012" --description "test" --endpoint-url http://localhost:8080

For the python SDK define the endpoint-url when setting up the diode client:
diode = boto3.sessions.Session(region_name="us-east-1").resource('diode', endpoint_url='http://localhost:8080')


You may need to add the model to use the Diode services to your CLI:
aws configure add-model --service-name diode --service-model file:///service-2.json

At this point the implemented API calls will behave like the real Diode service

Commands:

aws diode list-account-mappings --endpoint-url http://ipofinstance:8080

aws diode create-transfer --endpoint-url http://ipofinstance:8080 --s3-bucket "tonydahb-largefiles" --s3-key "100mb.txt" --mapping-id "12346789-abcd-1234-abcd-123456789012" --description "test"

aws diode describe-transfer --endpoint-url http://ipofinstance:8080 --transfer-id 746ff726-a19e-424b-acc7-0958b70848b0

aws diode list-transfers --endpoint-url http://ipofinstance:8080

The test harness also supports creating account mappings and accepting them like the real Diode service, including
the creation and need to use a PIN.  However, there is no concept of a low side and high side since it is all one endpoint.
This means that the commands are accepted but you must use strict values for some of the arguments.  An invalid argument
will display an error message with what the value should be, let's take an example.  NOTE: the harness does not require setting
up IAM roles and bucket policies.  Therefore, the source bucket (low side) and destination bucket (high side) are always the
same for all commands.  The names of these buckets in the properties file that is populated by the CloudFormation template.
The properties file is called diode_testharness.properties.  The bucket names are also output properties of the template
when it finishes setup.  You can specify the values when running the template or let the system pick names for you. The account
number is also hardcoded in the simulator to 123456789012.  All requests that need any form of account number should use
that number.

Here are some examples of using the account mapping commands to setup a mapping.  The region for the harness is localhost.

aws diode create-account-mapping --sender-account-id 123456789012 --delivery-s3-bucket-name <high side bucket name> \
    --role-arn 'arn:localhost:iam::123456789012:role/diode-receiver-role' --remote-region localhost \
    --alias "somealias" --endpoint-url http://ipofinstance:8080

The above command will return a mapping record with a mapping id - the above operation is normally only done on the high
side of Diode. Again, there is no high or low side for the test harness.  The following command will return the PIN.

aws diode get-account-mapping-pin --mapping-id <id from above> --endpoint-url http://ipofinstance:8080

The PIN will be returned as a six-digit number.

Now use the following command to accept the account mapping. You must use the exact name for the role-ARN shown, as well
as the exact same alias name that was used on the create-account-mapping.  Obviously this is not how the real Diode service
behaves but again the test harness is not a high and low service.

aws diode accept-account-mapping --mapping-id <id from create mapping> --alias tonyalias \
    --role-arn arn:localhost:iam::123456789012:role/diode-sender-role --pin <value of pin> --endpoint-url http://ipofinstance:8080

Upon success of this command your mapping will change to ACCEPTED and be able to be used for create transfer calls.
NOTE: The high and low mapping ids in the real diode service are not the same values, but this is a test harness.

To delete an account mapping use:
aws diode delete-account-mapping --mapping-id <mapping id> --endpoint-url http://ipofinstance:8080


There are some limitations within the simulator:
The ListAccountMappings call does not support filtering (the filter will be accepted but not used).
The ListTransfers call does not support filtering (the filter will be accepted but not used).
The CreateAccountMapping, GetAccountMappingPin and AcceptAccountMapping all work off the same endpoint (there
is no high and low side concept); these calls require specific values for the simulator (see above notes).
The DescribeTransfer call is not throttled like the real Diode service (you should be using CloudWatch events
instead of polling DescribeTransfer :) )
The source (low side bucket) cannot be any bucket in your account since the simulator is not
integrated with IAM roles/policies. If you wish to allow any bucket to be used in your account
then set the EnableAllBucketsAccess to True to permit a all access S3 policy for your account.
The simulator does not support encryption at rest for the buckets being used-since this is transparent to using
Diode - other than setting up the KMS access correctly it should not affect use of the simulator for testing.

Other Diode API calls are not currently supported in the simulator-if you would like to see others added please inquire.

************************************************
*** Created default mapping IDs descriptions ***
************************************************
The following mapping IDs are created as part of the install and are configured as follows

12346789-abcd-1234-abcd-123456789012 alias=myalias1-standard            This mapping is a standard diode
mapping that supports the following datatypes: txt, jpg, png, doc, csv, xml. The xml files in this mapping
are not validated with an XSD. If you wish to add XSD validation place an XSD with the name
12346789-abcd-1234-abcd-123456789012.xsd and this will force xsd verification.

6aa5455a-be47-45bd-b3e4-b21b8fe8aabc alias=myalias-software-artifacts   This mapping is a software artifacts
mapping and is there to support simulated use of this special feature within the Diode service. This mapping
requires the presentation of a payload and an associated manifest file that complies with the SA manifest
format. This feature is a special white list feature of the diode service and is not available by default
to users of Diode without special paperwork and approval.

6aa5455a-be47-45bd-b3e4-b21b8fe8a789 alias=myalias3-standard            This mapping is in the deleted state
and is here to allow you to see what a mapping that has been turned off looks like to users. This mapping
because it is in a deleted state cannot be used for transfers.

6aa5455a-be47-45bd-b3e4-b21b8fe8a123 alias=xml-only-with-xsd            This mapping uses an XSD to validate
all XML transferred through it. This XSD file is in the XSDs directory on the simulator server. This validation
of XML against an XSD is designed to implement the rigor for RTB data flows using xml. Furthermore, this mapping
only supports file types of xml. If you wish to add more filetypes then create/edit a file that is the mapping name
and contains a list of the allowed file suffixes - one on each line.

12346789-abcd-1234-abcd-123456789014 alias=myalias4-standard            This mapping is in a pending accepted
state and allows you to use the get pin api call and to activate the mapping, simulating what is normally
done on the sending side of a diode setup.

************************************************
************************************************
************************************************

****************************************************************************
*** Using SWAMS feature                                                  ***
****************************************************************************
SWAMS requires a template.json file-here is a sample that can be used for testing:
{
   "originator": "VENDORNAME",
   "product": "PRODUCTNAME",
   "version": "VERSIONNUMBER",
   "cpe": "cpe:/a:CPEVALUE",
   "arch": "64-bit",
   "virus_scan": {
      "vendor": "McAfee",
      "version": "VSE8.88",
      "signature_date": "2024-04-24T09:00:00Z",
      "result": "clean"
   },
   "mediaType": "application/octet-stream"
}

Place this file on the simulator somewhere you can access it.
Place a sample payload file in the simulator low side bucket created by the CF template.

Login to the simulator and cd into the directory where the template.json file was saved and do the
following command:
aws diode create-transfer-manifest --mapping-id 6aa5455a-be47-45bd-b3e4-b21b8fe8aabc --manifest-template file://template.json --payload-s3-bucket diode-simulator-lowsidebucket-name --payload-s3-key payload-name --manifest-format json --endpoint-url http://127.0.0.1:8080

you should receive a transfer manifest id back e.g.:
{
    "transferManifestId": "5a3d718a-f0ba-4233-a804-68ee749ae112"
}

To retrieve your manifest use the following command:
aws diode get-transfer-manifest --transfer-manifest-id 5a3d718a-f0ba-4233-a804-68ee749ae112 --mapping-id 6aa5455a-be47-45bd-b3e4-b21b8fe8aabc --endpoint-url http://127.0.0.1:8080

You will get your manifest back as a json string:

    "transferManifestId": "5a3d718a-f0ba-4233-a804-68ee749ae112",
    "manifestBody": "<?xml version='1.0' encoding='utf8'?>\n<tdf:TrustedDataObject xmlns:sign=\"http://www.w3.org/2000/09/xmldsig#\" xmlns:tdf=\"urn:us:gov:ic:tdf\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" tdf:version=\"202005\"><tdf:Assertion tdf:scope=\"PAYL\"><tdf:StructuredStatement xmlns:cdsm=\"urn:us:gov:ic:cdsmanifest\"><cdsm:CdsManifestAssertion cdsm:DESVersion=\"202005\"><cdsm:Originator>VENDORNAME</cdsm:Originator><cdsm:Product>PRODUCTNAME</cdsm:Product><cdsm:PayloadVersion>VERSIONNUMBER</cdsm:PayloadVersion><cdsm:CPE>cpe:/a:CPEVALUE</cdsm:CPE><cdsm:Arch>64-bit</cdsm:Arch><cdsm:HashVerification cdsm:blockSize=\"134217728\" cdsm:hashType=\"SHA256\" cdsm:totalBlocks=\"1\" cdsm:totalHash=\"997e0ec8936c8830c3657223d8ccdb24d143bb4146245311171e8a5e8b2bdf51\"><cdsm:Hash cdsm:block=\"1\" cdsm:value=\"9d3088c79514744c2773e4a2829f8e5d8b7c962dbde9fb065e287116138be3b1\"/></cdsm:HashVerification><cdsm:VirusScanList><cdsm:VirusScan><cdsm:ScanVendor>McAfee</cdsm:ScanVendor><cdsm:ScanVersion>VSE8.88</cdsm:ScanVersion><cdsm:SignatureDate>2021-04-24T09:00:00Z</cdsm:SignatureDate><cdsm:ScanResult>clean</cdsm:ScanResult></cdsm:VirusScan></cdsm:VirusScanList></cdsm:CdsManifestAssertion></tdf:StructuredStatement></tdf:Assertion><tdf:ReferenceValuePayload tdf:uri=\"DiodeSimulator.zip\" tdf:mediaType=\"application/octet-stream\"/></tdf:TrustedDataObject>"
}


************************************************
************************************************
************************************************


****************************************************************************
*** Setting/up for Simulator to support a cross account low side buckets ***
****************************************************************************
Another option with the simulator is to allow it to read from a set of different AWS accounts (low side) and
copy the files through the simulator which effectively makes it sit on the "high" side. This is the preferred
option and allows users to transfer files from a different low side account all through the simulator
to the high side bucket owned by the simulator. Note that this functionality only works within the same region, since
the simulator uses the S3 copy operation to "simulate" file movement low to high.

NOTE: The simulator accepts requests - it does not enforce that the user making the request actually belongs to
the low side bucket specified (only that it has access to pull the file). Keep this in mind when using this option
and you should enforce who can access the simulator endpoint and initiate transfers.  If you give the simulator access
to the buckets for read then any transfer request which specifies that bucket can perform a transfer.

In order to do have this work all the low side source buckets must have a policy placed on them (S3 bucket policy)
that permits the simulator to read from the bucket.  Here is the bucket policy that is needed.
You should replace the account number in the Principal statement with the account number that is running
the simulator and specify the buckets you wish to allow the simulator to read from:

{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "allow other account access to copy",
            "Effect": "Allow",
            "Principal": {
                "AWS": "arn:aws:iam::123456789012:root"
            },
            "Action": [
                "s3:GetBucketLocation",
                "s3:ListBucket",
                "s3:GetObject",
                "s3:GetObjectTagging"
            ],
            "Resource": [
                "arn:aws:s3:::bucket",
                "arn:aws:s3:::bucket/*"
            ]
        }

Once this has been done, place a sample file in the bucket in the policy above and then
log into the simulator host and run the simplecopytest.py script passing in the property file
for the simulator and the bucket name and object/file name you placed in it.  You should see the file
show up in the simulator high side bucket under a path of /testing if all is setup correctly.  If this works
then you may specify this bucket during your createTransfer commands.

*****************************************************************************
*****************************************************************************
*****************************************************************************

*****************************************************************************
****** Setting/up for Simulator to support a cross account high bucket ******
*****************************************************************************
This option is more complicated to setup and is designed where you want the simulator
to place the files into an alternate account's bucket as the high side bucket. Again,
like the cross account copy option above both accounts must reside in the same region.

The following steps through the setup process to make this work, which includes
adding two properties to the simulator properties file. Once that file is updated
you should restart the simulator process on the server to force it to re-read the
properties file.

Example:

In the following AccountA refers to the account where the simulator is running
AccountB refers to the account where you have place the S3 bucket for the simulator to write
transferred files (the simulated high side bucket).

In AccountA (111111111111)
Account xxx has simulator running in it
get the full role arn for the simulator ec2 role e.g.:
arn:aws:iam::111111111111:role/diodesimulator-EC2ExecutionRole-1N05TOJPG4I1O


In AccountB (222222222222)
Create the s3 bucket and note its name-you will need it later (e.g. acct222222222222-simulatorinotheraccount).
Create a policy in this account like the following:
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "DelegateS3Access",
            "Effect": "Allow",
            "Action": [
                "s3:GetObject",
                "s3:DeleteObject",
                "s3:PutObject",
                "s3:ListBucket",
                "s3:PutObjectTagging",
                "s3:PutObjectAcl",
                "s3:GetObjectTagging"
            ],
            "Resource": [
                "arn:aws:s3:::acct222222222222-simulatorinotheraccount/*",
                "arn:aws:s3:::acct222222222222-simulatorinotheraccount"
            ]
        }
    ]
}

Now create an ec2 role in accountB and call it simulatoraccesstos3 and attach the policy above to it

Now click on the role and on the summary screen select Edit trust relationship
You will be presented with a json policy document, replace the "Service": "ec2.amazonaws.com" with
"AWS": "arn:aws:iam::111111111111:role/diodesimulator-EC2ExecutionRole-1N05TOJPG4I1O"
{
     "Sid": "accountbTrustPolicyforaccounta",
     "Effect": "Allow",
     "Action": "sts:AssumeRole",
     "Principal": {"AWS": "arn:aws:iam::111111111111:role/diodesimulator-EC2ExecutionRole-1N05TOJPG4I1O"}
}

The above is saying that account B trusts accounta's ec2 role to assume the permissions to access accountb's S3 bucket.
Now grab the Role ARN for this new role e.g.
arn:aws:iam::222222222222:role/simulatorinotheraccount

In AccountA:
Return to AccountA and complete the permissions setup:
open IAM and locate the simulator ec2 server role
within the role are multiple policies attached
Locate the SimulatorS3HighLimitedAccess policy and edit the json
Prior to the change it will look something like this:
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Action": [
                "s3:GetObject",
                "s3:DeleteObject",
                "s3:PutObject",
                "s3:ListBucket",
                "s3:PutObjectTagging"
            ],
            "Resource": [
                "arn:aws:s3:::diodesimulator-highsidebucket-4naq7sq1wmzh",
                "arn:aws:s3:::diodesimulator-highsidebucket-4naq7sq1wmzh/*"
            ],
            "Effect": "Allow"
        }
    ]
}



You are going to add an assume role to accountA so it looks like the following,
the resource line contains the value of the role ARN from accountB above:
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Action": [
                "s3:GetObject",
                "s3:DeleteObject",
                "s3:PutObject",
                "s3:ListBucket",
                "s3:PutObjectTagging"
            ],
            "Resource": [
                "arn:aws:s3:::diodesimulator-highsidebucket-4naq7sq1wmzh",
                "arn:aws:s3:::diodesimulator-highsidebucket-4naq7sq1wmzh/*"
            ],
            "Effect": "Allow"
        },
        {
            "Sid": "AllowToAssumeCrossAccountRole",
            "Effect": "Allow",
            "Action": "sts:AssumeRole",
            "Resource": "arn:aws:iam::222222222222:role/simulatorinotheraccount"
        }
    ]
}

The final IAM step is to attach a bucket policy to the simulator low side bucket to allow the
AccountB to be able to pull files to place into it's new high side bucket.
The name of the simulator's low side bucket is in the properties file on the simulator server
or as an output from the CloudFormation template.

Locate the low side bucket used by the simulator in the s3 console and add a bucket policy of the
following:
 "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "allow other account access to copy",
            "Effect": "Allow",
            "Principal": {
                "AWS": "arn:aws:iam::222222222222:root"
            },
            "Action": [
                "s3:GetBucketLocation",
                "s3:ListBucket",
                "s3:GetObject",
                "s3:GetObjectTagging"
            ],
            "Resource": [
                "arn:aws:s3:::diodesimulator-lowsidebucket-jt4jomb6oko4",
                "arn:aws:s3:::diodesimulator-lowsidebucket-jt4jomb6oko4/*"
            ]
        }
    ]
}

It is important to understand that when doing a boto3 s3 copy operation, the destination
bucket/account actually pulls the file from the source bucket.  This is why the AccountB needs
to be able to get to the bucket on the diode simulator.  If you chose to allow access to all buckets
in your account for the simulator to allow diode operations you will need to put a bucket policy
on each one you intend to use.


Now edit the simulator properties file on the diode simulator host
and add the following two fields at the bottom:

CROSSACCOUNTROLEARN=arn:aws:iam::222222222222:role/simulatorinotheraccount
CROSSACCOUNTHIGHBUCKET=acct222222222222-simulatorinotheraccount

Now restart the simulator to reload the properties:
sudo systemctl stop diodesimulator
sudo systemctl start diodesimulator

All simulator high side files will now be written to accountB's S3 bucket called acct222222222222-simulatorinotheraccount

*****************************************************************************
*****************************************************************************
*****************************************************************************

*****************************************************************************
*********************** RELEASE NOTES ***************************************
*****************************************************************************

RELEASE NOTES:
Version 3.9.4   2024-06-06  Update CF template to use IMDSv2.
Version 3.9.3   2024-05-28  Fix due to changes in json2xml library in version 5.0.1. Fixed an issue
                            that caused transferid to not be prepended to object but to whole path if
                            if manifest was in a folder with the payload during write to simulated
                            high bucket.
Version 3.9.2   2023-09-21  Update allowed data types to match service for transfer profiles.
Version 3.9.1   2023-09-06  Update Lambda functions for swams simulation to python 3.10.
Version 3.9     2023-08-01  Addition of new fields in cloudwatch events that now includes
                            the computed hash of the file being transferred for standard
                            simulator transfers. This feature is being rolled out in the
                            Diode service soon and this is to provide parity.
Version 3.8     2023-04-11  Put prescriptive tag copy option in S3 calls to handle
                            cases where large S3 objects copied did not include the
                            S3 tags by default.
Version 3.7     2023-03-17  Added support for default file types by transfer profile,
                            populated the profile 2 and 3 based on subset of available.
Version 3.6     2023-01-09  Added support for including S3 object tags on the createTransfer
                            command as well setup of proper permissions on simulator buckets
                            to allow object tags to be copied.
Version 3.5     2022-10-13  Added support for specifying a vpc and subnet to place
                            the simulator endpoint. This allows use of the diode
                            auto-transfer lambda function in combination with
                            the simulator for demo purposes. Please follow the
                            setup instructions in SIM-AUTOTRANSFER-README.txt.
Version 3.4     2022-06-21  Added support for SWAMS calls to include a distributed
                            Lambda hash calculator. Added automatic install of yum-cron
                            and configuration to keep security patches up to date on the
                            simulator EC2 server.
Version 3.3     2022-05-12  Support for limits by mapping id is now available. The internal software supports
                            this but the cli tooling to allow changing it has not been completed yet.
                            You can change the values in the database and restart the simulator. Added CLI tool
                            to support tranforming a mapping from standard (default) to SA.
Version 3.2     2021-07-30  Supports XSD files per mapping to enforce xml transfers. Added support for file suffix
                            matching by mapping id as well. Any changes to file suffix files will be automatically
                            loaded at next request call without needing to restart simulator. Consult the
                            notes.txt in the allowed_file_suffixes directory and XSDs directory. Set simulator endpoint
                            default value to 127.0.0.1/32 in the CF template to prevent world access to endpoint. If
                            you wish to open it broader to your own network substitute a valid CIDR for this value. Support
                            is now in place to validate SA manifests against the reference XSDs for SA and reject an SA
                            transfer if they do not validate. Support is now added for optional transferProfile option on
                            creating a new mapping. This option has no functionality except for marking it in the mapping
                            record for future extensions.
Version 3.1     2021-07-23  Added the option to place an xsd in the simulator XSDs directory to validate xml over specific
                            mappings. The xsd must be called mapping_id.xsd where mapping_id is the actual mapping id.
Version 3.0     2021-06-12  Restructured layout of code that runs on server by aggregating all simulator code into a single
                            directory underneath /home/ec2-user. Fixed reported time/date fields to match the way the actual
                            diode service returns these (as UTC epoch seconds). Added option to allow multiple high side
                            buckets when creating a new mapping (previously if you did not match the high side bucket
                            name created by the simulator you received an error); note that in order to use this feature
                            you MUST select true during setup of CF template to allow all access so the simulator can write
                            to your buckets for high side operations. This version also supports updating the working tables
                            for new mappings to allow using them without having to restart the simulator. Previously,
                            the simulator only loaded the active mappings at startup. Added xml as an allowed file type by default.
Version 2.2     2021-02-03  Updated the simulator to support cross account low and/or high side buckets and documented
                            this in the README.txt
Version 2.1     2020-12-14  Updated the diode json library to the latest version 1.3.0
Version 2.0     2020-07-30  Created 2.0 of simulator to support Software artifacts transfers
Version 1.5     2020-01-20  Code now supports multiple high side buckets to be passed. The user of the
                            simulator must set the IAM permissions of the simulator manually to include the allowed
                            buckets to write to. If this is not done, then requests for that bucket to use on a
                            create transfer call will fail as the code will try to write a fake object in the
                            bucket during setup. Added support for transferProfile in request, this is ignored but
                            the value is saved. The IAM policy that needs to be updated is output by the CF script
                            when it concludes. You will need to manually add the additional buckets you want to
                            use as the simulator will try to write a sample file in the bucket.
Version 1.4     2019-12-02  Setup the simulator to use an elastic ip - preventing the ip being re-assigned if you start
                            and stop the instance.
Version 1.3     2019-11-20  Refactored the CloudFormation template to utilize properties and log setup files directly
                            from the template. This allowed the removal of the create_configFile.sh and simplified the
                            setup. The system now automatically sets up Session Manager to access the host if needed.
                            Host keys were removed as a way to pass values for the property file generation, it is now
                            created at template runtime in the template.
Version 1.2     2019-06-10  Added generation of IN_TRANSIT initial CloudWatch event - this was originally missed
                            (all other events were present except the initial IN_TRANSIT)
Version 1.1     2019-05-27  Updated code to use system d model for processes.
Version 1.0     2019-05-20  Initial release of diode simulator code base.

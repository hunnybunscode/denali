# Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS
# OF ANY KIND, either express or implied. See the License for the specific
# language governing permissions and limitations under the License.

from six import BytesIO
from lxml import etree
import hashlib


def is_element(obj):
    """Returns ``True`` if `obj` is an lxml ``Element``."""
    return isinstance(obj, etree._Element)  # noqa


def is_etree(obj):
    """Returns ``True`` if `obj` is an lxml ``ElementTree``."""
    return isinstance(obj, etree._ElementTree)  # noqa


def get_xml_parser(encoding=None):
    """Returns an ``etree.ETCompatXMLParser`` instance."""
    parser = etree.ETCompatXMLParser(
        huge_tree=False,
        remove_comments=True,
        strip_cdata=True,
        ns_clean=False,
        no_network=True,
        remove_blank_text=False,
        remove_pis=True,
        resolve_entities=False,
        encoding=encoding
    )
    return parser


def get_etree(doc, encoding=None):
    """Returns an ``etree._ElementTree`` instance."""
    if is_etree(doc):
        return doc
    elif is_element(doc):
        return etree.ElementTree(doc)
    else:
        parser = get_xml_parser(encoding=encoding)
        return etree.parse(doc, parser=parser)


def parse(doc, encoding=None):
    """Parses an XML document using the internal document parser.
    :returns: An ``etree._ElementTree`` instance.
    """
    return etree.parse(BytesIO(doc), get_xml_parser(encoding=encoding))


def get_value_in_xml_tag(xmldocument, tagname):
    """ Returns the value of the requested tag in the XML provided. This is a simple method to read element
    values.

    :param xmldocument: The lxml input object
    :param tagname: The desired element with the value you want
    :returns: the value of the element
    """
    try:
        return xmldocument.find(tagname).text
    except AttributeError:
        return None


def get_attr_value_in_xml_tag(xmldocument, attribname):
    """ Returns the value of the requested tag in the XML provided. This is a simple method to read element
    values.

    :param xmldocument: The lxml document
    :param attribname: The desired attribute name
    :returns: the value of the attribute
    """
    return xmldocument.attrib[attribname]

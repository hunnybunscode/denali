# Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS
# OF ANY KIND, either express or implied. See the License for the specific
# language governing permissions and limitations under the License.

import boto3
import re


def get_session(region='us-east-1'):
    """Returns the current AWS session for deriving service clients."""
    return boto3.session.Session(region_name=region)
    # return boto3.session.Session()


def get_s3_client(aws_session):
    """Returns the Amazon S3 resource (client = resource.meta.client)."""
    return aws_session.resource('s3')


def get_sqs_client(aws_session):
    return aws_session.resource('sqs')


def get_kms_client(region='us-east-1'):
    """Returns the Amazon KMS client - kms does not support resources."""
    return boto3.client('kms', region_name=region)


def get_bucket_key_from_s3uri(s3uri):
    """
    Returns bucket and key from SQS Message
    """
    pattern = '^(s3:\S\S)([a-zA-Z0-9]*).(.*)$'
    uri_regex = re.search(pattern, s3uri)
    return uri_regex.group(2), uri_regex.group(3)


def find_bucket_key(s3_path=''):
    """
    This is a helper function that given an s3 path such that the path is of
    the form: bucket/key
    It will return the bucket and the key represented by the s3 path
    """
    s3_components = s3_path.split('/')
    bucket = s3_components[0]
    s3_key = ""
    if len(s3_components) > 1:
        s3_key = '/'.join(s3_components[1:])
    return bucket, s3_key


def split_s3_bucket_key(s3_path=''):
    """Split s3 path into bucket and key prefix.
    This will also handle the s3:// prefix.
    :return: Tuple of ('bucketname', 'keyname')
    """
    if s3_path.lower().startswith('s3://'):
        s3_path = s3_path[5:]
    return find_bucket_key(s3_path)


def get_size_s3_object(s3=None, bucket=None, object_name=None, logger=None):
    if bucket and object_name:
        try:
            response = s3.meta.client.head_object(Bucket=bucket, Key=object_name)
        except Exception:
            if logger:
                logger.error("Could not find object with name %s, may not exist." % object_name)
            return -1
        return_code = response['ResponseMetadata']['HTTPStatusCode']
        if return_code == 200:
            return response['ContentLength']
        else:
            if logger:
                logger.error("response on size query of S3 object is %s" % str(return_code))
            return -1
    if logger:
        logger.error("No bucket and key provided to get size of object.")
    raise Exception("No bucket and key provided to get size of object.")


def write_data_s3(s3=None, bucket=None, key=None, data='', logger=None):
    """
    Writes specified data to s3.
    :param s3: s3 resource (not meta.client)
    :param bucket: bucket name to write data
    :param key: object name to write the data
    :param data: the data itself
    :param logger: logger object if logger output is desired
    :return: True if data written successfully, False if not
    """
    try:
        _ = s3.Object(bucket, key).put(Body=data)
        return True
    except Exception as e:
        if logger:
            logger.error("Error writing manifest data to s3://%s/%s exception: %s " % (bucket, key, e))
        return False


def read_data_s3(s3=None, bucket=None, key=None, logger=None):
    if bucket and key:
        try:
            obj = s3.Object(bucket, key)
            response = obj.get()
            if response and response['ResponseMetadata']['HTTPStatusCode'] == 200:
                data = response.get('Body').read()
                return data
            return None
        except Exception as e:
            if logger:
                logger.error(f"Error reading S3 object {bucket}/{key}")
            raise Exception(f"Error reading S3 object {bucket}/{key}exception: {e}")
    if logger:
        logger.error(f"Bucket and key not provided to read data from S3")
    raise Exception(f"Bucket and key not provided to read data from S3")

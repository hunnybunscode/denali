"""
The Diode Test Harness is provided to you as “Beta Materials” and your use of the Beta Materials
is governed by your agreement with AWS.  In particular, please note that your use of the Beta
Materials is subject to the Universal and Beta Service Participation sections of the AWS Service
Terms (http://aws.amazon.com/service-terms/) and is confidential, as is all associated documentation.
You may not discuss the features or functionality of the Beta Materials with any party
(individual or business) that is not authorized by Amazon Web Services.  You may not transfer the
Beta Materials outside of your AWS account nor may you otherwise distribute the Beta Materials to
any party.
"""
import os
import boto3
from botocore.exceptions import ClientError
import time
import decimal
import json
import base64

# REGION_NAME = 'us-east-1'
# AWS_ACCOUNT_NUM = "123456789012"
# SQS_QUEUE_NAME = 'diode-test-harness-transfers'
# DYNAMO_TRANSFER_TABLE = 'diode-simulator-transfers'
# DYNAMO_MAPPING_TABLE = 'diode-simulator-mappings'


# Helper class to convert a DynamoDB item to JSON.
class DecimalEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, decimal.Decimal):
            if o % 1 > 0:
                return float(o)
            else:
                return int(o)
        return super(DecimalEncoder, self).default(o)


def get_session(region='us-east-1'):
    """Returns the current AWS session for deriving service clients."""
    return boto3.session.Session(region_name=region)
    # return boto3.session.Session()


def get_sqs_client(aws_session):
    """Returns the Amazon SQS client."""
    return aws_session.resource('sqs')


def get_s3_client(aws_session):
    """Returns the Amazon SQS client."""
    return aws_session.resource('s3')


def get_dynamodb_client(aws_session):
    # return aws_session.resource('dynamodb', endpoint_url='http://localhost:8000')
    return aws_session.resource('dynamodb')


def get_cloudwatch_events_client(aws_session):
    return aws_session.client('events')


def get_sts_client(aws_session):
    return aws_session.client('sts')


def get_assumed_s3_role(aws_session, sts_client=None, role_arn=None):
    sts_client = get_sts_client(aws_session)
    assumed_role_object = sts_client.assume_role(RoleArn=role_arn, RoleSessionName="AssumeRoleSession1")
    credentials = assumed_role_object['Credentials']
    s3 = boto3.resource('s3', aws_access_key_id=credentials['AccessKeyId'],
                        aws_secret_access_key=credentials['SecretAccessKey'],
                        aws_session_token=credentials['SessionToken'])
    return s3


# def get_transfers_table_name():
    # return DYNAMO_TRANSFER_TABLE


# def get_mappings_table_name():
    # return DYNAMO_MAPPING_TABLE


# def get_transfers_queue_name():
    # return SQS_QUEUE_NAME

def get_current_time_in_diode_format():
    # return the current date/time in Diode service format
    # generate time of request
    # The following were the older ways of doing it for posterity!
    #       awstime = float("%0.3f" % time.time())
    #       d = str(datetime.utcnow().replace(microsecond=0).isoformat()) + 'Z'
    #       date_sent = str(datetime.now().replace(microsecond=0).isoformat())
    # Pythom time method time() returns the time as a floating point number
    # expressed in seconds since the epoch, in UTC.
    current_date_time_diode_format = decimal.Decimal(float("%0.3f" % time.time()))
    return current_date_time_diode_format


def get_post_key(post_body, key):
    return post_body.get(key, None)


def delete_table(db_client, table_name):
    try:
        table = db_client.Table(table_name)
        table.delete()
    except Exception as e:
        print(f"error trying to delete table {table_name} exception {e}- proceeding")
    return


def delete_record_by_transferid(db_client, table_name, transfer_id):
    table = db_client.Table(table_name)
    try:
        response = table.delete_item(Key={'transferId': transfer_id})
    except ClientError as e:
        if e.response['Error']['Code'] == "ConditionalCheckFailedException":
            print(e.response['Error']['Message'])
        else:
            raise
    else:
        print(f"DeleteItem succeeded - response = {response}.")
    return


def dump_whole_table(db_client, table_name, logger):
    table = db_client.Table(table_name)
    response = table.scan()

    for i in response['Items']:
        logger.info(i)
    return


def insert_record_in_table(db_client, table_name, pkey, filename, file_num):
    table = db_client.Table(table_name)
    table.put_item(Item={
        'guid': str(pkey),
        'objectname': filename,
        'starttime': 'N/A',
        'endtime': 'N/A',
        'filenumber': file_num,
        'status': 'not started',
        'transferid': 'N/A'
    })
    return


# mapping type is either standard or software
def insert_mapping_record_in_table(dbclient=None, table_name=None, mapping_id=None,
                                   alias='', account_num=None, mapping_status='PENDING_ACCEPTANCE',
                                   pin='',
                                   maxfilesizemb=1024, tps=0.25, maxinflightmbbytes=2048,
                                   mapping_type='standard',
                                   software_artifacts_max_files_in_flight=2,
                                   delivery_bucket='N/A', transfer_profile='CDS_1'):
    if mapping_type not in ['standard', 'software']:
        return False
    if transfer_profile not in ['CDS_1', 'CDS_2', 'CDS_3']:
        return False

    fields = {'dateMappingCreated': decimal.Decimal(get_current_time_in_diode_format()),
              'mappingAlias': alias,
              'mappingArn':  make_mapping_arn_prefix(account_num) + mapping_id,
              'mappingOwnerArn': "arn:aws:iam::" + account_num + ":root",
              'receivingBucket': delivery_bucket,
              'receivingRegion': 'localhost',
              'sendingRegion': 'localhost',
              'mappingStatus': mapping_status,
              'roleArn': "arn:localhost:iam::" + account_num + ":role/diode-sender-role",
              'maxFileSizeMB': maxfilesizemb,
              'TPS': decimal.Decimal(tps),
              'maxInFlightMB': maxinflightmbbytes,
              'transferProfile': transfer_profile,
              'mappingType': mapping_type,
              'softwareArtifactsMaxFileSizeMB': 30720,
              'softwareArtifactsMaxFilesInFlight': software_artifacts_max_files_in_flight,
              'pin': pin
              }
    # only put the pin in if it is a new request with no confirm on mapping, if new request then set ARN to receiver
    if mapping_status == 'PENDING_ACCEPTANCE':
        # fields['pin'] = pin
        fields['roleArn'] = "arn:localhost:iam::" + account_num + ":role/diode-receiver-role"

    # insert the record in dynamo - we use an update
    dyn_expression = "SET %s" % ", ".join(["#{name}=:{name}".format(name=name) for name in fields.keys()])
    dyn_expression_attribute_names = {"#%s" % k: k for k in fields.keys()}
    dyn_expression_attribute_values = {":%s" % k: v for k, v in fields.items()}
    dbclient.meta.client.update_item(
        TableName=table_name,
        Key={'mappingId': mapping_id},
        UpdateExpression=dyn_expression,
        ExpressionAttributeNames=dyn_expression_attribute_names,
        ExpressionAttributeValues=dyn_expression_attribute_values,
    )
    return True


def update_mapping_record_in_table(db_client, table_name, mapping_entry, remove_pin=False):
    fields = mapping_entry
    mapping_id = fields['mappingId']
    # remove it from the values for the expression builder since it is the primary key
    fields.pop('mappingId', None)
    # insert the record in dynamo - we use an update
    dyn_expression = "SET %s" % ", ".join(["#{name}=:{name}".format(name=name) for name in fields.keys()])
    dyn_expression_attribute_names = {"#%s" % k: k for k in fields.keys()}
    dyn_expression_attribute_values = {":%s" % k: v for k, v in fields.items()}
    response = db_client.meta.client.update_item(
        TableName=table_name,
        Key={'mappingId': mapping_id},
        UpdateExpression=dyn_expression,
        ExpressionAttributeNames=dyn_expression_attribute_names,
        ExpressionAttributeValues=dyn_expression_attribute_values,
    )
    if remove_pin:
        _ = db_client.meta.client.update_item(
            TableName=table_name,
            Key={'mappingId': mapping_id},
            UpdateExpression='remove pin'
        )
    return response


def get_mapping_record_in_table(db_client, table_name, mapping_id):
    table = db_client.Table(table_name)
    try:
        response = table.get_item(
            Key={
                'mappingId': mapping_id}
        )
    except ClientError as e:
        print(e.response['Error']['Message'])
        return None
    item = response.get('Item', None)
    return item


def get_mapping_tags_in_table(db_client, table_name, mapping_id):
    table = db_client.Table(table_name)
    try:
        response = table.get_item(
            Key={
                'mappingId': mapping_id
            }
        )
    except ClientError as e:
        print(e.response['Error']['Message'])
        return None
    item = response.get('Item', None)
    if item is not None:
        item = {'tags': response['Item'].get('tags', None)}
    return item


def get_all_mappings_table(db_client, table_name, **scanparams):
    table = db_client.Table(table_name)
    response = table.scan(**scanparams)
    jsontext = {'accountMappingList': list(response['Items'])}
    if response.get('LastEvaluatedKey', None) is not None:
        # base 64 encode it
        s = json.dumps(response.get('LastEvaluatedKey'))
        jsontext['nextToken'] = base64.b64encode(s.encode('utf-8')).decode()
    # we do not return the roleArn or the pin on a mapping - but the aws sdk takes care of this
    return jsontext


def get_transfer_record_in_table(db_client, table_name, transfer_id):
    table = db_client.Table(table_name)
    try:
        response = table.get_item(
            Key={
                'transferId': transfer_id}
        )
    except ClientError as e:
        print(e.response['Error']['Message'])
        return None
    if response.get('Item'):
        item = response['Item']
    else:
        item = None
    return item


def get_transfer_tags_in_table(db_client, table_name, transfer_id):
    table = db_client.Table(table_name)
    try:
        response = table.get_item(
            Key={
                'transferId': transfer_id}
        )
    except ClientError as e:
        print(e.response['Error']['Message'])
        return None
    if response.get('Item'):
        item = {'tags': response['Item'].get('tags', {})}
    else:
        item = None
    return item


def get_all_transfers_table(db_client, table_name,  **scanparams):
    # maxResults=0, nextToken=None
    table = db_client.Table(table_name)
    response = table.scan(**scanparams)
    jsontext = {'transferList':  list(response['Items'])}
    # print(list(response['Items']))
    if response.get('LastEvaluatedKey', None) is not None:
        # base 64 encode it
        s = json.dumps(response.get('LastEvaluatedKey'))
        jsontext['nextToken'] = base64.b64encode(s.encode('utf-8')).decode()
    return jsontext


def get_s3_tags(s3resource, bucket, key, logger=None):
    try:
        response = s3resource.meta.client.get_object_tagging(Bucket=bucket, Key=key)
        tags = response['TagSet']
        return tags
    except Exception as e:
        if logger:
            logger.severe(f"Exception reading tags on s3://{bucket}/{key}, exception {e}.")
        tags = []
        return tags


def put_s3_tags(s3resource, bucket, key, tag_set=None, logger=None):
    try:
        response = s3resource.meta.client.put_object_tagging(Bucket=bucket, Key=key,  Tagging={'TagSet': tag_set})
        success = response['ResponseMetadata']['HTTPStatusCode'] == 200
        if not success:
            if logger:
                logger.severe(f"Failure indicated in response to put tags operation, response={response}")
            return False
        return True
    except Exception as e:
        if logger:
            logger.severe(f"Exception writing tags on s3://{bucket}/{key}, exception {e}.")
        return False


def copy_s3_object(s3resource=None, source_bucket=None,
                   destination_bucket=None,
                   src_object_name=None,
                   mapping_id=None, dst_object_name=None,
                   include_s3_tags=False, logger=None):
    copy_source = {'Bucket': source_bucket, 'Key': src_object_name}
    try:
        # we use copy versus copy_object since it supports multipart and larger
        # files in s3 prepend the mapping id to the destination object name
        destination_name = f"{mapping_id}/{src_object_name}"
        if dst_object_name is not None:
            destination_name = f"{mapping_id}/{dst_object_name}"
        _ = s3resource.meta.client.copy(CopySource=copy_source,
                                        Bucket=destination_bucket,
                                        Key=destination_name)
        # Adding tagging since copy method for large objects (multipart) does
        # not copy tags.
        if not include_s3_tags:
            tagSet = []
        else:
            tagSet = get_s3_tags(s3resource, source_bucket, src_object_name, logger)

        put_s3_tags(s3resource=s3resource, bucket=destination_bucket,
                    key=destination_name, tag_set=tagSet, logger=logger)
        return True
    except Exception as e:
        if logger:
            logger.info(f"No object with name {src_object_name}, exception {e}.")
        return False


def copy_s3_object_manifest(s3resource=None, source_bucket=None, destination_bucket=None,
                            src_payload_name=None, src_manifest_name=None,
                            mapping_id='', transfer_id='',
                            include_s3_tags=False, logger=None):
    """
        In payload file add a key x-amz-meta-diode-linked-manifest-s3-key with name of manifest
        In manifest file add a key x-amz-meta-diode-linked-payload-s3-key with name of payload
        Manifest needs to be renamed at save time with transferid_manifestname. The diode service
        does not currently include the object tags for the manifest file, only the payload if
        asked for by the customer.
    :param s3resource:
    :param source_bucket:
    :param destination_bucket:
    :param src_payload_name:
    :param src_manifest_name:
    :param mapping_id:
    :param transfer_id:
    :param include_s3_tags:
    :param logger:
    :return: True if success, False otherwise
    """
    copy_payload_source = {'Bucket': source_bucket, 'Key': src_payload_name}
    copy_manifest_source = {'Bucket': source_bucket, 'Key': src_manifest_name}
    # prepend the mapping id to the destination object name
    destination_payload_name = f"{mapping_id}/{src_payload_name}"
    # destination manifest name must have the transferid prepended to the base name of the manifest not the path
    if len(os.path.dirname(src_manifest_name)) == 0:
        destination_manifest_name = f"{mapping_id}/{transfer_id}_{src_manifest_name}"
    else:
        destination_manifest_name = (f"{mapping_id}/{os.path.dirname(src_manifest_name)}/{transfer_id}_"
                                     f"{os.path.basename(src_manifest_name)}")
    try:
        # we use copy versus copy_object since it supports multipart and larger files in s3
        # Copy the payload and include the meta data for the manifest
        _ = s3resource.meta.client.copy(CopySource=copy_payload_source,
                                        Bucket=destination_bucket,
                                        Key=destination_payload_name,
                                        ExtraArgs={"Metadata": {'x-amz-meta-diode-linked-manifest-s3-key':
                                                                f"{transfer_id}_{src_manifest_name}"},
                                                   "MetadataDirective": 'REPLACE'})
        # Adding tagging since copy method for large objects (multipart) does
        # not copy tags.
        if not include_s3_tags:
            tagSet = []
        else:
            tagSet = get_s3_tags(s3resource, source_bucket, src_payload_name, logger)
        put_s3_tags(s3resource=s3resource, bucket=destination_bucket,
                    key=destination_payload_name, tag_set=tagSet, logger=logger)
        if logger:
            logger.debug(f"{transfer_id} payload {src_payload_name} copied to "
                         f"{destination_bucket}/{destination_payload_name}")
        # Copy the manifest and include the meta data for the payload
        _ = s3resource.meta.client.copy(CopySource=copy_manifest_source, Bucket=destination_bucket,
                                        Key=destination_manifest_name,
                                        ExtraArgs={"Metadata": {'x-amz-meta-diode-linked-payload-s3-key':
                                                                f"{src_payload_name}"},
                                                   "MetadataDirective": 'REPLACE'})
        if logger:
            logger.debug(f"{transfer_id} manifest {src_manifest_name} copied to "
                         f"{destination_bucket}/{destination_manifest_name}")
        no_tags = []
        # remove the tags on the manifest (always) since diode service never
        # includes manifest tags
        put_s3_tags(s3resource=s3resource, bucket=destination_bucket,
                    key=destination_manifest_name, tag_set=no_tags,
                    logger=logger)
        return True
    except Exception as e:
        if logger:
            logger.info(f"Unable to copy payload {src_payload_name} and/or "
                        f"manifest {src_manifest_name}, exception {e}.")
        # clean up one of the files that may have copied successfully so as not to leave remnants from
        # a failed transactional copy so delete both files - one delete may fail due to this but ok to fail it
        delete_s3_object(s3resource, destination_bucket, destination_payload_name, logger=logger)
        delete_s3_object(s3resource, destination_bucket, destination_manifest_name, logger=logger)
        return False


def delete_s3_object(s3resource, bucket, key, logger=None):
    """
    This is a delete object method and it is expected to succeed, we return False if unable to delete
    the object.
    :param s3resource:
    :param bucket:
    :param key:
    :param logger:
    :return:
    """
    try:
        response = s3resource.meta.client.delete_object(Bucket=bucket, Key=key)
        # 204 is normal response from a delete on S3
        if response['ResponseMetadata']['HTTPStatusCode'] != 204:
            if logger:
                logger.error(f"error deleting {bucket}/{key} response={response}")
            return False
        else:
            return True
    except Exception as e:
        if logger:
            logger.info(f"Exception trying to delete {bucket}/{key} exception {e}")
        return False


def read_data_from_s3(bucket=None, key=None, region='us-east-1', logger=None):
    if bucket and key:
        s3 = get_s3_client(get_session(region=region))
        try:
            obj = s3.Object(bucket, key)
            response = obj.get()
            if response and response['ResponseMetadata']['HTTPStatusCode'] == 200:
                data = response.get('Body').read()
                return data
            return None
        except Exception as e:
            if logger:
                logger.error(f"Error reading S3 object s3://{bucket}/{key} "
                             f"exception: {e}")
            return None
    if logger:
        logger.error(f"In read_data_from_s3 - passed bucket and/or key was None.")
    return None


def write_data_to_s3(bucket=None, key=None, data=None, region='us-east-1', logger=None):
    if bucket and key and data:
        s3 = get_s3_client(get_session(region=region))
    try:
        _ = s3.Object(bucket, key).put(Body=data)
        return True
    except Exception as e:
        logger.error("Error writing manifest data to s3://%s/%s exception: %s " % (bucket, key, e))
        return False


def make_mapping_arn_prefix(account_num="123456789012"):
    return f"arn:aws:diode:localhost:{account_num}:account-mapping/"


def get_mapping_id_from_mapping_arn(mapping_arn, account_num="123456789012"):
    # verify it is a proper formatted mapping arn with account number
    if mapping_arn.find(make_mapping_arn_prefix(account_num)) == 0:
        pos_mapping_id = mapping_arn.rfind('/')
        mapping_id = mapping_arn[pos_mapping_id+1:]
        return mapping_id
    else:
        return None


def make_transfer_arn_prefix(account_num="123456789012"):
    return f"arn:aws:diode:localhost:{account_num}:transfer/"


def get_transfer_id_from_transfer_arn(transfer_arn, account_num="123456789012"):
    # verify it is a proper formatted mapping arn with account number
    if transfer_arn.find(make_transfer_arn_prefix(account_num)) == 0:
        pos_transfer_id = transfer_arn.rfind('/')
        transfer_id = transfer_arn[pos_transfer_id+1:]
        return transfer_id
    else:
        return None


def MBtoBytes(num_MB):
    return 1024 * 1024 * num_MB


def environment_value_as_type(name, **kwargs):

    # Retrieves environment variable by name and casts the value to desired type.
    # Cloudformation and environment variables in general come in as strings.

    default_value = kwargs.pop('default', None)
    desired_type = kwargs.pop('type', str)

    value = name

    if value is None:
        if default_value is None:
            return None
        else:
            return default_value

    # This code deals with boolean types returned via environment variables and
    # handles the case where CF stores the value as true and false as strings
    # as well as handling the case where it might be True or False by converting
    # the string to all lowercase and handling it explicitly.
    if desired_type is bool:
        # boolean values from CF are returned as true and false not True and False
        if type(value) is str:
            if value.lower() == 'true':
                value = True
            elif value.lower() == 'false':
                value = False

    return desired_type(value)

import os
import boto3
import hashlib
import logging

logger = logging.getLogger()

"""
NOTE: Chunk size can affect performance, on a 500MB file:
            64MB Chunksize took 00:16 (16 seconds)
            128MB Chunksize took 00:12 (12 seconds)
            256MB Chunksize took 00:16 (16 seconds)
            512MB Chunksize took 00:33 (33 seconds)
"""

CHUNKSIZE = 12 * 1024 * 1024


def calculate_chunk_ranges(total_bytes, chunk_size):
    start_bytes = list(range(0, total_bytes, chunk_size))
    stop_bytes = [min(total_bytes - 1, start_byte + (chunk_size - 1)) for start_byte in start_bytes]
    # returns list of range tuples = [(0,(start1,stop1)), ..., (N, (start-N, stop-N))]
    return list(enumerate(list(zip(start_bytes, stop_bytes)), 0))


def lambda_handler(event, context):
    logger.setLevel(_get_logging_level_from_string(log_level=os.getenv("LOG_LEVEL")))

    bucket = event["bucket"]
    key = event["key"]
    start_byte = int(event["start_byte"])
    stop_byte = int(event["stop_byte"])
    total_bytes = stop_byte - start_byte + 1
    block_num = int(event["block_num"])
    hash_algorithm = event.get("hash_algorithm", '')
    if hash_algorithm not in ['SHA256', 'SHA384', 'SHA512']:
        hash_algorithm = 'SHA256'

    logger.debug(f"blocknum={block_num}, start_byte={start_byte}, "
                 f"stop_byte={stop_byte}, key={key}, hash_algorithm={hash_algorithm}")
    # return a result for testing
    result = {
        'blocknum': block_num,
        'value': "somehashvaluebasedonalgorithm",
        'md5': "somemd5value",
        'errornum': 0
    }
    # return result
    ranges = calculate_chunk_ranges(total_bytes, CHUNKSIZE)
    s3_client = boto3.client('s3')
    # bytes_read = s3_client.get_object(Bucket=bucket, Key=key, Range="bytes=%d-%d" % (0, 10))["Body"].read()
    # print("read 10 bytes of file")
    # initialize proper algorithm - default to 256
    hash_value = hashlib.sha256()
    if hash_algorithm == 'SHA384':
        hash_value = hashlib.sha384()
    elif hash_algorithm == 'SHA512':
        hash_value = hashlib.sha512()
    md5_hash = hashlib.md5()
    # Loop through and read 64MB at a time of the file and compute the hash
    try:
        for r in ranges:
            startrange = r[1][0] + start_byte
            endrange = r[1][1] + start_byte
            range_idx = r[0]
            bytes_read = s3_client.get_object(Bucket=bucket, Key=key, Range="bytes=%d-%d" % (startrange, endrange))[
                "Body"].read()
            hash_value.update(bytes_read)
            md5_hash.update(bytes_read)
        readable_hash_value = hash_value.hexdigest()
        readable_md5hash = md5_hash.hexdigest()
        return {
            'blocknum': block_num,
            'value': readable_hash_value,
            'md5': readable_md5hash,
            'errornum': 0
        }
    except Exception as e:
        logger.error(e)
        logger.error(f"Could not find object with name {key} in bucket {bucket}, may not exist.")
        return {
            'blocknum': block_num,
            'value': None,
            'md5': None,
            'errornum': 1
        }


def _get_logging_level_from_string(log_level: str = 'info'):
    try:
        logging_level = {
            "critical": logging.CRITICAL,
            "error": logging.ERROR,
            "warning": logging.WARNING,
            "info": logging.INFO,
            "debug": logging.DEBUG
        }[log_level.strip().lower()]
    except (KeyError, Exception):
        logging_level = logging.INFO
    return logging_level

These lambda functions are directly from the pymanifestgenerator package that
is available to customers to compute manifests. The diode simulator uses the
same code base to perform the hash calculations for blocks in S3.

Please contact the diode team at awsdiode@amazon.com for more information
on this package.
# Copyright 2019 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS
# OF ANY KIND, either express or implied. See the License for the specific
# language governing permissions and limitations under the License.

# NOTE: this class requires the use of the Python XML pyopenssl, lxml. json2xml, and boto3 library.  All other
# libraries should be part of a standard python 3 install.
#   pip3 install pyopenssl
#   pip3 install lxml
#   pip3 install json2xml
#   pip3 install boto3

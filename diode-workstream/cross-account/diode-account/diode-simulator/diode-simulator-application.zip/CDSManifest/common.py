# Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS
# OF ANY KIND, either express or implied. See the License for the specific
# language governing permissions and limitations under the License.

NS_TDF_SCHEMA = "urn:us:gov:ic:tdf"
NS_TDF_SOFTWARE_SCHEMA = "urn:us:gov:ic:cdsmanifest"

# TDF Tags Section

TAG_TDF_TRUSTEDDATAOBJECT = "{%s}TrustedDataObject" % NS_TDF_SCHEMA
TAG_TDF_ATTR_VERSION = "{%s}version" % NS_TDF_SCHEMA
TAG_TDF_ASSERTION = "{%s}Assertion" % NS_TDF_SCHEMA
TAG_TDF_BINDING = "{%s}Binding" % NS_TDF_SCHEMA
TAG_TDF_SIGNER = "{%s}Signer" % NS_TDF_SCHEMA
TAG_TDF_SIGNATUREVALUE = "{%s}SignatureValue" % NS_TDF_SCHEMA
TAG_TDF_REFERENCEVALUEPAYLOAD = "{%s}ReferenceValuePayload" % NS_TDF_SCHEMA
TAG_TDF_STRUCTURED_STATEMENT = "{%s}StructuredStatement" % NS_TDF_SCHEMA

TAG_TDF_ATTR_URI = "{%s}uri" % NS_TDF_SCHEMA
TAG_TDF_ATTR_MEDIATYPE = "{%s}mediaType" % NS_TDF_SCHEMA
TAG_TDF_ATTR_SCOPE = "{%s}scope" % NS_TDF_SCHEMA
TAG_TDF_ATTR_SUBJECT = "{%s}subject" % NS_TDF_SCHEMA
TAG_TDF_ATTR_ISSUER = "{%s}issuer" % NS_TDF_SCHEMA
TAG_TDF_ATTR_SIGNATUREALGORITHM = "{%s}signatureAlgorithm" % NS_TDF_SCHEMA
TAG_TDF_ATTR_NORMALIZATIONMETHOD = "{%s}normalizationMethod" % NS_TDF_SCHEMA
TAG_TDF_ATTR_INCLUDESTATEMENTMETADATA = "{%s}includesStatementMetadata" % NS_TDF_SCHEMA

# TDF Software Tags Section

TAG_TDF_SOFTWARE_SOFTWARE = "{%s}CdsManifestAssertion" % NS_TDF_SOFTWARE_SCHEMA
TAG_TDF_SOFTWARE_SOFTWARE_DESVERSION = "{%s}DESVersion" % NS_TDF_SOFTWARE_SCHEMA
TAG_TDF_SOFTWARE_HASH = "{%s}Hash" % NS_TDF_SOFTWARE_SCHEMA
TAG_TDF_SOFTWARE_HASHVERIFICATION = "{%s}HashVerification" % NS_TDF_SOFTWARE_SCHEMA
TAG_TDF_SOFTWARE_VIRUSSCANLIST = "{%s}VirusScanList" % NS_TDF_SOFTWARE_SCHEMA
TAG_TDF_SOFTWARE_VIRUSSCAN = "{%s}VirusScan" % NS_TDF_SOFTWARE_SCHEMA
TAG_TDF_SOFTWARE_VIRUSVENDOR = "{%s}ScanVendor" % NS_TDF_SOFTWARE_SCHEMA
TAG_TDF_SOFTWARE_VIRUSVENDORSCANVERSION = "{%s}ScanVersion" % NS_TDF_SOFTWARE_SCHEMA
TAG_TDF_SOFTWARE_VIRUSSIGNATUREDATE = "{%s}SignatureDate" % NS_TDF_SOFTWARE_SCHEMA
TAG_TDF_SOFTWARE_VIRUSRESULT = "{%s}ScanResult" % NS_TDF_SOFTWARE_SCHEMA
TAG_TDF_SOFTWARE_VENDORCHECKSUM = "{%s}VendorChecksum" % NS_TDF_SOFTWARE_SCHEMA
TAG_TDF_SOFTWARE_ORIGINATOR = "{%s}Originator" % NS_TDF_SOFTWARE_SCHEMA
TAG_TDF_SOFTWARE_PRODUCT = "{%s}Product" % NS_TDF_SOFTWARE_SCHEMA
TAG_TDF_SOFTWARE_VERSION = "{%s}PayloadVersion" % NS_TDF_SOFTWARE_SCHEMA
TAG_TDF_SOFTWARE_CPE = "{%s}CPE" % NS_TDF_SOFTWARE_SCHEMA
TAG_TDF_SOFTWARE_ARCH = "{%s}Arch" % NS_TDF_SOFTWARE_SCHEMA
TAG_TDF_SOFTWARE_ROUTING = "{%s}Routing" % NS_TDF_SOFTWARE_SCHEMA
TAG_TDF_SOFTWARE_WORKFLOWID = "{%s}WorkFlowid" % NS_TDF_SOFTWARE_SCHEMA
TAG_TDF_SOFTWARE_USERKEY = "{%s}Userkey" % NS_TDF_SOFTWARE_SCHEMA
TAG_TDF_SOFTWARE_SHA256 = "{%s}SHA256" % NS_TDF_SOFTWARE_SCHEMA
TAG_TDF_SOFTWARE_MD5 = "{%s}MD5" % NS_TDF_SOFTWARE_SCHEMA

TAG_TDF_SOFTWARE_ATTR_BLOCKSIZE = "{%s}blockSize" % NS_TDF_SOFTWARE_SCHEMA
TAG_TDF_SOFTWARE_ATTR_TOTALBLOCKS = "{%s}totalBlocks" % NS_TDF_SOFTWARE_SCHEMA
TAG_TDF_SOFTWARE_ATTR_TOTALHASH = "{%s}totalHash" % NS_TDF_SOFTWARE_SCHEMA
TAG_TDF_SOFTWARE_ATTR_HASHTYPE = "{%s}hashType" % NS_TDF_SOFTWARE_SCHEMA
TAG_TDF_SOFTWARE_ATTR_BLOCK = "{%s}block" % NS_TDF_SOFTWARE_SCHEMA
TAG_TDF_SOFTWARE_ATTR_VALUE = "{%s}value" % NS_TDF_SOFTWARE_SCHEMA


# Mainly used for XPath purposes.
NSMAP = {
    "tdf": "urn:us:gov:ic:tdf",
    "cdsm": "urn:us:gov:ic:cdsmanifest",
    "xsi": "http://www.w3.org/2001/XMLSchema-instance",
    "ds": "http://www.w3.org/2000/09/xmldsig#",
}

XPATH_EXTRACT_ASSERTION = "/tdf:TrustedDataObject/tdf:Assertion"
XPATH_EXTRACT_STRUCTURED_STATEMENT = "/tdf:TrustedDataObject/tdf:Assertion/tdf:StructuredStatement"
XPATH_EXTRACT_BINDING = "/tdf:TrustedDataObject/tdf:Assertion/tdf:Binding"
XPATH_EXTRACT_REFERENCE_VALUE_PAYLOAD = "/tdf:TrustedDataObject/tdf:ReferenceValuePayload"
XPATH_EXTRACT_HASH_VERIFICATION_ROOT = "/tdf:TrustedDataObject/tdf:Assertion/tdf:StructuredStatement/cdsm:CdsManifestAssertion/cdsm:HashVerification"
XPATH_EXTRACT_HASHBLOCK_ROOT = "/tdf:TrustedDataObject/tdf:Assertion/tdf:StructuredStatement/cdsm:CdsManifestAssertion/cdsm:HashVerification/cdsm:Hash[@cdsm:block=\"{}\"]"


# These XPath operations start from the root of the signed portion of the document - only used in verify code
XPATH_EXTRACT_VENDOR_CHECKSUM = "/tdf:StructuredStatement/cdsm:CdsManifestAssertion/cdsm:VendorChecksum"
XPATH_EXTRACT_HASH_VERIFICATION = "/tdf:StructuredStatement/cdsm:CdsManifestAssertion/cdsm:HashVerification"
XPATH_EXTRACT_HASHBLOCK = "/tdf:StructuredStatement/cdsm:CdsManifestAssertion/cdsm:HashVerification/cdsm:Hash[@cdsm:block=\"{}\"]"

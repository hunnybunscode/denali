# Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS
# OF ANY KIND, either express or implied. See the License for the specific
# language governing permissions and limitations under the License.

# NOTE: this class requires the use of the Python XML pyopenssl, lxml. json2xml, and boto3 library.  All other
# libraries should be part of a standard python 3 install.
#   pip3 install pyopenssl
#   pip3 install lxml
#   pip3 install json2xml
#   pip3 install boto3
import os
import sys
import binascii
import hashlib
import json
import logging as logcheck
from json2xml import json2xml
import lxml.etree as ET
import io
from typing import Optional
from botocore.config import Config
import botocore
import botocore.exceptions
import botocore.session
from io import BytesIO
import OpenSSL.crypto
path = os.path.abspath(os.path.join(os.path.dirname(__file__)))
if path not in sys.path:
    sys.path.insert(1, path)
del path
import tomorrow as tomorrow
from common import (NSMAP, XPATH_EXTRACT_ASSERTION, XPATH_EXTRACT_STRUCTURED_STATEMENT,
                    XPATH_EXTRACT_REFERENCE_VALUE_PAYLOAD, XPATH_EXTRACT_BINDING,
                    TAG_TDF_BINDING, TAG_TDF_SIGNATUREVALUE,
                    TAG_TDF_SOFTWARE_HASHVERIFICATION, XPATH_EXTRACT_HASH_VERIFICATION_ROOT,
                    XPATH_EXTRACT_HASHBLOCK_ROOT, TAG_TDF_SOFTWARE_HASH, TAG_TDF_SOFTWARE_ATTR_HASHTYPE,
                    TAG_TDF_SOFTWARE_ATTR_BLOCKSIZE, TAG_TDF_SOFTWARE_ATTR_TOTALBLOCKS,
                    TAG_TDF_SOFTWARE_ATTR_TOTALHASH, TAG_TDF_SOFTWARE_VIRUSSCANLIST, TAG_TDF_SOFTWARE_VIRUSSCAN,
                    TAG_TDF_SOFTWARE_VIRUSVENDOR,
                    TAG_TDF_SOFTWARE_VIRUSVENDORSCANVERSION, TAG_TDF_SOFTWARE_VIRUSSIGNATUREDATE,
                    TAG_TDF_SOFTWARE_VIRUSRESULT, TAG_TDF_SOFTWARE_ATTR_BLOCK, TAG_TDF_SOFTWARE_ATTR_VALUE,
                    TAG_TDF_SIGNER, TAG_TDF_ATTR_SUBJECT, TAG_TDF_ATTR_ISSUER, TAG_TDF_ATTR_SIGNATUREALGORITHM,
                    TAG_TDF_ATTR_NORMALIZATIONMETHOD, TAG_TDF_ATTR_INCLUDESTATEMENTMETADATA,
                    TAG_TDF_SOFTWARE_SHA256, TAG_TDF_ATTR_URI, TAG_TDF_SOFTWARE_MD5,
                    TAG_TDF_ATTR_SCOPE, TAG_TDF_SOFTWARE_ARCH,
                    TAG_TDF_SOFTWARE_ROUTING, TAG_TDF_SOFTWARE_WORKFLOWID, TAG_TDF_SOFTWARE_USERKEY,
                    TAG_TDF_SOFTWARE_CPE, TAG_TDF_SOFTWARE_PRODUCT,
                    TAG_TDF_ATTR_MEDIATYPE, TAG_TDF_SOFTWARE_ORIGINATOR,
                    TAG_TDF_SOFTWARE_VERSION, TAG_TDF_SOFTWARE_SOFTWARE_DESVERSION,
                    TAG_TDF_ASSERTION, TAG_TDF_SOFTWARE_SOFTWARE, TAG_TDF_ATTR_VERSION,
                    TAG_TDF_REFERENCEVALUEPAYLOAD,
                    TAG_TDF_SOFTWARE_VENDORCHECKSUM, TAG_TDF_STRUCTURED_STATEMENT,
                    TAG_TDF_TRUSTEDDATAOBJECT)

from utils import get_value_in_xml_tag, get_etree, parse, get_attr_value_in_xml_tag
from aws_utils import get_session, get_s3_client, split_s3_bucket_key, get_size_s3_object, read_data_s3, get_kms_client
# open access to diode api for SWAMS
os.environ['AWS_DATA_PATH'] = '../models'

# kms has an upper limit on data size to sign of 4K
kms_maximum_allowed_data_size = 4096

__version__ = 4.4

# This is how many local threads to run in parallel to compute hashes on files not being handled using S3 and Lambda
NUM_HASH_THREADS = 10


class Hashes:
    # Simple class to hold values from multi-thread hash computation and error state
    def __init__(self, blocknum=0, value=None, md5=None, errornum=0, retrycount=0):
        self.blocknum = blocknum
        self.value = value
        self.md5 = md5
        self.errornum = errornum
        self.retrycount = retrycount


class AwsCdsManifest(object):
    logger = None
    AWS_REGION = 'us-east-1'  # can be overriden by call to generate_manifest method
    multi_thread = False
    lambda_function_name = None
    payload_name = ''
    log_prefix = ''

    namespaces_map = {
        None: 'urn:us:gov:ic:tdf',
        'tdf': 'urn:us:gov:ic:tdf',
        'xsi': 'http://www.w3.org/2001/XMLSchema-instance',
        'sign': 'http://www.w3.org/2000/09/xmldsig#'
    }
    cdsm_namespaces_map = {
        None: 'urn:us:gov:ic:cdsmanifest',
        'cdsm': 'urn:us:gov:ic:cdsmanifest'
    }

    def __init__(self, aws_region='us-east-1', logger=None, log_prefix=''):
        """
        Initializer for class
        :param aws_region: string representation of aws region where service is being used
        :param logger: logger instance to use
        :param log_prefix: optional prefix to prepend log messages with (useful for multi
        thread systems to identify messages with thread id)
        """
        if logger is None:
            raise OSError(f"{log_prefix}Please provide a valid logger for messages")
        self.logger = logger
        if not log_prefix:
            self.log_prefix = ''
        else:
            self.log_prefix = log_prefix
        self.AWS_REGION = aws_region
        self.multi_thread = False
        self.lambda_function_name = None
        self.logger.info(f"{self.log_prefix}AwsCdsManifest version {__version__} object created.")

    """
    The following are the public accessible methods of this class
        if either private_key_file or public_cert_file are empty then an unsigned manifest is returned
    """
    def get_version(self) -> str:
        """
        Returns the version of the class as a string
        :return:
        """
        return f"{__version__}"

    def generate_manifest(self, payload_name=None, template_file=None, template_data_as_json=None,
                          templ_xsd=None, blksize=256, hash_algorithm="SHA256",
                          lambda_function_name=None, multi_thread=False) -> (int, Optional[str]):
        """
        This method will generate a manifest, but NOT sign it. The manifest is returned
        as an xml object.
        :param payload_name:
        :param template_file: path to xml or json file
        :param template_data_as_json: template data as json (not a string)
        :param templ_xsd:
        :param blksize:
        :param hash_algorithm:
        :param lambda_function_name:
        :param multi_thread:
        :return: an integer of 0 or 1, if 0 return generated manifest
        """
        if payload_name is None or len(payload_name) < 3:
            raise ValueError(f"{self.log_prefix}payload name must be valid")
        self.multi_thread = multi_thread
        self.lambda_function_name = lambda_function_name
        self.logger.debug(f"{self.log_prefix}Multi thread hash computation is set to {multi_thread}")
        # verify existence of payload by getting it's size
        try:
            size_payload = self.__get_payload_size(payload_name=payload_name)
            self.logger.debug(f"{self.log_prefix}Payload located and existence verified.")
        except OSError as ioe:
            raise OSError(f"{self.log_prefix}Error with obtaining access to specified payload exception {ioe}")
        if size_payload == -1:
            raise OSError("{log_prefix}Error with obtaining access to specified payload.")
        if templ_xsd is None:
            current_directory = os.path.dirname(os.path.abspath(__file__))
            # package_location = os.path.dirname(current_directory)
            # self.logger.debug(f"current directory is {package_location}")
            template_xsd_file = os.path.join(current_directory, "../Reference_XSDs", "template.xsd")
            self.logger.info(f"{self.log_prefix}Using internally provided schema {template_xsd_file}.")
        else:
            template_xsd_file = templ_xsd
            self.logger.info(f"{self.log_prefix}Using schema {template_xsd_file}.")

        if template_data_as_json is not None:
            # process json provided data for template
            template_as_xml = self.__obtain_template_data_as_xml_from_json(template_xsd_file=template_xsd_file,
                                                                           json_data=template_data_as_json)
            if template_as_xml is None:
                raise ValueError(f"{self.log_prefix}error parsing json data to xml file - exiting.")
        else:
            # process template data as a file (either xml or json)
            if not os.path.exists(template_file):
                raise ValueError(f"{self.log_prefix}Input template file at {template_file} cannot be found.")
            template_as_xml = self.__obtain_template_data_as_xml(template_file=template_file,
                                                                 template_xsd_file=template_xsd_file)
            if template_as_xml is None:
                raise ValueError(f"{self.log_prefix}error reading the template file - exiting.")

        if hash_algorithm not in ['SHA256', 'SHA384', 'SHA512']:
            raise ValueError(f"{self.log_prefix}hash algorithm must be either SHA256, SHA384 or SHA512")

        # arguments checking is done - now generate the manifest
        root = self.__generate_base_xml(payload_name=payload_name,
                                        template_xml=template_as_xml,
                                        hash_algorithm=hash_algorithm,
                                        shortened_block_size=blksize)
        if root is None:
            return 1, None
        return 0, self.manifest_data_as_string(root)

    def manifest_file_as_string(self, manifest_file=None) -> Optional[str]:
        manifest_xml = self.__read_manifest_file_and_return_xml(manifest_file=manifest_file)
        return self.manifest_data_as_string(manifest_xml)

    @staticmethod
    def manifest_data_as_string(manifest) -> Optional[str]:
        if manifest is not None:
            results = ET.tostring(
                manifest,
                encoding='utf8',
                method='xml',
                xml_declaration=True,
                pretty_print=False
            ).decode()
            return results
        return None

    def verify_manifest(self, payload_name=None, manifest_file=None,
                        xml_document: str = None,
                        manifest_xsd_f=None,
                        public_cert_file=None, kms_used=False, kms_arn=None,
                        lambda_function_name=None, multi_thread=False) -> (bool, int):
        if payload_name is None or len(payload_name) < 3:
            raise ValueError(f"{self.log_prefix}payload name must be valid")
        self.multi_thread = multi_thread
        self.lambda_function_name = lambda_function_name
        manifest_xml = self.__read_manifest_file_and_return_xml(manifest_file=manifest_file,
                                                                xml_document=xml_document)
        if manifest_xml is None:
            self.logger.error(f"{self.log_prefix}Error reading the manifest xml file - exiting.")
            return False, 1
        if manifest_xsd_f is None:
            current_directory = os.path.dirname(os.path.abspath(__file__))
            manifest_xsd_file = os.path.join(current_directory, "../Reference_XSDs", "cdsmanifest_tdf.xsd")
        else:
            manifest_xsd_file = manifest_xsd_f
        self.logger.info(f"{self.log_prefix}Using XSD schema {manifest_xsd_file}.")
        if self.__verify_xml_against_xsd(manifest_xml, manifest_xsd_file):
            self.logger.debug(f"{self.log_prefix}Manifest validated against manifest XSD.")
        else:
            self.logger.debug(f"{self.log_prefix}Manifest did not validate against manifest XSD.")
            return False, 2

        validation_result, signed_structured_statement, signed_reference_payload = \
            self.__verify_manifest_signature(manifest_xml,
                                             public_cert_file=public_cert_file,
                                             kms_used=kms_used, kms_arn_alias=kms_arn)
        if validation_result is False:
            self.logger.debug(f"{self.log_prefix}Manifest file does not verify "
                              f"with specified public key/certificate and/or kms arn")
            return False, 1

        # verify payload against values in manifest using only the portion
        # protected by the signature.
        if not self.__verify_hashes_with_payload(payload_name=payload_name,
                                                 manifest_xml=manifest_xml):
            self.logger.error(f"{self.log_prefix}Payload does not verify "
                              f"against the provided hashes in the manifest file.")
            return False, 2
        self.logger.debug(f"{self.log_prefix}Manifest and payload: checksums "
                          f"match, signature verified.")
        return True, 0

    def verify_manifest_signature(self, manifest_file=None,
                                  xml_document: str = None,
                                  public_cert_file=None,
                                  kms_used=False, kms_arn=None) -> bool:
        # verify manifest file signature
        manifest_xml = self.__read_manifest_file_and_return_xml(manifest_file=manifest_file,
                                                                xml_document=xml_document)
        if manifest_xml is None:
            self.logger.error(f"{self.log_prefix}Error reading the manifest "
                              f"xml file - exiting.")
            return False
        validation_result, signed_structured_statement, signed_reference_payload = \
            self.__verify_manifest_signature(manifest_xml,
                                             public_cert_file=public_cert_file,
                                             kms_used=kms_used,
                                             kms_arn_alias=kms_arn)
        if validation_result is False:
            self.logger.error(f"{self.log_prefix}Manifest file does not verify "
                              f"with specified public key/certificate and/or kms arn.")
            return False
        return True

    def verify_hash_of_hashes(self, manifest_file=None, xml_document: str = None) -> bool:
        manifest_xml = self.__read_manifest_file_and_return_xml(manifest_file=manifest_file,
                                                                xml_document=xml_document)
        if manifest_xml is None:
            self.logger.error(f"{self.log_prefix}Error reading the manifest xml file - exiting.")
            return False
        # pass the root xml document and the total hash will be recomputed and compared to what is in the manifest
        ok = self.__verify_hash_of_hashes(manifest_xml=manifest_xml)

        if ok:
            self.logger.info(f"{self.log_prefix}Manifest file hashes match hashes of hashes value.")
        else:
            self.logger.info(f"{self.log_prefix}Manifest file hashes did not match hashes of hashes value.")
        return ok

    def sign_manifest_using_priv_pub_keys(self, private_key_file=None,
                                          public_cert_file=None, passphrase=None,
                                          xml_file=None, xml_document: str = None) -> Optional[str]:
        """
                This method allows users to just provide a manifest file and have it
                properly signed using private/public keys.
                :param private_key_file: private key file in pem format (e.g. samples/examplekey.pem)
                :param public_cert_file: corresponding public cert file for private key (e.g. samples/examplecert.pem)
                :param passphrase: passphrase for private key file if present
                :param xml_file: provide the full path to the unsigned manifest file s3 prefix or file system
                :param xml_document: provide the data as xml document as a string - either file or document not both
                :return:
                """
        if private_key_file and len(private_key_file) > 0 and \
                public_cert_file and len(public_cert_file) > 0:
            self.logger.debug(f"{self.log_prefix}Private key file: {private_key_file} "
                              f"is being used to sign manifest.")
        else:
            self.logger.warning(f"{self.log_prefix}No private key or public "
                                f"cert provided-manifest is not being signed.")
            return None

        xmlroot = self.__read_manifest_file_and_return_xml(manifest_file=xml_file,
                                                           xml_document=xml_document)
        # if xml_document is not None:
        #     # xmlroot = xml_document.getroot()
        #     # xmlroot = copy.deepcopy(xml_document)
        #     if isinstance(xml_document, str):
        #         xmlroot = ET.fromstring(xml_document.encode())
        #     else:
        #         xmlroot = xml_document.getroot()
        # elif xml_file is not None:
        #     xmlroot = self.__read_manifest_file_and_return_xml(manifest_file=xml_file)
        # else:
        #     xmlroot = None

        if xmlroot is None:
            self.logger.error(f"{self.log_prefix}Unable to generate root element"
                              f" for provided xml data source")
            return None
        signed_root = self.__signit(xmlroot=xmlroot,
                                    private_key_file=private_key_file,
                                    passphrase=passphrase,
                                    public_cert_file=public_cert_file)
        if signed_root is None:
            self.logger.error(f"{self.log_prefix}Unable to sign xml root "
                              f"with key and/or passphrase provided, exiting...")

        return self.manifest_data_as_string(signed_root)

    def sign_manifest_using_kms(self, kms_key_alias='', issuer='not provided',
                                subject='not provided', xml_file=None,
                                xml_document=None) -> Optional[str]:
        # xmlroot = None
        # if xml_document is not None:
        #     if isinstance(xml_document, str):
        #         xmlroot = ET.fromstring(xml_document.encode())
        #     else:
        #         xmlroot = xml_document.getroot()
        # elif xml_file is not None:
        #     xmlroot = self.__read_manifest_file_and_return_xml(manifest_file=xml_file)

        xmlroot = self.__read_manifest_file_and_return_xml(manifest_file=xml_file,
                                                           xml_document=xml_document)

        if xmlroot is None:
            self.logger.error(f"{self.log_prefix}Unable to generate root element"
                              f" for provided xml data source")
            return None

        signed_root = self.__signit(xmlroot=xmlroot, kms_alias=kms_key_alias,
                                    kms_issuer=issuer, kms_subject=subject)
        if signed_root is None:
            self.logger.error(f"{self.log_prefix}Unable to sign xml root "
                              f"with key and/or passphrase provided, exiting...")

        return self.manifest_data_as_string(signed_root)

    def sign_swams_manifest_using_priv_pub_keys(self, mapping_id=None,
                                                transfer_manifest_id=None,
                                                private_key_file=None,
                                                public_cert_file=None,
                                                passphrase=None) -> Optional[str]:
        """
                This public method is used when the manifest has been generated
                by the Diode SWAMS service. The caller provides the mapping id
                and transfer manifest id from swams to sign the manifest.
                :param mapping_id: mapping id used by swams to generate the
                    mapping (this must be an SA mapping in diode)
                :param transfer_manifest_id: the manifest tansfer id returned
                    by swams from the generate call
                :param private_key_file: private key file in pem format
                    (e.g. samples/examplekey.pem)
                :param public_cert_file: corresponding public cert file for
                    private key (e.g. samples/examplecert.pem)
                :param passphrase: passphrase for private key file if present
                :return: signed manifest as a str or None if there was an error
                """
        if mapping_id is None or transfer_manifest_id is None:
            raise ValueError("must pass a mapping id and transfer_manifest id "
                             "to use this method.")
        manifest_data = self.__retrieve_swams_manifest(mapping_id=mapping_id,
                                                       transfer_manifest_id=transfer_manifest_id)
        if manifest_data is None:
            return None
        xmlroot = ET.fromstring(manifest_data)
        self.logger.info(f"Manifest retrieved with Manifest Id "
                         f"{transfer_manifest_id}.")
        # call the signer now that the manifest has been pulled from swams
        signed_root = self.__signit(xmlroot=xmlroot,
                                    private_key_file=private_key_file,
                                    passphrase=passphrase,
                                    public_cert_file=public_cert_file)
        if signed_root is None:
            self.logger.error(f"{self.log_prefix}Unable to sign xml root "
                              f"with key and/or passphrase provided, exiting...")
        else:
            self.logger.info(f"Manifest successfully signed.")
        return self.manifest_data_as_string(signed_root)

    def sign_swams_manifest_using_kms(self, mapping_id=None, transfer_manifest_id=None,
                                      kms_key_alias='', issuer='not provided',
                                      subject='not provided') -> Optional[str]:
        """
        This public method is used when the manifest has been generated by the Diode SWAMS service. The
        caller provides the mapping id and transfer manifest id from swams to sign the manifest.
        :param mapping_id: mapping id used by swams to generate the mapping (this must be an SA mapping in diode)
        :param transfer_manifest_id: the manifest tansfer id returned by swams from the generate call
        :param kms_key_alias:
        :param issuer:
        :param subject:
        :return:
        """
        if mapping_id is None or transfer_manifest_id is None:
            raise ValueError("must pass a mapping id and transfer_manifest id to use this method.")
        manifest_data = self.__retrieve_swams_manifest(mapping_id=mapping_id,
                                                       transfer_manifest_id=transfer_manifest_id)
        if manifest_data is None:
            return None
        xmlroot = ET.fromstring(manifest_data)
        self.logger.info(f"Manifest retrieved with Manifest Id "
                         f"{transfer_manifest_id}.")
        # call the kms signer now that the manifest has been pulled from swams
        signed_root = self.__signit(xmlroot=xmlroot, kms_alias=kms_key_alias,
                                    kms_issuer=issuer, kms_subject=subject)
        if signed_root is None:
            self.logger.error(f"{self.log_prefix}Unable to sign xml root "
                              f"with key and/or passphrase provided, exiting...")
        else:
            self.logger.info(f"Manifest successfully signed.")
        return self.manifest_data_as_string(signed_root)
    """
    End of the public accessible class methods
    """

    @staticmethod
    def __calculate_chunk_ranges(total_bytes, chunk_size):
        # TODO: enforce in future max of 10,000 chunks (s3 limit)?
        start_bytes = list(range(0, total_bytes, chunk_size))
        stop_bytes = [min(total_bytes - 1, start_byte + (chunk_size - 1)) for start_byte in start_bytes]
        # returns list of range tuples = [(1,(start1,stop1)), ..., (N, (start-N, stop-N))]
        # change the enumeration index to start at 1 since s3 multipart part numbers begin at 1.
        return list(enumerate(list(zip(start_bytes, stop_bytes)), 1))

    def __generate_block_hashes_for_payload_insert_into_xml(self, payload_name=None,
                                                            software_item=None,
                                                            hash_algorithm=None,
                                                            shortened_block_size=256) -> bool:
        """
        This is the dispatcher to the different methods of computing the block hash codes. If the user has provided
        a property file (and lambda function name) and the object resides in S3 it will dispatch to the lambda processor
        for the hash calculations. If not then it will use one of the local processors to compute the hashes based
        on whether multi-thread is enabled.  These local processors will then call the proper handlers based on
        whether the data must be read from S3 or local disk.
        multi_thread: True or False depending on whether user wants single thread or multi-thread calculations
            done on local files
        lambda_function_name: Name of lambda function - derived from property file passed at startup or during
            call to class method generate_manifest.
        :param shortened_block_size: integer of 128, 256, or 512
        :param hash_algorithm:
        :param software_item: XML where to add the hash codes elements
        :return: True if successful generating block hashes, false if not - overall XML is updated with values.
        """
        hashes_json = self.__generate_block_hashes_for_payload_json(payload_name=payload_name,
                                                                    hash_algorithm=hash_algorithm,
                                                                    shortened_block_size=shortened_block_size)
        if hashes_json is None:
            return False
        # build the xml elements in the software_item element
        hashverification = ET.SubElement(software_item, TAG_TDF_SOFTWARE_HASHVERIFICATION)
        hashverification.set(TAG_TDF_SOFTWARE_ATTR_BLOCKSIZE,
                             str(self.__block_size_from_human_form(shortened_block_size)))
        hashverification.set(TAG_TDF_SOFTWARE_ATTR_HASHTYPE, hash_algorithm)
        num_errors = int(hashes_json.get('errnum'))
        if num_errors != 0:
            self.logger.error(f"{self.log_prefix}Errnum on computation of hashes is not zero, value={num_errors}")
            return False
        hashes = hashes_json['Hash']
        for hash_element in hashes:
            hashblock = ET.SubElement(hashverification, TAG_TDF_SOFTWARE_HASH)
            hashblock.set(TAG_TDF_SOFTWARE_ATTR_BLOCK, str(hash_element['block']))
            hashblock.set(TAG_TDF_SOFTWARE_ATTR_VALUE, hash_element['value'])
        hashverification.set(TAG_TDF_SOFTWARE_ATTR_TOTALBLOCKS, str(hashes_json['totalBlocks']))
        hashverification.set(TAG_TDF_SOFTWARE_ATTR_TOTALHASH, hashes_json['totalHash'])
        return True

    def __generate_block_hashes_for_payload_json(self, payload_name=None,
                                                 hash_algorithm='SHA256',
                                                 shortened_block_size=256):
        """
            This is the dispatcher to the different methods of computing the block hash codes. If the user has provided
            a property file (with a lambda function name) and the object resides in S3 it will dispatch to the lambda
            processor for the hash calculations. If not then it will use one of the local processors to compute the
            hashes based on whether multi-thread is enabled.  These local processors will then call the proper handlers
            based on whether the data must be read from S3 or local disk.

            multi_thread: True or False depending on whether user wants single thread or multi-thread calculations
                done on local files
            lambda_function_name: Name of lambda function - derived from property file passed at startup or during
                call to class method generate_manifest.
            :param hash_algorithm:
            :param shortened_block_size: integer of 128, 256, or 512
            :return: hashes as JSON if successful generating block hashes, None false if not.
        """
        if self.lambda_function_name is not None and payload_name.lower().startswith('s3://'):
            self.logger.debug(f"{self.log_prefix}Calling lambda handler for S3 object")
            hashes_json = \
                self.__hash_block_generation_s3_using_lambda_just_json(payload_name=payload_name,
                                                                       hash_algorithm=hash_algorithm,
                                                                       shortened_block_size=shortened_block_size)
        else:
            if self.multi_thread:
                self.logger.debug(f"{self.log_prefix}Calling multi-threaded hash block generator")
                hashes_json = \
                    self.__hash_block_generation_file_multi_thread_just_json(payload_name=payload_name,
                                                                             hash_algorithm=hash_algorithm,
                                                                             shortened_block_size=shortened_block_size)
            else:
                self.logger.debug(f"{self.log_prefix}Calling single-threaded hash block generator")
                hashes_json = \
                    self.__hash_block_generation_file_one_pass_just_json(payload_name=payload_name,
                                                                         hash_algorithm=hash_algorithm,
                                                                         shortened_block_size=shortened_block_size)
        return hashes_json

    def __hash_block_generation_file_one_pass_just_json(self, payload_name=None,
                                                        hash_algorithm='SHA256',
                                                        shortened_block_size=256):
        """ Creates the json response for the hashes. The file is read and at each blocksize value the hash
        is computed for that block. This method also computes the hash of hashes hash
        values in an attempt at reducing the number of re-reads of the same file.
        The enclosing xml element that the hash-verification should be inserted
        is passed and the the new element is added/appended inside of the enclosing element.

        :param shortened_block_size: integer number of blocksize 128, 256, or 512
        :param hash_algorithm:
        :returns: True if success or False otherwise
        """
        blocksize = self.__block_size_from_human_form(shortened_block_size)
        hash_of_hashes = ''
        numblocks = 0
        self.logger.debug(f"{self.log_prefix}Payload name is {payload_name}")
        filename = payload_name
        results = []
        if filename.lower().startswith("s3://"):
            bucket, key = split_s3_bucket_key(s3_path=filename)
            payload_size = self.__get_payload_size()
            ranges = self.__calculate_chunk_ranges(payload_size, blocksize)
            try:
                s3resource = get_s3_client(get_session(region=self.AWS_REGION))
                obj = s3resource.Object(bucket, key)
                for range_idx in ranges:
                    blocknum = range_idx[0]
                    startbyte = range_idx[1][0]
                    range_read = 'bytes=' + str(startbyte) + '-' + str((startbyte + blocksize - 1))
                    bytes_read = obj.get(Range=range_read)['Body'].read()
                    readable_hash = self.__compute_hash(data=bytes_read, hash_algorithm=hash_algorithm)
                    # md5_hash = hashlib.md5(bytes_read).hexdigest()
                    # result = Hashes(blocknum, readable_hash, md5_hash, 0)
                    result = Hashes(blocknum, readable_hash, None, 0)
                    self.logger.debug(f"{self.log_prefix}Hash computed for "
                                      f"filename={filename} range={range_read}")
                    results.append(result)
                    hash_of_hashes = hash_of_hashes + readable_hash
                    numblocks = blocknum  # just update, when we exit will have total blocks as last blocknum
            except Exception as e:
                self.logger.error(f"{self.log_prefix}Could not find object or "
                                  f"read object with name {key}, may not exist-exception: {e}")
                return None
        else:
            with io.open(payload_name, "rb") as f:
                bytes_read = f.read(blocksize)
                while bytes_read:
                    readable_hash = self.__compute_hash(data=bytes_read, hash_algorithm=hash_algorithm)
                    # md5_hash = hashlib.md5(bytes_read).hexdigest()
                    numblocks = numblocks + 1
                    # result = Hashes(numblocks, readable_hash, md5_hash, 0)
                    result = Hashes(numblocks, readable_hash, None, 0)
                    results.append(result)
                    bytes_read = f.read(blocksize)
                    # append to the block hash accumulator the latest block hash
                    hash_of_hashes = hash_of_hashes + readable_hash
                f.close()
            # because we increment prior to next read must decrement for failed read
            # numblocks = numblocks - 1
        hashed_result_sorted = sorted(results, key=lambda h: h.blocknum)
        hashes_for_payload = [
            {
                "block": str(hash_element.blocknum),
                "value": hash_element.value
            } for hash_element in hashed_result_sorted
        ]
        hashsum = self.__compute_hash(data=str(hash_of_hashes).encode('utf-8'), hash_algorithm=hash_algorithm)
        # now build our resulting json
        full_hashes = {
            "blockSize": str(blocksize),
            "hashType": hash_algorithm,
            "totalBlocks": str(numblocks),
            "totalHash": hashsum,
            "errnum": str('0'),
            "errortext": '',
            "Hash": hashes_for_payload
        }
        return full_hashes

    def __hash_block_generation_s3_using_lambda_just_json(self, payload_name=None,
                                                          hash_algorithm=None,
                                                          shortened_block_size=None):
        """ Creates the json response for the hashes.  The S3 object is read and at each blocksize value the hash
        is computed for that block. This interfaces with the lambda remote call and returns the results for consumption
        by the class.

        This uses a massively parallel lambda set of functions to compute the hashes on S3 objects.

        :param shortened_block_size:
        :param hash_algorithm:
        :returns: True if success or False otherwise
        """
        # This only works for S3 based objects
        if payload_name is None or not payload_name.lower().startswith('s3://'):
            self.logger.error(f"{self.log_prefix}This method only supports S3 "
                              f"objects, name passed={payload_name}.")
            return None

        bucket, key = split_s3_bucket_key(s3_path=payload_name)
        # algorithm = 'SHA256'
        # we need the blocksize for hashes as a string for lambda to pick up correctly
        lambda_payload = {
            "s3Bucket": bucket,
            "s3Key": key,
            "blocksize": f"{shortened_block_size}",
            "algorithm": hash_algorithm
        }
        s = get_session(region=self.AWS_REGION)
        client = s.client('lambda', config=Config(read_timeout=300))
        # client = boto3.client('lambda')
        response = client.invoke(
            FunctionName=self.lambda_function_name,
            InvocationType='RequestResponse',
            Payload=json.dumps(lambda_payload)
        )
        '''
        JSON returned from this LAMBDA looks like this as an example (actual hash total value
        is not correct for this example):
        {
          "blockSize": "536870912",
          "hashType": "SHA256",
          "totalBlocks": "3",
          "totalHash": "17564c15f23bc4234b4b4c6106bbb5e4bbee829580f9fac408a0afebf071f0e6",
          "errnum": "0",
          "errortext": "",
          "Hash": [
            {
              "block": "1",
              "value": "826c4f634bb5c8d0bf1c2c804cf83612fcf98c9c1984eb45e102a4944dad80c6"
            },
            {
              "block": "2",
              "value": "841eaa5f23b5e4c41fd2ef40c075eb437b71b9147f8681978eebd2b404c9e9e2"
            },
            {
              "block": "3",
              "value": "55b77c4ca359ff48a68036e6725b6990ccc86e3f2084cde224ce49a28d86fc12"
            }
          ]
        }
        '''

        if response['StatusCode'] != 200:
            self.logger.error(f"{self.log_prefix}ERROR - StatusCode from Lambda is {response['StatusCode']}")
            return None

        hashes_json = json.loads(response["Payload"].read())
        if hashes_json:
            self.logger.debug(f"{self.log_prefix}Response from lambda function: {hashes_json}")
            self.logger.debug(f"{self.log_prefix}******")
        else:
            self.logger.error(f"{self.log_prefix}Response from lambda function is None")
        errnum = hashes_json.get('errnum', '-1')  # error from lambda call would result in this not being set
        errtext = hashes_json.get('errortext', '')  # get error message if present
        if int(errnum) != 0:
            self.logger.error(f"{self.log_prefix}Lambda had a non-zero return "
                              f"code for hash computation-returned errnum={errnum} "
                              f"description={errtext}")
            return None
        self.logger.debug(f"{self.log_prefix}Generated {hashes_json['totalBlocks']} "
                          f"block hashes using hash algorithm {hash_algorithm}")
        return hashes_json

    def __hash_block_generation_file_multi_thread_just_json(self, payload_name=None,
                                                            hash_algorithm='SHA256',
                                                            shortened_block_size=256):
        """ Creates the json response for the hashes. The file is read and at each blocksize value the hash
        is computed for that block. The enclosing xml element that the hash-verification should be inserted
        is passed and the the new element is appended inside of the enclosing element.

        :param shortened_block_size: integer of 128, 256, or 512
        :param hash_algorithm: SHA256, SHA384, or SHA512
        :returns: JSON representation of all hashes in blocksizes, None if failure or error
        """
        block_size = self.__block_size_from_human_form(shortened_block_size)
        payload_size = self.__get_payload_size()
        ranges = self.__calculate_chunk_ranges(payload_size, block_size)
        self.logger.debug(f"{self.log_prefix}Total number of ranges={len(ranges)}")
        # dynamic example remove decorator
        # dynamic_block_hash_func = tomorrow.threads(4)(block_hash_of_file)
        # hashes = [dynamic_block_hash_func(filename, range_idx, blocksize) for range_idx in ranges]
        try:
            self.logger.debug(f"{self.log_prefix}Launching local threads for hash computation")
            results = []
            if payload_name.lower().startswith("s3://"):
                bucket, key = split_s3_bucket_key(s3_path=payload_name)
                s3object = get_s3_client(get_session(region=self.AWS_REGION)).Object(bucket, key)
            else:
                s3object = None
            for range_idx in ranges:
                if s3object:
                    result = self.__block_hash_of_s3_object(s3object=s3object, range_idx=range_idx, hash_algorithm=hash_algorithm)
                else:
                    result = self.__block_hash_of_file(filename=payload_name, range_idx=range_idx, hash_algorithm=hash_algorithm)
                results.append(result)
            # hashes = [self.block_hash_of_file(range_idx, self.blocksize) for range_idx in ranges]

            # The following line forces the parallel threads to complete by referencing the value in the returns
            results_sorted = sorted(results, key=lambda h: h.blocknum)
        except Exception as e:
            self.logger.error(f"{self.log_prefix}Multi-thread hash calculation exception: {e}")
            return None

        self.logger.debug(f"{self.log_prefix}Number of hashes returned is {len(results_sorted)}")
        hash_ok = True
        numblocks = 0
        hash_of_hashes = ''
        for part in results_sorted:
            # allow reporting of all block hash errors
            numblocks = part.blocknum   # by updating we will end with the last blocknum which is number of blocks
            if part.value is None:
                self.logger.error(f"{self.log_prefix}Error computing hash for blocknum {part.blocknum}-exiting.")
                hash_ok = False
                continue
            hash_of_hashes = hash_of_hashes + part.value  # append the block hash to the cumulative block hash string

        if not hash_ok:
            return None
        hashes_for_payload = [
            {
                "block": str(hash_element.blocknum),
                "value": hash_element.value
            } for hash_element in results_sorted
        ]
        hashsum = self.__compute_hash(data=hash_of_hashes, hash_algorithm=hash_algorithm)
        # now build our resulting json
        full_hashes = {
            "blockSize": str(block_size),
            "hashType": hash_algorithm,
            "totalBlocks": str(numblocks),
            "totalHash": hashsum,
            "errnum": str('0'),
            "errortext": '',
            "Hash": hashes_for_payload
        }

        self.logger.debug(f"{self.log_prefix}Generated {len(results_sorted)} "
                          f"block hashes using hash algorithm {hash_algorithm}")
        return full_hashes

    @tomorrow.threads(NUM_HASH_THREADS)
    def __block_hash_of_s3_object(self, s3_object=None, range_idx=None, hash_algorithm='SHA256'):
        """
        This version breaks the range read passed in to smaller chunks and computes the hash of the whole range
            this allows more threads to run and reduces memory constraints.
        :param hash_algorithm:
        :param s3_object: s3Object reference
        :param range_idx: array of range to process based of the form:
            (1, (0, 268435455)) for the first block, and (2, (268435456, 536870911)) for the second block
            basically start byte and endbyte to compute hash value for of entire object
        :return: Hashes object with hash computed
        """
        blocknum = range_idx[0]
        startbyte = range_idx[1][0]
        stopbyte = range_idx[1][1]
        totalbytes = stopbyte - startbyte + 1
        self.logger.debug(f"{self.log_prefix}blocknum={blocknum}, "
                          f"filename={s3_object.key}, startbyte={startbyte}, "
                          f"stopbyte={stopbyte}")
        # compute hash of startbyte..endbyte inclusive of endbyte
        # break block size into smaller chunks
        chunk_size = 12 * 1024 * 1024
        ranges = self.__calculate_chunk_ranges(totalbytes, chunk_size=chunk_size)
        # compute hash of startbyte..endbyte inclusive of endbyte
        # filename = self.payload_name
        # bucket, key = split_s3_bucket_key(s3_path=filename)
        hash_value = hashlib.sha256()
        if hash_algorithm == 'SHA384':
            hash_value = hashlib.sha384()
        elif hash_algorithm == 'SHA512':
            hash_value = hashlib.sha512()
        # md5_hash = hashlib.md5()
        range_read = ''
        try:
            for r in ranges:
                startrange = r[1][0] + startbyte
                endrange = r[1][1] + startbyte
                range_read = 'bytes=' + str(startrange) + '-' + str(endrange)
                self.logger.debug(f"  {self.log_prefix}blocknum={blocknum}, sub-range={range_read}")
                bytes_read = s3_object.get(Range=range_read)['Body'].read()
                hash_value.update(bytes_read)
                # md5_hash.update(bytes_read)
            readable_hash = hash_value.hexdigest()
            # readable_md5hash = md5_hash.hexdigest()
            self.logger.debug(f"{self.log_prefix}Hash computed for "
                              f"blocknum={blocknum}, sub-range={range_read} - "
                              f"hashvalue={readable_hash}")
            # return Hashes(blocknum, readable_hash, readable_md5hash, 0, 0)
            return Hashes(blocknum, readable_hash, None, 0, 0)
        except Exception as e:
            self.logger.error(f"{self.log_prefix}Could not find S3 object with "
                              f"name {s3_object.key}, may not exist - "
                              f"exception:{e}")
            return Hashes(blocknum, None, None, 1, 1)

    @tomorrow.threads(NUM_HASH_THREADS)
    def __block_hash_of_file(self, filename=None, range_idx=None, hash_algorithm=None):
        blocknum = range_idx[0]
        startbyte = range_idx[1][0]
        stopbyte = range_idx[1][1]
        totalbytes = stopbyte - startbyte + 1
        # print(blocknum, startbyte)
        # compute hash of startbyte..endbyte inclusive of endbyte
        self.logger.debug(f"{self.log_prefix}blocknum={blocknum}, "
                          f"filename={filename}, "
                          f"startbyte={startbyte}, stopbyte={stopbyte}")
        # break block size into smaller chunks
        chunk_size = 12 * 1024 * 1024
        ranges = self.__calculate_chunk_ranges(totalbytes, chunk_size=chunk_size)
        hash_value = hashlib.sha256()
        if hash_algorithm == 'SHA384':
            hash_value = hashlib.sha384()
        elif hash_algorithm == 'SHA512':
            hash_value = hashlib.sha512()
        # md5_hash = hashlib.md5()
        f = None
        try:
            f = io.open(filename, "rb")
            f.seek(startbyte, 0)
            for r in ranges:
                startrange = r[1][0] + startbyte
                endrange = r[1][1] + startbyte
                bytes_to_read = endrange - startrange + 1
                bytes_read = f.read(bytes_to_read)
                self.logger.debug(f"  {self.log_prefix}blocknum={blocknum}, "
                                  f"startbyte={startrange}, # bytes_read={bytes_to_read}")
                hash_value.update(bytes_read)
                # md5_hash.update(bytes_read)
            readable_hash = hash_value.hexdigest()
            # readable_md5hash = md5_hash.hexdigest()
            f.close()
            # return Hashes(blocknum, readable_hash, readable_md5hash, 0, 0)
            return Hashes(blocknum, readable_hash, None, 0, 0)
        except IOError:
            return Hashes(blocknum, None, None, 1, 1)
        finally:
            if f and not f.closed:
                f.close()

    @staticmethod
    def __verify_privatekey_matches_certificate(private_key=None, public_cert=None) -> bool:
        """
        Verifies whether the provided private key and public certificate match (are paired). Returns True if
        they match, False if they do not.
        DO NOT pass the filename but the actual private_key and public_cert themselves based on OpenSSL load operations.
        :return: True if they match, False if they do not
        """
        if not private_key or not public_cert:
            return False
        ctx = OpenSSL.SSL.Context(OpenSSL.SSL.TLSv1_2_METHOD)
        ctx.use_privatekey(private_key)
        ctx.use_certificate(public_cert)
        try:
            ctx.check_privatekey()
            return True
        except OpenSSL.SSL.Error:
            return False

    def __signit(self, xmlroot=None, private_key_file=None,
                 passphrase=None, public_cert_file=None,
                 kms_alias='', kms_issuer='', kms_subject=''):
        """
        This method is using a different signature methodology based on what the TDF folks want to do
        it needs the pyOpenSSL libraries to accomplish this and use the following methodology:
            Take the StructuredStatement section and normalize it with c14n
            Take the ReferenceValuePayload section and normalize it with c14n
            concat the c14n StructuredStatement and the c14n ReferenceValuePayload section and sign that block
            put the signature in the binding section following the StructuredStatement Element

        This function verifies the private key and public cert are properly paired as well.

        :param public_cert_file:
        :param private_key_file:
        :param passphrase:
        :param xmlroot: lxml Element where Assertion is contained.
        :returns: the updated xmlroot with the signature inserted, None if unable to sign
        """
        # Get the assertion and check to make sure it is good before proceeding
        if xmlroot is None:
            self.logger.error(f"{self.log_prefix}xmlroot is None.")
            return None
        assertion = xmlroot.xpath(XPATH_EXTRACT_ASSERTION, namespaces=NSMAP)
        if len(assertion) != 1:
            self.logger.error(f"{self.log_prefix}{'urn:us:gov:ic:tdf'}Assertion element not found or malformed!")
            return None

        # Get an element tree from StructuredStatement portion of the xml document
        structured_statement = xmlroot.xpath(XPATH_EXTRACT_STRUCTURED_STATEMENT, namespaces=NSMAP)
        if len(structured_statement) != 1:
            self.logger.error(f"{self.log_prefix}{'urn:us:gov:ic:tdf'}StructuredStatement "
                              f"element not found or malformed!")
            return None
        reference_payload = xmlroot.xpath(XPATH_EXTRACT_REFERENCE_VALUE_PAYLOAD, namespaces=NSMAP)
        if len(reference_payload) != 1:
            self.logger.error(f"{self.log_prefix}{'urn:us:gov:ic:tdf'}ReferenceValuePayload "
                              f"element not found or malformed!")
            return None

        # put structured_statement and reference payload into C14N format into Bytes memory block - steps 1 and 2
        output = BytesIO()
        # The following is deprecated: -> get_etree(structured_statement[0]).write_c14n(output)
        # supported method is below
        get_etree(structured_statement[0]).write(output, method="c14n")
        structured_statement_c14n = output.getvalue()
        output.close()

        output = BytesIO()
        get_etree(reference_payload[0]).write(output, method="c14n")
        reference_payload_c14n = output.getvalue()
        output.close()

        # concat them together - step 3
        data_c14n = structured_statement_c14n + reference_payload_c14n

        if private_key_file is not None:
            # sign the data to be signed using public private key file method
            signed_info = self.__sign_using_private_pub_key_files(data_to_sign=data_c14n,
                                                                  private_key_file=private_key_file,
                                                                  passphrase=passphrase,
                                                                  public_cert_file=public_cert_file)
        elif kms_alias != '':
            signed_info = self.__sign_using_kms_key(data_to_sign=data_c14n,
                                                    kms_key_alias=kms_alias,
                                                    kms_issuer=kms_issuer,
                                                    kms_subject=kms_subject)
        else:
            self.logger.error(f"{self.log_prefix}Invalid parameters to determine how to sign manifest.")
            return None

        if signed_info is None:
            return None
        hex_string_signature = signed_info['signature_hex_string']
        issuer = signed_info['issuer']
        subject = signed_info['subject']

        # Now insert the the xml attributes for the signature into the assertion in the root xml - step 4
        binding = ET.SubElement(assertion[0], TAG_TDF_BINDING)

        signer_item = ET.SubElement(binding, TAG_TDF_SIGNER)
        signer_item.set(TAG_TDF_ATTR_SUBJECT, subject)
        signer_item.set(TAG_TDF_ATTR_ISSUER, issuer)

        # Add the signature byte codes to the binding element
        signature_value_item = ET.SubElement(binding, TAG_TDF_SIGNATUREVALUE)
        signature_value_item.set(TAG_TDF_ATTR_SIGNATUREALGORITHM, "SHA256withRSA")
        signature_value_item.set(TAG_TDF_ATTR_NORMALIZATIONMETHOD, "http://www.w3.org/2006/12/xml-c14n11")
        signature_value_item.set(TAG_TDF_ATTR_INCLUDESTATEMENTMETADATA, "false")
        signature_value_item.text = hex_string_signature

        self.logger.debug(f"{self.log_prefix}manifest signed subject={subject} and issuer={issuer}")
        return xmlroot

    def __sign_using_private_pub_key_files(self, data_to_sign='', private_key_file=None,
                                           passphrase=None, public_cert_file=None):
        """
        This method returns a tuple of the signature as hex string, the subject and the issuer
        e.g. {
                "signature_hex_string": "70c564a976603b...",
                'subject': "*.example.com",
                "issuer": "DNAnexus CA" <- this returns the commonName from the issuer
            }
        :param data_to_sign: the c14n string to sign
        :param private_key_file: full path to private key file
        :param passphrase: optional passphrase if the private key is protected
        :param public_cert_file: full path to public cert for private key
        :return: json result noted above or None if error
        """
        # load the the private key using the passphrase if needed
        with io.open(private_key_file, mode="rb") as f:
            if passphrase is not None:
                encoded_pass_phrase = passphrase.encode('utf-8')
            else:
                encoded_pass_phrase = passphrase
            private_key = OpenSSL.crypto.load_privatekey(
                OpenSSL.crypto.FILETYPE_PEM,
                f.read(),
                passphrase=encoded_pass_phrase
            )

        # check the type of the key and ensure it is an RSA key
        if private_key.type() != OpenSSL.crypto.TYPE_RSA:
            self.logger.error(f"{self.log_prefix}Signing key must be of type RSA")
            return None

        try:
            # now sign the needed portion of the document (Assertion portion)
            signature = OpenSSL.crypto.sign(private_key, data_to_sign, "sha256")
            hex_string_signature = binascii.b2a_hex(signature)
        except (binascii.Error, binascii.Incomplete):
            self.logger.error(
                f"{self.log_prefix}Failed to return the hexadecimal representation for the signature value")
            return False, None
        except OpenSSL.crypto.Error as ce:
            self.logger.error(f"{self.log_prefix}Error signing message, exception {ce}")
            return None

        # The signer must have an issuer and one of serial or subject?
        # <tdf:Signer tdf:subject="firstPersonDN" tdf:issuer="C=US" />
        with io.open(public_cert_file, mode="rb") as f:
            public_cert = OpenSSL.crypto.load_certificate(OpenSSL.crypto.FILETYPE_PEM, f.read())
        if self.__verify_privatekey_matches_certificate(private_key=private_key, public_cert=public_cert) is False:
            self.logger.error(f"{self.log_prefix}Private key and public certificate do not match.")
            return None

        issuer = public_cert.get_issuer().commonName
        subject = public_cert.get_subject().commonName

        return {
                    'signature_hex_string': hex_string_signature,
                    'subject': f"{subject}",
                    'issuer': f"{issuer}"
                }

    def __sign_using_kms_key(self, data_to_sign='', kms_key_alias=None, kms_issuer=None, kms_subject=None):
        """
        NOTE: KMS service cannot sign anything larger than 4096 bytes, since the
                data to be signed in a manifest for a large payload can exceed
                this - we compute a hash of all the data to be signed and sign that.
        This method returns a dict of the signature as hex string, the subject
            and the issuer
        e.g. {
                'signature_hex_string': "70c564a976603b...",
                'subject': "*.example.com",
                'issuer': "DNAnexus CA" <- this returns the commonName from the issuer,
                'used_digest': True or False if we had to sign a hash of the data (see note above),
                'digest': hex digest of the SHA512 digest we computed, None if used_digest is False
            }
        :param data_to_sign: the c14n string to sign
        :param kms_key_alias: kms key alias to use (remember key alias' typically start with alias/somename
        :param kms_issuer: the string of the key issuer to use in the manifest
        :param kms_subject: the string of the subject to use in the manifest
        :return: None if an error otherwise a json object with the data as noted above.

        """
        data_being_signed = data_to_sign
        using_digest = False
        hash_value_digest = None
        message_type = 'RAW'
        if len(data_to_sign) > kms_maximum_allowed_data_size:
            self.logger.info(f"Data passed for KMS signing is of size "
                             f"{len(data_to_sign)} which exceeds KMS limit of "
                             f"{kms_maximum_allowed_data_size} will "
                             f"generate a hash digest")
            # generate a sha256 hash of the data and sign that instead
            hash_value_digest = hashlib.sha256(data_to_sign).hexdigest()
            self.logger.debug(f"hash generated = {hash_value_digest}")
            message_type = 'DIGEST'
            self.logger.info(f"SHA256 digest created for data to be signed, to "
                             f"verify ensure assertion data is hashed using "
                             f"sha256 and then verify using the hash.")
            data_being_signed = hash_value_digest
            using_digest = True
        kms_client = get_kms_client(self.AWS_REGION)
        key_metadata = kms_client.describe_key(KeyId=kms_key_alias)[
            "KeyMetadata"
        ]
        if "RSA" not in key_metadata["CustomerMasterKeySpec"]:
            self.logger.error(f"{self.log_prefix}Signing key must be of type RSA")
            return None
        try:
            # now sign the needed portion of the document (Assertion and Reference payload portion)
            signature = kms_client.sign(
                KeyId=kms_key_alias,
                Message=data_being_signed,
                MessageType=message_type,
                SigningAlgorithm="RSASSA_PKCS1_V1_5_SHA_256"
                # SigningAlgorithm="RSASSA_PSS_SHA_256",
            )["Signature"]
            hex_string_signature = binascii.b2a_hex(signature)
        except (binascii.Error, binascii.Incomplete):
            self.logger.error(f"{self.log_prefix}Failed to return the hexadecimal "
                              f"representation for the signature value")
            return None
        except botocore.exceptions.ClientError as error:
            self.logger.error(f"{self.log_prefix}KMS error signing message: {error}")
            return None

        return {
            'signature_hex_string': hex_string_signature,
            'subject': f"{kms_subject}",
            'issuer': f"{kms_issuer}",
            'used_digest': using_digest,
            'digest': f"{hash_value_digest}"
        }

    def __verify_manifest_signature(self, xmlroot=None, public_cert_file=None,
                                    kms_used=False, kms_arn_alias=None):
        """
        This method is using a different signature methodology based on what the TDF folks want to do,
        it needs the pyOpenSSL libraries to accomplish this and uses the following methodology
            Take the StructuredStatement Section and normalize c14n
            Take the reference payload section and normalize it with c14n
            concat the c14n structuredstatement and the c14n payload section and sign that block
            put the signature in the binding section

        :param xmlroot: lxml root Element
        :param public_cert_file: the public certificate used in the validation process
        :param kms_used: set to true if public_cert_file passed is from kms (exported)
        :param kms_arn_alias: provide kms arn or alias to use kms to verify the signature
        :returns: True if the document signature validated correctly and the xml content protected by the signature for
                StructuredStatement element and the ReferenceValuePayload only.
            False otherwise.
        """

        if public_cert_file is None and kms_arn_alias is None:
            self.logger.error(f"{self.log_prefix}public_cert_file or kms arn must be provided.")
            return False, None, None

        if kms_arn_alias is not None:
            kms_used = True

        # Get the assertion element from the xml document
        assertion = xmlroot.xpath(XPATH_EXTRACT_ASSERTION, namespaces=NSMAP)
        if len(assertion) != 1:
            self.logger.error(f"{self.log_prefix}{'urn:us:gov:ic:tdf'}Assertion element not found or malformed!")
            return False, None, None

        binding = xmlroot.xpath(XPATH_EXTRACT_BINDING, namespaces=NSMAP)
        if len(binding) != 1:
            self.logger.error(f"{self.log_prefix}{'urn:us:gov:ic:tdf'}Binding element not found or malformed!")
            return False, None, None

        # Get an element tree from StructuredStatement portion of the xml document
        structured_statement = xmlroot.xpath(XPATH_EXTRACT_STRUCTURED_STATEMENT, namespaces=NSMAP)
        if len(structured_statement) != 1:
            self.logger.error(f"{self.log_prefix}{'urn:us:gov:ic:tdf'}StructuredStatement "
                              f"element not found or malformed!")
            return False, None, None
        reference_payload = xmlroot.xpath(XPATH_EXTRACT_REFERENCE_VALUE_PAYLOAD, namespaces=NSMAP)
        if len(reference_payload) != 1:
            self.logger.error(f"{self.log_prefix}{'urn:us:gov:ic:tdf'}ReferenceValuePayload "
                              f"element not found or malformed!")
            return False, None, None

        # put structured_statement and reference payload into C14N format into Bytes memory block
        output = BytesIO()
        # The following is deprecated: get_etree(structured_statement[0]).write_c14n(output), supported method is below
        get_etree(structured_statement[0]).write(output, method="c14n")
        structured_statement_c14n = output.getvalue()
        output.close()

        output = BytesIO()
        get_etree(reference_payload[0]).write(output, method="c14n")
        reference_payload_c14n = output.getvalue()
        output.close()

        # concat the c14n structuredstatement and the c14n payload section - this is what we verify against
        data_c14n = structured_statement_c14n + reference_payload_c14n
        self.logger.debug(f"{self.log_prefix}datatovalidatesignature:{data_c14n}")

        try:
            # now verify the data against the signature
            # get the signature from the manifest
            signature = binascii.a2b_hex(get_value_in_xml_tag(binding[0], TAG_TDF_SIGNATUREVALUE))
            self.logger.debug(f"{self.log_prefix}signature={signature}")
            self.logger.debug(f"{self.log_prefix}public_cert_file={public_cert_file}")

            if public_cert_file is not None:
                try:
                    with io.open(public_cert_file, mode="rb") as f:
                        cert_text = f.read()
                except IOError:
                    self.logger.error(f"{self.log_prefix}Failed to read certificate "
                                      f"file:{public_cert_file}")
                    return False, None, None
                crt_obj = self.__get_crt_object(cert_data=cert_text)
                if crt_obj is None:
                    return False, None, None

            # try to verify the signature with the public cert
            try:
                original_signed_data = data_c14n
                message_type = 'RAW'
                if kms_used and len(data_c14n) > kms_maximum_allowed_data_size:
                    # KMS can only sign up to 4096 bytes so hash it and use that value
                    self.logger.debug(f"{self.log_prefix}using sha256 hash due "
                                      f"to KMS limit on data size of "
                                      f"{kms_maximum_allowed_data_size} bytes.")
                    original_signed_data = hashlib.sha256(data_c14n).hexdigest()
                    message_type = 'DIGEST'
                # Use OpenSSL unless KMS is to be used for the verify
                if kms_arn_alias is None:
                    OpenSSL.crypto.verify(crt_obj, signature, original_signed_data, "sha256")
                else:
                    kms_client = get_kms_client(region=self.AWS_REGION)
                    response = kms_client.verify(KeyId=kms_arn_alias,
                                                 Message=original_signed_data,
                                                 MessageType=message_type,
                                                 Signature=signature,
                                                 SigningAlgorithm='RSASSA_PKCS1_V1_5_SHA_256')
                    self.logger.debug(f"{self.log_prefix}KMS verify response={response}")
                    if not response['SignatureValid']:
                        return False, None, None
            except Exception as ve:
                self.logger.error(f"{self.log_prefix}{ve}")
                return False, None, None
        except OpenSSL.crypto.Error as ce:
            self.logger.error(f"Exception {ce}")
            self.logger.error(f"{self.log_prefix}Failed on verify() procedure. Digital Signature could not be verified")
            return False, None, None

        except (binascii.Error, binascii.Incomplete):
            self.logger.error(f"{self.log_prefix}Failed to return the hexadecimal "
                              f"representation for the signature value")
            return False, None, None

        self.logger.info(f"{self.log_prefix}Document digital signature validated successfully.")
        signed_structured_statement = parse(structured_statement_c14n)
        signed_reference_payload = parse(reference_payload_c14n)
        return True, signed_structured_statement, signed_reference_payload

    def __get_crt_object(self, cert_data=''):
        # we try two ways to get the cert obj (depending on key type or if kms was used)
        try:
            # this is used for x509 public key files
            crt_obj = OpenSSL.crypto.load_certificate(OpenSSL.crypto.FILETYPE_PEM, cert_data)
            # We could print more data about the certificate.
            self.logger.debug(f"{self.log_prefix}common name on certificate is:\t{crt_obj.get_subject().commonName}")
            self.logger.debug(f"{self.log_prefix}issuer name on certificate is:\t{crt_obj.get_issuer().name}")
            self.logger.debug(f"{self.log_prefix}serial number on certificate is:\t{crt_obj.get_serial_number()}")
            return crt_obj
        except OpenSSL.crypto.Error as ce:
            self.logger.debug(f"{self.log_prefix}failed using openssl.load_certificate...")
            try:
                self.logger.debug(f"{self.log_prefix}trying openssl.load_public_key...")
                crt_obj = OpenSSL.crypto.load_publickey(OpenSSL.crypto.FILETYPE_PEM, cert_data)
                x509 = OpenSSL.crypto.X509()
                x509.set_pubkey(crt_obj)
                self.logger.debug(f"{self.log_prefix}success..")
                return x509
            except OpenSSL.crypto.Error as ce:
                self.logger.error(f"{self.log_prefix}{ce}")
                return None

    def __obtain_template_data_as_xml(self, template_file=None, template_xsd_file=None):
        """
        Determine if template data is xml or json and read the data from the file, if json convert to XML
        and pass the xml etree to verify routine
        :return: lxml root element of the file
        """
        if template_file is None:
            return None
        if template_file.endswith('.json'):
            with open(template_file) as f:
                data = json.load(f)
            xmldata = json2xml.Json2xml(data, wrapper="software-manifest-template",
                                        attr_type=False).to_xml()
            xmlroot = ET.fromstring(xmldata)
            tree = get_etree(xmlroot)
        else:
            tree = get_etree(template_file)

        return self.__validate_template_data_and_return_xml(tree, template_xsd_file=template_xsd_file)

    def __obtain_template_data_as_xml_from_json(self, template_xsd_file=None, json_data=None):
        """
        Return lxml root element from a JSON provided, json converted to XML
        and pass the xml etree to verify routine. json_data should be json formatted
        not a string.
        :return: lxml root element of the passed json data
        """
        if json_data is None:
            return None

        # handle case of user passing in a json data with the template (not a file)
        xmldata = json2xml.Json2xml(json_data, wrapper="software-manifest-template",
                                    attr_type=False).to_xml()
        xmlroot = ET.fromstring(xmldata)
        tree = get_etree(xmlroot)

        return self.__validate_template_data_and_return_xml(tree, template_xsd_file=template_xsd_file)

    def __validate_template_data_and_return_xml(self, tree=None, template_xsd_file=None):
        """ Takes the etree provided in the full path and returns an lxml root element with the data. This
        function does a simple check of the outer element name to ensure it is the correct xml data and then
        performs an XSD verification on the data.

        :returns: lxml root element of the passed etree, None if unable to read or verify the xml data
        """
        root = tree.getroot()
        if root.tag != 'software-manifest-template':
            self.logger.error(f"{self.log_prefix}Not valid software "
                              f"manifest.xml file, root element needs to be "
                              f"software-manifest-template")
            self.logger.error(f"{self.log_prefix}instead root element={root.tag}")
            return None

        self.logger.debug(f"{self.log_prefix}Template file passed preliminary check-continuing...")
        # load the xsd file from the default package location if no file location was provided.
        xsd_schema_doc = get_etree(template_xsd_file)
        xml_schema = ET.XMLSchema(xsd_schema_doc)

        if self.logger.level >= logcheck.DEBUG:
            self.logger.debug(f" {self.log_prefix}calling xml_schema.assertValid() "
                              f"on root of xml tree-None result is good "
                              f"result: {xml_schema.assertValid(root)}")

        valid = xml_schema.validate(root)
        if not valid:
            self.logger.info(f"{self.log_prefix}Template file did not validate "
                             f"against template XSD of {template_xsd_file}")
            return None
        else:
            self.logger.debug(f"{self.log_prefix}Template file passed XSD verification.")

        return root

    def __generate_base_xml(self, payload_name=None, template_xml=None,
                            hash_algorithm='SHA256', shortened_block_size=256):
        """ Generates the base xml for the manifest file. This is the main entry point to generate the manifest xml
        document. This routine does not sign the document as that is an optional operation if desired.
        lambda_function_name: name of lambda function to call for s3 objects (the controller lambda)
            AWS Lambda to do the hash calculations-you must setup the lambda functions and ensure they have
            permissions to access the S3 bucket (looking to do a CF version to do all this but for now it
            is manual)
        multi_thread: True to allow multi_thread execution on local file - if lambda_function_name is None
            then this parameter will determine if single/multithread is used on S3 objects.  If object is local
            then this determines local approach for hash calculations.
        :param hash_algorithm:
        :param shortened_block_size: integer of blocksize as 128, 256, or 512
        :param template_xml: the lxml root that contains the template xml file
        :returns: lxml Element containing the created manifest data, or None if unable to create the manifest.
        """

        software_archive_name = os.path.basename(payload_name)

        # Create TrustedDataObject and add tdf:version to root element
        trusted_data_object = ET.Element(TAG_TDF_TRUSTEDDATAOBJECT, nsmap=self.namespaces_map)
        trusted_data_object.set(TAG_TDF_ATTR_VERSION, "202005")

        # Generate the assertion for the payload
        pay_assertion_item = ET.SubElement(trusted_data_object, TAG_TDF_ASSERTION)
        pay_assertion_item.set(TAG_TDF_ATTR_SCOPE, "PAYL")

        # Generate StructuredStatement and add it to software
        structured_item = ET.SubElement(pay_assertion_item, TAG_TDF_STRUCTURED_STATEMENT)
        software_item = ET.SubElement(structured_item, TAG_TDF_SOFTWARE_SOFTWARE, nsmap=self.cdsm_namespaces_map)
        software_item.set(TAG_TDF_SOFTWARE_SOFTWARE_DESVERSION, "202005")

        # Generate Originator element and add it to software
        originator_item = ET.SubElement(software_item, TAG_TDF_SOFTWARE_ORIGINATOR)
        originator_item.text = get_value_in_xml_tag(template_xml, 'originator')

        # Generate product element and add it to software
        product_item = ET.SubElement(software_item, TAG_TDF_SOFTWARE_PRODUCT)
        product_item.text = get_value_in_xml_tag(template_xml, 'product')

        # Generate version element and add it to software
        product_version_item = ET.SubElement(software_item, TAG_TDF_SOFTWARE_VERSION)
        product_version_item.text = get_value_in_xml_tag(template_xml, 'version')

        # Generate optional cpe element and add it to software if present
        tag_value = get_value_in_xml_tag(template_xml, 'cpe')
        if tag_value is not None:
            product_cpe_item = ET.SubElement(software_item, TAG_TDF_SOFTWARE_CPE)
            product_cpe_item.text = tag_value

        # Generate arch element and add it to software
        product_arch_item = ET.SubElement(software_item, TAG_TDF_SOFTWARE_ARCH)
        product_arch_item.text = get_value_in_xml_tag(template_xml, 'arch')

        # add optional tags for routing, workflowid, and userkey if present
        tag_value = get_value_in_xml_tag(template_xml, 'routing')
        if tag_value is not None:
            routing_item = ET.SubElement(software_item, TAG_TDF_SOFTWARE_ROUTING)
            routing_item.text = tag_value

        tag_value = get_value_in_xml_tag(template_xml, 'workflowid')
        if tag_value is not None:
            workflowid_item = ET.SubElement(software_item, TAG_TDF_SOFTWARE_WORKFLOWID)
            workflowid_item.text = tag_value

        tag_value = get_value_in_xml_tag(template_xml, 'userkey')
        if tag_value is not None:
            userkey_item = ET.SubElement(software_item, TAG_TDF_SOFTWARE_USERKEY)
            userkey_item.text = tag_value

        # dispatch to the proper handlers to generate the manifest hashes based on user choice of multithread and S3
        ok = self.__generate_block_hashes_for_payload_insert_into_xml(payload_name=payload_name,
                                                                      software_item=software_item,
                                                                      hash_algorithm=hash_algorithm,
                                                                      shortened_block_size=shortened_block_size)
        if not ok:
            return None

        # provide vendor public checksums from the template file if present (only on or both are present)
        product_vendor_checksum_item = None
        tag_value = get_value_in_xml_tag(template_xml, 'vendor_checksum_md5')
        if tag_value is not None:
            product_vendor_checksum_item = ET.SubElement(software_item, TAG_TDF_SOFTWARE_VENDORCHECKSUM)
            product_vendor_md5checksum_item = ET.SubElement(product_vendor_checksum_item, TAG_TDF_SOFTWARE_MD5)
            product_vendor_md5checksum_item.text = tag_value

        tag_value = get_value_in_xml_tag(template_xml, 'vendor_checksum_sha256')
        if tag_value is not None:
            if product_vendor_checksum_item is None:
                product_vendor_checksum_item = ET.SubElement(software_item, TAG_TDF_SOFTWARE_VENDORCHECKSUM)
            product_vendor_sha256checksum_item = ET.SubElement(product_vendor_checksum_item, TAG_TDF_SOFTWARE_SHA256)
            product_vendor_sha256checksum_item.text = tag_value

        # we used to compute the whole checksum of the payload - now it must be in the template
        # product_vendor_checksum_item = ET.SubElement(software_item, TAG_TDF_SOFTWARE_VENDORCHECKSUM)
        # product_vendor_md5checksum_item = ET.SubElement(product_vendor_checksum_item, TAG_TDF_SOFTWARE_MD5)
        # product_vendor_md5checksum_item.text = md5_hash
        # product_vendor_sha1checksum_item = ET.SubElement(product_vendor_checksum_item, TAG_TDF_SOFTWARE_SHA256)
        # product_vendor_sha1checksum_item.text = sha256_hash

        # Virus scan information - use class variables in case caller wants to update them
        # and not have to mess with the template that is auto-generated.
        product_virus_item_list = ET.SubElement(software_item, TAG_TDF_SOFTWARE_VIRUSSCANLIST)

        # support multiple or a single virus item definition(s) in the template file
        # First look to see if the virus_scan is a single entry
        template_virus_items = template_xml.findall('virus_scan')
        # looks like one is not present so we ensure we have a list
        if len(template_virus_items) == 0:
            template_virus_items = template_xml.findall('virus_scans/virus_scan')
            if len(template_virus_items) == 0:
                # uh oh they did not include any which is not allowed
                self.logger.error("Some form of virus scan must be present in template")
                return None
        for virus_scan_item in template_virus_items:
            product_virus_item = ET.SubElement(product_virus_item_list, TAG_TDF_SOFTWARE_VIRUSSCAN)
            product_virus_vendor_item = ET.SubElement(product_virus_item, TAG_TDF_SOFTWARE_VIRUSVENDOR)
            # product_virus_vendor_item.text = get_value_in_xml_tag(template_xml, 'virus_scan/vendor')
            product_virus_vendor_item.text = get_value_in_xml_tag(virus_scan_item, 'vendor')

            product_virus_version_item = ET.SubElement(product_virus_item, TAG_TDF_SOFTWARE_VIRUSVENDORSCANVERSION)
            product_virus_version_item.text = get_value_in_xml_tag(virus_scan_item, 'version')
            # product_virus_version_item.text = get_value_in_xml_tag(template_xml, 'virus_scan/version')

            product_virus_signaturedate_item = ET.SubElement(product_virus_item, TAG_TDF_SOFTWARE_VIRUSSIGNATUREDATE)
            product_virus_signaturedate_item.text = get_value_in_xml_tag(virus_scan_item, 'signature_date')
            # product_virus_signaturedate_item.text = get_value_in_xml_tag(template_xml, 'virus_scan/signature_date')

            product_virus_result_item = ET.SubElement(product_virus_item, TAG_TDF_SOFTWARE_VIRUSRESULT)
            product_virus_result_item.text = get_value_in_xml_tag(virus_scan_item, 'result')
            # product_virus_result_item.text = get_value_in_xml_tag(template_xml, 'virus_scan/result')

        # Reference Value Payload portion
        payload_reference_value_item = ET.SubElement(trusted_data_object, TAG_TDF_REFERENCEVALUEPAYLOAD)
        payload_reference_value_item.set(TAG_TDF_ATTR_URI, software_archive_name)
        payload_reference_value_item.set(TAG_TDF_ATTR_MEDIATYPE, get_value_in_xml_tag(template_xml, 'mediaType'))

        return trusted_data_object

    def __read_manifest_file_and_return_xml(self, manifest_file=None, xml_document: str = None):
        """ Read the template file provided in the full path or document data and
        returns an lxml root element with the data. This function does a simple
        check of the outer element name to ensure it is the correct xml file.
        Future cases could include an XSD check.
        :param manifest_file: Full path and name of template xml file or s3 path,
            s3:// prefix will cause it to parse bucket and key then read file from S3
        :returns: lxml root element of the template file, None if unable to read or verify the xml file
        """

        if xml_document is not None:
            if isinstance(xml_document, str):
                xmlroot = ET.fromstring(xml_document.encode())
            else:
                xmlroot = xml_document.getroot()
            return xmlroot

        # process as a file to get XML
        if manifest_file.lower().startswith('s3://'):
            bucket, key = split_s3_bucket_key(s3_path=manifest_file)
            s3 = get_s3_client(get_session(region=self.AWS_REGION))
            manifest_xml = read_data_s3(s3=s3, bucket=bucket, key=key)
            if not manifest_xml:
                return None
            root = ET.fromstring(manifest_xml)
        else:
            if not os.path.exists(manifest_file):
                raise IOError(f"{self.log_prefix}Unable to find manifest file at {manifest_file}")
            tree = get_etree(manifest_file)
            root = tree.getroot()
        if root.tag != TAG_TDF_TRUSTEDDATAOBJECT:
            self.logger.error(f"{self.log_prefix}Not valid software manifest.xml "
                              f"file, root element needs to be "
                              f"tdf:TrustedDataObject instead root element={root.tag}")
            return None
        self.logger.debug(f"{self.log_prefix}Basic check of manifest file succeeded-continuing...")
        # not doing any other checking at this point - can be extended to verify with an XSD...
        return root

    def __verify_xml_against_xsd(self, xmldata=None, xsd_file=None) -> bool:
        """ verify the passed xml root data against the specified xsd file on the file system.

        :param xmldata: is root of XML
        :param xsd_file: Full path to XSD to use to verify the xml file
        :returns: True if validated, False if not, None if unable to read or verify the xml file

        NOTE: if xml data is in a file you can use:
            tree = get_etree(self.manifestfile)
            root = tree.getroot()
            and then pass root to this method
        """
        if not os.path.exists(xsd_file):
            raise IOError(f"{self.log_prefix}Requested XSD file at {xsd_file} cannot be found.")
        # load the xsd file from the default package location if no file location was provided.
        xsd_schema_doc = get_etree(xsd_file)
        xsd_xml_schema = ET.XMLSchema(xsd_schema_doc)

        # for very detailed messaging about why a verify failed use:
        if self.logger.level >= logcheck.DEBUG:
            xsd_xml_schema.assertValid(xmldata)

        valid = xsd_xml_schema.validate(xmldata)
        if not valid:
            self.logger.error(f"{self.log_prefix}XML data did not validate against XSD of {xsd_file}")
            return False
        else:
            self.logger.debug(f"{self.log_prefix}XML data passed XSD verification.")
            return True

    def __verify_hashes_with_payload(self, payload_name=None, manifest_xml=None) -> bool:
        # This method re-computes the hashes from the payload and compares them to the manifest provided
        # NOTE: for larger payloads this can be a length operation depending on where the data sits and the option
        # to use multi-thread versus lambda.

        # retrieve hash_algorithm and blocksize (we will need to convert blocksize to shortened version
        hash_verification_block_values = manifest_xml.xpath(XPATH_EXTRACT_HASH_VERIFICATION_ROOT, namespaces=NSMAP)
        if len(hash_verification_block_values) != 1:
            self.logger.error(f"{self.log_prefix}{'urn:us:gov:ic:cdsmanifest'}"
                              f"HashVerification element not found or malformed!")
            return False
        hash_verification_block_values = hash_verification_block_values[0]
        blocksize = int(get_attr_value_in_xml_tag(hash_verification_block_values, TAG_TDF_SOFTWARE_ATTR_BLOCKSIZE))
        hash_algorithm = get_attr_value_in_xml_tag(hash_verification_block_values, TAG_TDF_SOFTWARE_ATTR_HASHTYPE)
        num_blocks = int(get_attr_value_in_xml_tag(hash_verification_block_values, TAG_TDF_SOFTWARE_ATTR_TOTALBLOCKS))
        total_hash = get_attr_value_in_xml_tag(hash_verification_block_values, TAG_TDF_SOFTWARE_ATTR_TOTALHASH)
        if hash_algorithm not in ['SHA256', 'SHA384', 'SHA512']:
            self.logger.error(f"{self.log_prefix}Hash algorithm unexpected-exiting.")
            return False
        shortened_block_size = self.__human_form_from_block_size(block_size=blocksize)

        hashes_json = self.__generate_block_hashes_for_payload_json(payload_name=payload_name,
                                                                    hash_algorithm=hash_algorithm,
                                                                    shortened_block_size=shortened_block_size)
        if hashes_json is None:
            self.logger.error(f"{self.log_prefix}Unable to recompute hash values for requested payload.")
            return False
        num_errors = int(hashes_json.get('errnum'))
        if num_errors != 0:
            self.logger.error(f"{self.log_prefix}Errnum on computation of hashes is not zero value={num_errors}")
            return False
        # now compare the hashes computed against those in the manifest
        if num_blocks != int(hashes_json['totalBlocks']):
            self.logger.error(f"{self.log_prefix}Total blocks in original "
                              f"manifest={num_blocks}, newly computed "
                              f"total blocks={int(hashes_json['totalBlocks'])}")
            return False
        if total_hash != hashes_json['totalHash']:
            self.logger.error("Total Hash mismatch")
            # Ensure the following line up to make visual comparison easier
            self.logger.error(f"{self.log_prefix}Manifest total hash={total_hash}")
            self.logger.error(f"{self.log_prefix}Newly computed hash={hashes_json['totalHash']}")
            return False
        # Compare each block hash value one by one
        newly_computed_hashes = hashes_json['Hash']
        mismatch = False
        for hash_element in newly_computed_hashes:
            block_num = int(hash_element['block'])
            newly_computed_hash_value = hash_element['value']
            # read the value from the manifest
            xml_block_element = manifest_xml.xpath(XPATH_EXTRACT_HASHBLOCK_ROOT.format(block_num), namespaces=NSMAP)[0]
            block_hash = get_attr_value_in_xml_tag(xml_block_element, TAG_TDF_SOFTWARE_ATTR_VALUE)
            if newly_computed_hash_value != block_hash:
                self.logger.error(f"{self.log_prefix}hash computed for blocknum="
                                  f"{block_num} does not match original hash for same block.")
                self.logger.error(f"  {self.log_prefix}manifest hash={block_hash}")
                self.logger.error(f"  {self.log_prefix}computed hash={newly_computed_hash_value}")
                mismatch = True
        if mismatch:
            return False
        # all matched!
        return True

    def __verify_hash_of_hashes(self, manifest_xml=None) -> bool:
        """
        This method takes a manifest xml document and recomputes the totalHash using all the block hashes, then
        compares the newly computed hash value against the one in the manifest.
        :param manifest_xml: the manifest xml document root
        :return: True if the recomputed hash of hashes matches the value in the manifest, False if it does not match
        """
        if manifest_xml is None:
            self.logger.error(f"{self.log_prefix}Error reading the manifest xml data - none passed.")
            return False
        hash_verification_block_values = manifest_xml.xpath(XPATH_EXTRACT_HASH_VERIFICATION_ROOT, namespaces=NSMAP)

        if len(hash_verification_block_values) != 1:
            self.logger.error(f"{self.log_prefix}{'urn:us:gov:ic:cdsmanifest'}"
                              f"HashVerification element not found or malformed!")
            return False
        hash_verification_block_values = hash_verification_block_values[0]
        # blocksize = int(get_attr_value_in_xml_tag(hash_verification_block_values, TAG_TDF_SOFTWARE_ATTR_BLOCKSIZE))
        hash_algorithm = get_attr_value_in_xml_tag(hash_verification_block_values, TAG_TDF_SOFTWARE_ATTR_HASHTYPE)
        num_blocks = int(get_attr_value_in_xml_tag(hash_verification_block_values, TAG_TDF_SOFTWARE_ATTR_TOTALBLOCKS))
        total_hash = get_attr_value_in_xml_tag(hash_verification_block_values, TAG_TDF_SOFTWARE_ATTR_TOTALHASH)
        if hash_algorithm not in ['SHA256', 'SHA384', 'SHA512']:
            self.logger.error(f"{self.log_prefix}Hash algorithm unexpected-exiting.")
            return False
        total_hash_recompute_str = ''
        for blocknum in range(1, num_blocks + 1):
            xml_block_element = manifest_xml.xpath(XPATH_EXTRACT_HASHBLOCK_ROOT.format(blocknum), namespaces=NSMAP)[0]
            block_hash = get_attr_value_in_xml_tag(xml_block_element, TAG_TDF_SOFTWARE_ATTR_VALUE)
            total_hash_recompute_str = total_hash_recompute_str + block_hash
        # Now compute the total hash to compare to the one in the manifest
        computed_total_hash = self.__compute_hash(data=total_hash_recompute_str, hash_algorithm=hash_algorithm)
        if computed_total_hash == total_hash:
            return True
        self.logger.error(f"{self.log_prefix}Total Hash mismatch")
        # Ensure the following line up to make visual comparison easier
        self.logger.error(f"{self.log_prefix}manifest total hash={total_hash}")
        self.logger.error(f"{self.log_prefix}newly computed hash={computed_total_hash}")
        return False

    def __get_payload_size(self, payload_name=None) -> int:
        if payload_name is None:
            return -1
        else:
            if payload_name.lower().startswith('s3://'):
                temp = split_s3_bucket_key(s3_path=payload_name)
                if temp:
                    s3resource = get_s3_client(get_session(region=self.AWS_REGION))
                    return get_size_s3_object(s3=s3resource, bucket=temp[0], object_name=temp[1], logger=self.logger)
                else:
                    return -1
            stat_result = os.stat(payload_name)
            return stat_result.st_size

    @staticmethod
    def __block_size_from_human_form(human_form=None) -> int:
        try:
            # numbers below represent mapping for human ease to actual bytes e.g. 128*1024*1024,
            # 256*1024*1024, 512*1024*1024
            actual_bytes = {
                "128": 134217728,
                "256": 268435456,
                "512": 536870912
            }[str(human_form)]
            return actual_bytes
        except KeyError:
            raise KeyError(f"hashing_block size must be one of: 128, 256, or "
                           f"512 in MB. value provided: {str(human_form)}")

    @staticmethod
    def __human_form_from_block_size(block_size=None) -> str:
        try:
            # numbers below represent mapping for human ease to actual bytes e.g. 128*1024*1024,
            # 256*1024*1024, 512*1024*1024
            human_form = {
                "134217728": 128,
                "268435456": 256,
                "536870912": 512
            }[str(block_size)]
            return human_form
        except KeyError:
            raise KeyError(f"hashing_block size must be one of: 134217728, 268435456, or 536870912 in Bytes. value "
                           "provided: {str(block_size)}")

    def __compute_hash(self, data=None, hash_algorithm='SHA256') -> Optional[str]:
        """
        Compute a readable hash for the given data using the algorithm requested. This code was setup to handle
        strings better by catching an error and then converting to bytes and trying again.
        :param data: The data as a string or encoded utf-8
        :param hash_algorithm: the value of SHA256, SHA384, or SHA512
        :return: None if hash could not be computed or returns hexdigest of computed hash for provided data
        """
        if data is None:
            return None
        if hash_algorithm == 'SHA256':
            hasher = hashlib.sha256()
        elif hash_algorithm == 'SHA384':
            hasher = hashlib.sha384()
        elif hash_algorithm == 'SHA512':
            hasher = hashlib.sha512()
        else:
            return None
        try:
            hasher.update(data)
            readable_hash = hasher.hexdigest()
            return readable_hash
        except TypeError as te:
            self.logger.warning(f"{self.log_prefix}Exception in hash_compute "
                                f"{te} - will try encoding data.")
            # try converting the data to utf-8 and trying again
            try:
                hasher.update(str(data).encode('utf-8'))
                readable_hash = hasher.hexdigest()
                return readable_hash
            except Exception:
                return None
        except Exception:
            return None

    def __retrieve_swams_manifest(self, mapping_id=None,
                                  transfer_manifest_id=None) -> Optional[str]:
        """
                This method is used to retrieve a SWAMS generated by the Diode SWAMS service.
                :param mapping_id: mapping id used by swams to generate the mapping (this must be an SA mapping in diode)
                :param transfer_manifest_id: the manifest tansfer id returned by swams from the generate call
                :return: signed manifest as a str or None if there was an error
                """
        if mapping_id is None or transfer_manifest_id is None:
            self.logger.error("must pass a mapping id and transfer_manifest id to use this method.")
            return None
        diode = botocore.session.get_session().create_client('diode', region_name=self.AWS_REGION)
        try:
            response = diode.get_transfer_manifest(mappingId=mapping_id, transferManifestId=transfer_manifest_id)
            manifest_data = response['manifestBody']
            manifest_data = manifest_data.encode()
            self.logger.info(f"Manifest retrieved with Manifest Id "
                             f"{transfer_manifest_id}.")
            return manifest_data
        except (KeyError, IOError, ValueError, Exception) as ex:
            self.logger.error(f"Exception in __retrieve_swams_manifest {ex}")
            return None


if __name__ == "__main__":
    print("instantiate the class-versus trying to run directly at command line.")
    sys.exit(1)

'''
sample run with files here:
python3 signer-cli/generate_tdf_manifest.py -i signer-cli/samples/template_sample.xml \
  -v signer-cli/Reference_XSDs/template.xsd -o mymanifest.xml \
  -a '/Users/test/Desktop/mypayload.tar' -k samples/examplekey.key -c samples/examplecert.pem

The following example assumes the existence of a properties file with the following fields-note these should be set
to your proper values.
# Properties file for Diode test harness
[Signer]
LAMBDAHASHFUNCTION=lambda-function
AWS_REGION=us-east-1
PAYLOADBUCKET=mypayload-bucket

Sample that uses the lambda function against an object in S3:
python3 signer-cli/generate_tdf_manifest.py -i signer-cli/samples/template_sample.xml \
-v signer-cli/Reference_XSDs/template.xsd -o payload_manifest.xml -a 's3://mybucketname/mypayload.tar' \
-k signer-cli/samples/examplekey.key -c signer-cli/samples/examplecert.pem -mt -f generator_signer.properties

Sample that uses the lambda function against an object in S3 with a blocksize of 512MB instead of 256MB:
python3 signer-cli/generate_tdf_manifest.py -i signer-cli/samples/template_sample.xml \
-v signer-cli/Reference_XSDs/template.xsd -o payload_manifest.xml -a 's3://mybucketname/mypayload.tar' \
-k signer-cli/samples/examplekey.key -c signer-cli/samples/examplecert.pem -mt -f generator_signer.properties -b 512

Sample that uses the multi-thread mode on a local file:
python3 signer-cli/generate_tdf_manifest.py -i signer-cli/samples/template_sample.xml \
  -v signer-cli/Reference_XSDs/template.xsd -o mymanifest.xml \
  -a '/Users/test/Desktop/mypayload.tar' -k samples/examplekey.key -c samples/examplecert.pem -mt

Using the class in your own code:

import generate_tdf_manifest_class as makemanifest
make_manifest = makemanifest.AwsCdsManifest(template_file="template_sunjdk.xml", 
    template_xsd="Reference_XSDs/template.xsd", 
    payload_name="/Users/tonydahb/Desktop/openjdk-11.0.1_linux-x64_bin.tar.gz", blocksize="256", 
    private_key_file="samples/examplekey.key", public_cert_file="samples/examplecert.pem")
If you want to update virus scan information or date it can be done in this step
by updating the following class variables - otherwise they will contain the values from the
template:
   virus_vendor, virus_version , virus_signaturedate, virus_result

The following line will cause the manifest to be generated - there is an optional 
argument on the generate_and_sign_manifest()
  call of multi_thread which if set to true will cause threads to be used in the computation of the hashes on a
  local file-this is highly recommended on files of 3-4 GB or larger.
return_code, manifest = make_manifest.generate_and_sign_manifest(multi_thread=False|True, 
                                                            lambda_function_name=LAMBDA_FUNCTION_NAME, 
                                                            aws_region='us-east-1')
All arguments are optional. Teh default is false for multi_thread, and None for lambda_function_name.


when using the command line version passing a -d will enable debugging
passing a -mt argument will enable multithreaded hash computation for local files (up to 10 threads will run
in parallel.
'''

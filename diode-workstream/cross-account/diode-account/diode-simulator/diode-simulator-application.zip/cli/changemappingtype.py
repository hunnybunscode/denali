"""
The Diode Test Harness is provided to you as “Beta Materials” and your use of the Beta Materials
is governed by your agreement with AWS.  In particular, please note that your use of the Beta
Materials is subject to the Universal and Beta Service Participation sections of the AWS Service
Terms (http://aws.amazon.com/service-terms/) and is confidential, as is all associated documentation.
You may not discuss the features or functionality of the Beta Materials with any party
(individual or business) that is not authorized by Amazon Web Services.  You may not transfer the
Beta Materials outside of your AWS account nor may you otherwise distribute the Beta Materials to
any party.
"""
import os
import sys
import configparser
from random import seed
import time
path = os.path.abspath(os.path.join(os.path.dirname(__file__), '../common_utils'))
if path not in sys.path:
    sys.path.insert(1, path)
import general_utils as generalutils

DYNAMO_MAPPING_TABLE = 'diode-simulator-mappings'
AWS_ACCOUNT_NUM = '123456789012'
MAXFILESIZEMB = 1024  # 1024 is 1GB, 2048 is 2GB
MAXINFLIGHTMBBYTES = 2048
NUM_MOVER_THREADS = 1
TPS = 0.25  # Default Diode TPS rating
AWS_REGION = 'us-east-1'

# All of the following values are only settable by modifying this code and should be done only if absolutely necessary
PROPERTY_FILE = './diode_simulator.properties'  # file name to use if none passed at startup
mapping_types = ['standard', 'software']

seed(time.time())


def setup_properties_from_file(propertyfile):
    global DYNAMO_MAPPING_TABLE, AWS_REGION, MAXFILESIZEMB, TPS, MAXINFLIGHTMBBYTES

    config = configparser.RawConfigParser()
    try:
        config.read(propertyfile)
        DYNAMO_MAPPING_TABLE = config.get('diodeSimulator', 'DYNAMO_MAPPING_TABLE')
        AWS_REGION = generalutils.environment_value_as_type(config.get('diodeSimulator', 'AWS_REGION'), type=str,
                                                            default=AWS_REGION)
        MAXFILESIZEMB = generalutils.environment_value_as_type(config.get('diodeSimulator', 'MAXFILESIZEMB'),
                                                               type=int, default=100)
        TPS = generalutils.environment_value_as_type(config.get('diodeSimulator', 'TPS'), type=float, default=0.25)
        MAXINFLIGHTMBBYTES = generalutils.environment_value_as_type(config.get('diodeSimulator', 'MAXINFLIGHTMBBYTES'),
                                                                    type=int, default=MAXINFLIGHTMBBYTES)
    except configparser.Error as e:
        print("error reading property file %s" % (str(e)))
    return


if __name__ == "__main__":
    from sys import argv

    # see if an agument of a property file has been provided
    if len(argv) == 4:
        propertyFile = argv[1]
        mapping_id = argv[2]
        convert_to = argv[3]
    elif len(argv) == 3:
        propertyFile = PROPERTY_FILE
        mapping_id = argv[1]
        convert_to = argv[2]
    else:
        print("please pass property file to use, mapping id to update and [software|standard]")
        sys.exit(2)

    if convert_to not in mapping_types:
        print("mapping type to convert to must be either standard or software")
        sys.exit(1)

    setup_properties_from_file(propertyFile)
    mapping_id = mapping_id.lower()  # make sure it is all lower case

    dynamo = generalutils.get_dynamodb_client(generalutils.get_session(region=AWS_REGION))
    mappingEntry = generalutils.get_mapping_record_in_table(dynamo, DYNAMO_MAPPING_TABLE, mapping_id)
    if mappingEntry.get('mappingStatus', None) is None:
        print(f"mapping id {mapping_id} does not exist")
        sys.exit(1)

    if mappingEntry['mappingType'] == convert_to:
        print(f"mapping id {mapping_id} is already a {convert_to} mapping.")
        sys.exit(0)

    mappingEntry['mappingType'] = convert_to
    generalutils.update_mapping_record_in_table(dynamo, DYNAMO_MAPPING_TABLE, mappingEntry)
    mappingEntry = generalutils.get_mapping_record_in_table(dynamo, DYNAMO_MAPPING_TABLE, mapping_id)

    print(f"mapping id {mapping_id} updated to {convert_to} mapping.\nmappingEntry={mappingEntry}")

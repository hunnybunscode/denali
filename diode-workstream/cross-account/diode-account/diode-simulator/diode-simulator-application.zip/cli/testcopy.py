import boto3
import os
import sys
from sys import argv
path = os.path.abspath(os.path.join(os.path.dirname(__file__), '../common_utils'))
if path not in sys.path:
    sys.path.insert(1, path)
import general_utils as generalutils

AWS_REGION = 'us-east-1'

if __name__ == "__main__":
    # see if an argument of a property file has been provided
    if len(argv) != 5 and len(argv) != 6:
        print(f"Please provide 4 or 5 arguments: rolearn sourcebucketname destbucketname objectname optionalregionname")
        print("python3 testcopy.py 'arn:aws:iam::123456789012:role/simulatorinotheraccount' "
              "'diodesimulator-lowsidebucket-abcjomb6oko4' 'bucketinotheraccount' 'sample.txt'")
        exit(1)

    role_arn = argv[1]
    source_bucket = argv[2]
    dest_bucket = argv[3]
    src_object_name = argv[4]
    if len(argv) == 6:
        AWS_REGION = argv[5]

    s3client = generalutils.get_assumed_s3_role(generalutils.get_session(region=AWS_REGION), role_arn=role_arn)
    s3local = generalutils.get_s3_client(generalutils.get_session(region=AWS_REGION))
    copy_source = {'Bucket': source_bucket, 'Key': src_object_name}
    destination_name = f"fromtestcopy/{src_object_name}"

    move_ok = generalutils.copy_s3_object(s3client, source_bucket, dest_bucket, src_object_name, '1234', logger=None)
    print(move_ok)

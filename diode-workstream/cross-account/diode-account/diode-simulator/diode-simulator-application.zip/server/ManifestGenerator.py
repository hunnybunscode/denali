import os
import sys
import threading
import time
import json
import uuid
import boto3
import decimal
from botocore.exceptions import ClientError
path = os.path.abspath(os.path.join(os.path.dirname(__file__), '../common_utils'))
if path not in sys.path:
    sys.path.insert(1, path)
path = os.path.abspath(os.path.join(os.path.dirname(__file__), '../CDSManifest'))
if path not in sys.path:
    sys.path.insert(1, path)
del path
import general_utils as generalutils
import AwsCdsManifest as DiodeCDSManifest

# cleanup old manifests every 6 days
delay_in_seconds_before_manifest_cleanup = 6 * 60 * 60 * 24

# default SA max allowed bytes in flight (60GB)
max_in_flight_bytes_allowed_default = 60 * 1024 * 1024 * 1024

# indices for dynamodb queries
external_status_index = 'status-index'
internal_status_index = 'internal-status-index'
maximum_time_in_seconds_to_let_manifest_sit_in_processing = 60 * 10
when_to_delete_manifest_in_seconds = 60 * 60 * 24 * 14  # delete in 14 days

# path to where the template.xsd is stored on the simulator filesystem
template_xsd_name_and_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '../XSDs/tdf_xsds/template.xsd'))
__VERSION__ = 1.0

# This class is responsible for generating manifests using the distributed lambda
# functions. You need to ensure you do not allocate more instances of this class
# than you can run simultaneous lambda functions. Currently, only 1 thread is
# configured in the simulator to generate manifests.
# this class needs access to dynamodb where manifest requests are written
# it needs to know the name of the s3 bucket where it will write manifests
# it needs access to the limits of maxfile size allowed by mapping id


class ManifestGenerator:

    def __init__(self, aws_region='us-east-1', logger=None,
                 manifest_bucket=None,
                 cloudwatch_events_source='diode.simulator',
                 dynamo_swams_table=None, lambda_controller_arn=None):
        self.aws_region = aws_region
        self.logger = logger
        self.manifest_bucket = manifest_bucket
        self.cloudwatch_events_source = cloudwatch_events_source
        self.dynamo_swams_table = dynamo_swams_table
        self.lambda_controller_arn = lambda_controller_arn

        # setup states for internalStatus
        self.external_status_state = ['CREATE_IN_PROGRESS', 'CREATE_COMPLETE', 'CREATE_FAILURE']
        self.internal_status_state = ['NOT_STARTED', 'STARTED', 'FINISHED']
        self.logger.info(f"ManifestGenerator {__VERSION__}-class instantiated")

        self.threads_keep_running = True
        self.swams_process_thread = None
        self.swams_cleanup_thread = None

        # setup and start threads
        self.__setup_start_threads()

    """
    The following methods are the only publicly exposed methods for this class
    """
    def shutdown(self):
        self.threads_keep_running = False
        self.swams_cleanup_thread.join()
        self.swams_process_thread.join()
        return

    def create_transfer_manifest(self, mapping_dictionary=None, mapping_id=None,
                                 manifest_template=None,
                                 payload_s3_bucket=None, payload_s3_key=None,
                                 payload_size_bytes=0,
                                 manifest_format='TDF', hash_type='sha256'):
        """
        @return None if too much data in flight for manifest creations, otherwise
        return transferManifestId
        """
        if mapping_dictionary is not None:
            max_in_flight_bytes_allowed = mapping_dictionary[mapping_id]['softwareArtifactsMaxFilesInFlight'] * (
                        mapping_dictionary[mapping_id]['softwareArtifactsMaxFileSizeMB'] * 1024 * 1024)
        else:
            max_in_flight_bytes_allowed = max_in_flight_bytes_allowed_default

        # get amount of bytes queued manifest generation for this mapping id
        amount_queued = self.__get_size_of_queued_manifest_requests_in_bytes(mapping_id=mapping_id)
        msg = f"mapping_id {mapping_id} amount_queued+payload_size_bytes={amount_queued+payload_size_bytes} " \
              f"max_in_flight_bytes_allowed={max_in_flight_bytes_allowed} "
        self.logger.debug(f"ManifestGenerator-create_transfer_manifest {msg}")
        self.logger.debug(f"ManifestGenerator-create_transfer_manifest "
                          f"payload_size_bytes={payload_size_bytes} ")
        self.logger.debug(f"ManifestGenerator-create_transfer_manifest "
                          f"amount_queued={amount_queued}")

        if amount_queued + payload_size_bytes > max_in_flight_bytes_allowed:
            self.logger.info(f"ManifestGenerator-create_transfer_manifest "
                             f" request for manifest creation of "
                             f"s3://{payload_s3_bucket}/{payload_s3_key} size {payload_size_bytes}"
                             f" exceeds allowed active bytes in queue to process.")
            return None

        transferManifestId = str(uuid.uuid4())
        clean_date = generalutils.get_current_time_in_diode_format() + delay_in_seconds_before_manifest_cleanup
        self.logger.info(f"ManifestGenerator transferManifestId generated {transferManifestId}")
        # put the record in dynamodb transfers table
        dynamo = generalutils.get_dynamodb_client(generalutils.get_session(region=self.aws_region))
        fields = {'mappingId': mapping_id,
                  'status': self.external_status_state[0],
                  'cleanupDate': clean_date,
                  'statusReason': 'The manifest is currently being created.',
                  'payloadS3Bucket': payload_s3_bucket,
                  'payloadS3Key': payload_s3_key,
                  'payloadSizeBytes': payload_size_bytes,
                  'manifestFormat': manifest_format,
                  'templateData': manifest_template,
                  'hashType': hash_type,
                  'internalStatus': self.internal_status_state[0],
                  'internalStatusUpdated': decimal.Decimal(float("%0.3f" % 0.0)),
                  'expiryTime': decimal.Decimal(float("%0.3f" % 0.0))
                  }
        # insert the record in dynamo - we use an update
        dyn_expression = "SET %s" % ", ".join(["#{name}=:{name}".format(name=name) for name in fields.keys()])
        dyn_expression_attribute_names = {"#%s" % k: k for k in fields.keys()}
        dyn_expression_attribute_values = {":%s" % k: v for k, v in fields.items()}
        dynamo.meta.client.update_item(
            TableName=self.dynamo_swams_table,
            Key={'transferManifestId': transferManifestId},
            UpdateExpression=dyn_expression,
            ExpressionAttributeNames=dyn_expression_attribute_names,
            ExpressionAttributeValues=dyn_expression_attribute_values,
        )
        self.logger.info(f"ManifestGenerator-transferManifestId={transferManifestId} record placed into dynamodb")
        # Now generate the cloudwatch event
        self.__generate_swams_cloudwatch_event(transfer_manifest_id=transferManifestId)
        return transferManifestId

    def describe_transfer_manifest(self, transfer_manifest_id=None, mapping_id=None):
        dynamo = generalutils.get_dynamodb_client(generalutils.get_session(region=self.aws_region))
        table = dynamo.Table(self.dynamo_swams_table)
        try:
            response = table.get_item(
                Key={
                    'transferManifestId': transfer_manifest_id
                }
            )
        except ClientError as e:
            self.logger(f"ManifestGenerator-{e.response['Error']['Message']}")
            return None
        item = response.get('Item', None)
        if item:
            if item['mappingId'] != mapping_id.casefold():
                self.logger.error(f"ManifestGenerator-describe_transfer_manifest "
                                  f"provided mapping id does not match for requested transferManifestId.")
                item = None
        return item

    def get_transfer_manifest(self, transfer_manifest_id=None, mapping_id=None):
        if transfer_manifest_id is None or mapping_id is None:
            return None
        dynamo = generalutils.get_dynamodb_client(generalutils.get_session(region=self.aws_region))
        table = dynamo.Table(self.dynamo_swams_table)
        try:
            response = table.get_item(
                Key={
                    'transferManifestId': transfer_manifest_id
                }
            )
        except ClientError as e:
            self.logger(f"ManifestGenerator-{e.response['Error']['Message']}")
            return None
        item = response.get('Item', None)
        if item is None:
            return None
        if item['status'] != self.external_status_state[1]:
            self.logger.error(f"ManifestGenerator-get_transfer_manifest manifest is not ready.")
            return None
        if item['mappingId'] != mapping_id.casefold():
            self.logger.error(f"ManifestGenerator-get_transfer_manifest "
                              f"provided mapping id does not match for requested transferManifestId.")
            return None
        # format the response for the returning of the manifest by reading it
        manifest_data = generalutils.read_data_from_s3(bucket=self.manifest_bucket,
                                                       key=f"{transfer_manifest_id}.xml",
                                                       region=self.aws_region, logger=self.logger)
        if manifest_data is None:
            self.logger.error(f"ManifestGenerator-get_transfer_manifest unable to read manifest.")
            return None
        generated_manifest_response = {'transferManifestId': transfer_manifest_id,
                                       'manifestBody': manifest_data.decode()}
        self.logger.info(f"ManifestGenerator-get_transfer_manifest returning "
                         f"response of {generated_manifest_response}")
        return generated_manifest_response
    """
    End of the public available methods
    """

    def __setup_start_threads(self):
        # startup 2 threads for the SWAMS service (class)
        # 1 - to check for new swams requests
        self.swams_process_thread = threading.Thread(target=self.__generate_manifest_processor, args=())
        self.swams_process_thread.start()
        # 2 - to clean up old swams artifacts
        self.swams_cleanup_thread = threading.Thread(target=self.__cleanup_manifests_processor, args=())
        self.swams_cleanup_thread.start()

    def __generate_manifest_processor(self):
        loop_cycle_time = 60 * 0.5
        self.logger.info(f"ManifestGenerator-__generate_manifest_processor thread running.")
        while self.threads_keep_running:
            self.logger.info(f"ManifestGenerator-__generate_manifest_processor "
                             f"thread checking for manifest requests to process.")
            # check the database and see if any entries need processing
            # if so grab an entry and call the lambda controller and then build the xml manifest
            # write the data to the manifest bucket
            # update the db entry to indicate completed
            # generate the event
            # do again
            manifest_to_process = self.__get_next_manifest_request_to_process_and_mark()
            if manifest_to_process is None:
                self._wait_until(timeout_seconds=loop_cycle_time)
                continue
            # process the found manifest
            transferManifestId = manifest_to_process['transferManifestId']
            hash_algorithm = manifest_to_process['hashType']
            if hash_algorithm not in ['sha256', 'sha384', 'sha512']:
                self.logger.error(f"ManifestGenerator-__generate_manifest_processor "
                                  f"got bad hash algorithm value - defaulting to sha256")
                hash_algorithm = 'sha256'

            s3_object = f"s3://{manifest_to_process['payloadS3Bucket']}/{manifest_to_process['payloadS3Key']}"
            template_data_json = json.loads(manifest_to_process['templateData'])
            s3_payload_size = self.__get_size_s3_object(manifest_to_process['payloadS3Bucket'],
                                                        manifest_to_process['payloadS3Key'])
            if s3_payload_size == -1:
                self.logger.info(f"ManifestGenerator-__generate_manifest_processor "
                                 f"unable to get S3 object size.")
                self._mark_manifest_generation_failure(manifest_info=manifest_to_process)
                continue

            if s3_payload_size < 30 * 1024 * 1024 * 1024:  # less than 30GB
                blocksize_for_hashes = 128
            elif s3_payload_size < 60 * 1024 * 1024 * 1024:  # 30GB - 60GB
                blocksize_for_hashes = 256
            else:
                blocksize_for_hashes = 512
            try:
                self.logger.info(f"ManifestGenerator-__generate_manifest_processor "
                                 f"calling manifest_generator.generate_manifest.")
                manifest_generator = DiodeCDSManifest.AwsCdsManifest(aws_region=self.aws_region,
                                                                     logger=self.logger)
                self.logger.info(
                    f"ManifestGenerator-__generate_manifest_processor manifest generator object instantiated.")
                rc, manifest = manifest_generator.generate_manifest(payload_name=s3_object,
                                                                    template_data_as_json=template_data_json,
                                                                    templ_xsd=template_xsd_name_and_path,
                                                                    blksize=blocksize_for_hashes,
                                                                    hash_algorithm=hash_algorithm.upper(),
                                                                    lambda_function_name=self.lambda_controller_arn,
                                                                    multi_thread=True)
            except ValueError as ve:
                self.logger.error(f"ManifestGenerator-__generate_manifest_processor "
                                  f"manifest {transferManifestId}.xml generation failure exception={ve}.")
                self._mark_manifest_generation_failure(manifest_info=manifest_to_process)
                continue
            except Exception as ex:
                self.logger.error(f"ManifestGenerator-__generate_manifest_processor "
                                  f"manifest {transferManifestId}.xml generation failure exception={ex}.")
                continue

            if rc == 0 and manifest is not None:
                # write the manifest to the S3 manifest bucket
                if generalutils.write_data_to_s3(bucket=self.manifest_bucket,
                                                 key=f"{transferManifestId}.xml",
                                                 data=manifest,
                                                 region=self.aws_region,
                                                 logger=self.logger):
                    self.logger.info(f"ManifestGenerator-__generate_manifest_processor "
                                     f"manifest {transferManifestId}.xml "
                                     f"written to manifest bucket {self.manifest_bucket}.")
                    # update the record in the database showing success and generate event
                    self._mark_manifest_generation_success(manifest_info=manifest_to_process)
                else:
                    self._mark_manifest_generation_failure(manifest_info=manifest_to_process)
            else:
                self._mark_manifest_generation_failure(manifest_info=manifest_to_process)
            # now wait a bit and see if any more manifests to process from dynamodb
            # self._wait_until(timeout_seconds=loop_cycle_time)
            # moved wait up at top of loop - reach here if done processing so go see if
            # more to process.

    def __get_next_manifest_request_to_process_and_mark(self):
        # find records that have not been processed and update one to say processing
        # and return that record - if none updated or found return None
        while True:
            try:
                dynamo = generalutils.get_dynamodb_client(generalutils.get_session(region=self.aws_region))
                response = dynamo.meta.client.query(
                    TableName=self.dynamo_swams_table,
                    IndexName=internal_status_index,
                    Select='ALL_ATTRIBUTES',
                    Limit=1,
                    ConsistentRead=False,
                    KeyConditionExpression='internalStatus=:internalstatusvalue',
                    ExpressionAttributeValues={":internalstatusvalue": f"{self.internal_status_state[0]}"}
                )
                if len(response['Items']) == 0:
                    self.logger.info(f"ManifestGenerator-__get_next_manifest_request_to_process_and_mark "
                                     f"no unprocessed manifest requests found.")
                    return None
                else:
                    # The following gets a record in a state of NOT_STARTED and sets it to STARTED
                    # while also setting the field expiryTime to 10 minutes from now
                    # This way if the record stays in the started state more than 10 minutes it will
                    # get reset to NOT_STARTED so it can be processed and not lost by the watcher thread.
                    # The assumption here is no manifest should take longer than 10 minutes to process
                    # given the lambda hash computation functions.
                    manifest_to_process = response['Items'][0]
                    self.logger.debug(f"{manifest_to_process}")
                    transferManifestId = manifest_to_process['transferManifestId']
                    fields = {'newInternalStatus': self.internal_status_state[1],
                              'oldInternalStatus': self.internal_status_state[0],
                              'newInternalStatusUpdated':
                                  generalutils.get_current_time_in_diode_format(),
                              'setExpiryTime':
                                  generalutils.get_current_time_in_diode_format() +
                                  maximum_time_in_seconds_to_let_manifest_sit_in_processing}
                    dyn_expression = f"SET internalStatus=:newInternalStatus, " \
                                     f"internalStatusUpdated=:newInternalStatusUpdated, " \
                                     f"expiryTime=:setExpiryTime"
                    dyn_expression_attribute_values = {":%s" % k: v for k, v in fields.items()}
                    dynamodb = boto3.session.Session(region_name=self.aws_region).resource('dynamodb')
                    try:
                        _ = dynamodb.meta.client.update_item(
                            TableName=self.dynamo_swams_table,
                            Key={'transferManifestId': transferManifestId},
                            UpdateExpression=dyn_expression,
                            ExpressionAttributeValues=dyn_expression_attribute_values,
                            ConditionExpression="internalStatus = :oldInternalStatus",
                            ReturnValues='UPDATED_NEW'
                        )
                    except ClientError as ce:
                        self.logger.error(f"ManifestGenerator-__get_next_manifest_request_to_process_and_mark "
                                          f"exception {ce}")
                        # some other thread may have picked this up between our query and update
                        # check for another record.
                        continue

                    # update read record to represent what is in dynamodb after update-saved re-reading record
                    manifest_to_process['internalStatus'] = self.internal_status_state[1]
                    manifest_to_process['internalStatusUpdated'] = fields['newInternalStatusUpdated']
                    manifest_to_process['expiryTime'] = fields['setExpiryTime']
                    # update the record to show it being worked
                    self.logger.info(f"ManifestGenerator-__get_next_manifest_request_to_process_and_mark "
                                     f"unprocessed manifest request "
                                     f"found: {manifest_to_process}.")
                    return manifest_to_process
            except ClientError as ce:
                self.logger.error(f"ManifestGenerator-__get_next_manifest_request_to_process_and_mark "
                                  f"error accessing dynamodb for manifest check exception {ce}.")
                return None

    def __get_size_of_queued_manifest_requests_in_bytes(self, mapping_id=None):
        self.logger.debug(f"ManifestGenerator-__get_size_of_queued_manifest_requests_in_bytes "
                          f"checking size of total pending requests for mapping_id {mapping_id}")
        dynamo = generalutils.get_dynamodb_client(generalutils.get_session(region=self.aws_region))
        total_bytes_unprocessed = 0
        last_evaluated_key = None
        keepIterating = True
        while keepIterating:
            try:
                if last_evaluated_key is None:
                    response = dynamo.meta.client.query(
                        TableName=self.dynamo_swams_table,
                        IndexName=external_status_index,
                        Select='SPECIFIC_ATTRIBUTES',
                        ProjectionExpression='payloadSizeBytes',
                        ConsistentRead=False,
                        KeyConditionExpression='#S=:statusvalue '
                                               'and mappingId=:mappingID',
                        ExpressionAttributeValues={":statusvalue": f"{self.external_status_state[0]}",
                                                   ":mappingID": f"{mapping_id}"},
                        ExpressionAttributeNames={'#S': "status"},
                    )
                else:
                    response = dynamo.meta.client.query(
                        TableName=self.dynamo_swams_table,
                        IndexName=internal_status_index,
                        ExclusiveStartKey=last_evaluated_key,
                        Select='SPECIFIC_ATTRIBUTES',
                        ProjectionExpression='payloadSizeBytes',
                        ConsistentRead=False,
                        KeyConditionExpression='#S=:statusvalue '
                                               'and mappingId=:mappingID',
                        ExpressionAttributeValues={":statusvalue": f"{self.external_status_state[0]}",
                                                   ":mappingID": f"{mapping_id}"},
                        ExpressionAttributeNames={'#S': "status"},
                    )
            except Exception as ex:
                self.logger.error(f"ManifestGenerator-__get_size_of_queued_manifest_requests_in_bytes {ex}")
                break
            if len(response['Items']) == 0:
                self.logger.info(f"ManifestGenerator-__get_size_of_queued_manifest_requests_in_bytes "
                                 f"no unprocessed manifest requests found.")
                break
            else:
                for size_bytes in response['Items']:
                    self.logger.debug(f"ManifestGenerator-__get_size_of_queued_manifest_requests_in_bytes "
                                      f"dynamodb response {size_bytes}")
                    total_bytes_unprocessed = total_bytes_unprocessed + size_bytes['payloadSizeBytes']
                last_evaluated_key = response.get('LastEvaluatedKey', None)
                if last_evaluated_key is None:
                    keepIterating = False
        self.logger.debug(f"ManifestGenerator-__get_size_of_queued_manifest_requests_in_bytes "
                          f"total unprocessed manifest file bytes={total_bytes_unprocessed}")
        return total_bytes_unprocessed

    def _mark_manifest_generation_success(self, manifest_info=None):
        # Update record in database and generate the event
        transferManifestId = manifest_info['transferManifestId']
        fields = {'newInternalStatus': self.internal_status_state[2],
                  'newInternalStatusUpdated':
                      generalutils.get_current_time_in_diode_format(),
                  'newStatus': self.external_status_state[1],
                  'newStatusReason':
                      'The manifest has been created and can be retrieved by calling GetTransferManifest.',
                  'newExpiryTime': generalutils.get_current_time_in_diode_format() + when_to_delete_manifest_in_seconds
                  }
        dyn_expression = f"SET internalStatus=:newInternalStatus, " \
                         f"internalStatusUpdated=:newInternalStatusUpdated, " \
                         f"#S=:newStatus, " \
                         f"statusReason=:newStatusReason, " \
                         f"expiryTime=:newExpiryTime"
        dyn_expression_attribute_values = {":%s" % k: v for k, v in fields.items()}
        dynamo = generalutils.get_dynamodb_client(generalutils.get_session(region=self.aws_region))
        try:
            _ = dynamo.meta.client.update_item(
                TableName=self.dynamo_swams_table,
                Key={'transferManifestId': transferManifestId},
                UpdateExpression=dyn_expression,
                ExpressionAttributeValues=dyn_expression_attribute_values,
                ExpressionAttributeNames={'#S': "status"},
                ReturnValues='UPDATED_NEW'
            )
            self.__generate_swams_cloudwatch_event(transfer_manifest_id=transferManifestId)
            self.logger.info(f"ManifestGenerator-manifest {transferManifestId} "
                             f"record updated in dynamodb to {self.external_status_state[1]}.")
        except ClientError as ce:
            self.logger.error(f"ManifestGenerator-{ce}")
        return

    def _mark_manifest_generation_failure(self, manifest_info=None):
        # TODO Need to determine what real SWAMS does in this situation and
        #  implement, update record in database and generate the event have
        #  been unable to cause this error in whitebox testing
        # Update record in database and generate the event
        transferManifestId = manifest_info['transferManifestId']
        fields = {'newInternalStatus': self.internal_status_state[2],
                  'newInternalStatusUpdated':
                      generalutils.get_current_time_in_diode_format(),
                  'newStatus': self.external_status_state[2],
                  'newStatusReason':
                      'The manifest could not be generated please retry.',
                  'newExpiryTime':
                      generalutils.get_current_time_in_diode_format() + when_to_delete_manifest_in_seconds}
        dyn_expression = f"SET internalStatus=:newInternalStatus, " \
                         f"internalStatusUpdated=:newInternalStatusUpdated, " \
                         f"#S=:newStatus, " \
                         f"statusReason=:newStatusReason, " \
                         f"expiryTime=:newExpiryTime"
        dyn_expression_attribute_values = {":%s" % k: v for k, v in fields.items()}
        dynamo = generalutils.get_dynamodb_client(generalutils.get_session(region=self.aws_region))
        try:
            _ = dynamo.meta.client.update_item(
                TableName=self.dynamo_swams_table,
                Key={'transferManifestId': transferManifestId},
                UpdateExpression=dyn_expression,
                ExpressionAttributeValues=dyn_expression_attribute_values,
                ExpressionAttributeNames={'#S': "status"},
                ReturnValues='UPDATED_NEW'
            )
            self.__generate_swams_cloudwatch_event(transfer_manifest_id=transferManifestId)
            self.logger.info(f"ManifestGenerator-manifest {transferManifestId} "
                             f"record updated in dynamodb to {self.external_status_state[2]}.")
        except ClientError as ce:
            self.logger.error(f"ManifestGenerator-{ce}")
        return

    def _wait_until(self, timeout_seconds: float):
        """
        This method will wait in small intervals and check the threads to exit
        variable and if it gets set it will exit quick.
        """
        end = time.time() + timeout_seconds
        while time.time() < end:
            if self.threads_keep_running:
                time.sleep(0.1)
            else:
                return

    def __cleanup_manifests_processor(self):
        # look for records in database that are set to STARTED and
        # expiryTime is < current time
        # (expiryTime is set to current time + maximum_time_in_seconds_to_let_manifest_sit_in_processing)
        # upon creation of the record to a PROCESSING state.
        #
        loop_cycle_time = 60 * 2
        self.logger.info(f"ManifestGenerator-__cleanup_manifests_processor thread started.")
        while self.threads_keep_running:
            # find records that have not been in processing for over a specific interval - means it was
            # somehow not able to be completed so reset to process it again.
            self.__cleanup_stuck_manifests_being_processed()
            self.__cleanup_expired_old_manifests()
            self._wait_until(timeout_seconds=loop_cycle_time)

    def __cleanup_stuck_manifests_being_processed(self):
        # look for records in database that are set to STARTED and
        # expiryTime is < current time
        # (expiryTime is set to current time + maximum_time_in_seconds_to_let_manifest_sit_in_processing)
        # upon creation of the record to a PROCESSING state.
        #
        dynamo = generalutils.get_dynamodb_client(generalutils.get_session(region=self.aws_region))
        num_found = 0
        while self.threads_keep_running:
            # find records that have not been in processing for over a specific interval - means it was
            # somehow not able to be completed so reset to process it again.
            try:
                self.logger.info(f"ManifestGenerator-__cleanup_stuck_manifests_being_processed "
                                 f"looking for old stuck {self.internal_status_state[1]} records.")
                response = dynamo.meta.client.query(
                    TableName=self.dynamo_swams_table,
                    IndexName=internal_status_index,
                    Select='ALL_ATTRIBUTES',
                    Limit=1,
                    ConsistentRead=False,
                    KeyConditionExpression='internalStatus=:internalstatusvalue and expiryTime<:currentTimeValue',
                    ExpressionAttributeValues={":internalstatusvalue": f"{self.internal_status_state[1]}",
                                               ":currentTimeValue": generalutils.get_current_time_in_diode_format()
                                               }
                )
                if len(response['Items']) == 0:
                    self.logger.info(f"ManifestGenerator-__cleanup_stuck_manifests_being_processed "
                                     f"no in progress records that are stuck found.")
                    break
                manifest_to_process = response['Items'][0]
                transferManifestId = manifest_to_process['transferManifestId']
                # reset this entry to reprocessed next time as it has been stuck for 10 minutes
                self.logger.debug(f"{manifest_to_process}")
                fields = {'newInternalStatus': self.internal_status_state[0],
                          'oldInternalStatus': self.internal_status_state[1],
                          'newInternalStatusUpdated': generalutils.get_current_time_in_diode_format(),
                          'resetExpiryTime': decimal.Decimal(float("%0.3f" % 0.0))}
                dyn_expression = f"SET internalStatus=:newInternalStatus, " \
                                 f"internalStatusUpdated=:newInternalStatusUpdated, " \
                                 f"expiryTime=:resetExpiryTime"
                dyn_expression_attribute_values = {":%s" % k: v for k, v in fields.items()}
                try:
                    _ = dynamo.meta.client.update_item(
                        TableName=self.dynamo_swams_table,
                        Key={'transferManifestId': transferManifestId},
                        UpdateExpression=dyn_expression,
                        ExpressionAttributeValues=dyn_expression_attribute_values,
                        ConditionExpression="internalStatus = :oldInternalStatus",
                        ReturnValues='UPDATED_NEW'
                    )
                    num_found = num_found + 1
                    self.logger.info(f"ManifestGenerator-__cleanup_stuck_manifests_being_processed "
                                     f"reset transferManifestId {transferManifestId} to NOT_STARTED")
                except ClientError as ce:
                    self.logger.error(f"ManifestGenerator-{ce}")
                    # some other thread may have picked this up between our query and update
                    # check for another record.
                    continue
            except ClientError as ce:
                self.logger.error(f"ManifestGenerator-__cleanup_stuck_manifests_being_processed "
                                  f"error accessing dynamodb for manifest check exception {ce}.")
        return num_found

    def __cleanup_expired_old_manifests(self):
        # look for finished manifests that are over 14 days old and delete from s3 and database
        #
        dynamo = generalutils.get_dynamodb_client(generalutils.get_session(region=self.aws_region))
        num_found = 0
        while self.threads_keep_running:
            # find records that have not been in processing for over a specific interval - means it was
            # somehow not able to be completed so reset to process it again.
            try:
                self.logger.info(f"ManifestGenerator-__cleanup_expired_old_manifests "
                                 f"looking for old manifests to cleanup.")
                response = dynamo.meta.client.query(
                    TableName=self.dynamo_swams_table,
                    IndexName=internal_status_index,
                    Select='ALL_ATTRIBUTES',
                    Limit=1,
                    ConsistentRead=False,
                    KeyConditionExpression='internalStatus=:internalstatusvalue and expiryTime<:currentTimeValue',
                    ExpressionAttributeValues={":internalstatusvalue": f"{self.internal_status_state[2]}",
                                               ":currentTimeValue": generalutils.get_current_time_in_diode_format()
                                               }
                )
                if len(response['Items']) == 0:
                    self.logger.info(f"ManifestGenerator-__cleanup_expired_old_manifests "
                                     f"no finished manifest records that are old found.")
                    break
                manifest_to_process = response['Items'][0]
                transferManifestId = manifest_to_process['transferManifestId']
                if manifest_to_process['internalStatus'] == self.internal_status_state[2]:
                    # expired manifest in system so delete it from S3 and dynamodb database
                    self.logger.error(f"ManifestGenerator-__cleanup_expired_old_manifests "
                                      f"deleting a manifest that is older than 14 days.")
                    manifest_s3_name = f"{transferManifestId}.xml"
                    try:
                        _ = dynamo.meta.client.delete_item(
                            TableName=self.dynamo_swams_table,
                            Key={'transferManifestId': transferManifestId},
                        )
                        self.logger.info(f"ManifestGenerator-__cleanup_expired_old_manifests "
                                         f"deleted transferManifestId {transferManifestId} due to 14 day expiry")
                        num_found = num_found + 1
                    except ClientError as ce:
                        self.logger.error(f"ManifestGenerator-__cleanup_expired_old_manifests exception {ce}")
                        # some other thread may have picked this up between our query and update
                        # check for another record.
                    s3 = generalutils.get_s3_client(generalutils.get_session(region=self.aws_region))
                    if generalutils.delete_s3_object(s3, self.manifest_bucket,
                                                     manifest_s3_name, logger=self.logger):
                        self.logger.info(f"ManifestGenerator-__cleanup_expired_old_manifests "
                                         f"deleted manifest from manifest bucket - {manifest_s3_name}.")
                    else:
                        self.logger.error(f"ManifestGenerator-__cleanup_expired_old_manifests "
                                          f"unable to delete manifest object "
                                          f"from manifest bucket - {manifest_s3_name}.")
            except ClientError as ce:
                self.logger.error(f"ManifestGenerator-__cleanup_expired_old_manifests "
                                  f"error accessing dynamodb for manifest check exception {ce}.")
                return None
        return num_found

    def __generate_swams_cloudwatch_event(self, transfer_manifest_id=None):
        """
        {
          "version": "0",
          "id": "6b5ae6cf-9781-3366-8d0d-7ce5b05acfc4",
          "detail-type": "Diode Manifest Creation Status",
          "source": "aws.diode",
          "account": "555555555555",
          "time": "2021-01-25T18:45:21Z",
          "region": "us-east-1",
          "resources": [],
          "detail": {
            "transferManifestId": "fbac6108-aa5d-48f1-aa68-80ab7a3089a3",
            "mappingId": "00000000-0000-0000-0000-000000000000",
            "status": "CREATE_COMPLETE",
            "message": "The manifest has been generated and can be retrieved by calling GetTransferManifest.",
            "payloadS3Key": "the-path/to/my-original-file.txt",
            "payloadS3Bucket": "my.unique.bucket.name"
          }
        }
        :return: nothing
        """
        if transfer_manifest_id is None:
            self.logger.error(f"ManifestGenerator-__generate_swams_cloudwatch_event "
                              f"passed None for transferManifestId")
            return
        # go read the dynamo record for all the details
        dynamo = generalutils.get_dynamodb_client(generalutils.get_session(region=self.aws_region))
        table = dynamo.Table(self.dynamo_swams_table)
        try:
            response = table.get_item(
                Key={
                    'transferManifestId': transfer_manifest_id},
                ConsistentRead=True
            )
        except ClientError as e:
            self.logger.error(e.response['Error']['Message'])
            return
        item = response['Item']
        self.logger.debug(json.dumps(item, indent=4, cls=generalutils.DecimalEncoder))
        cloudwatch_events = generalutils.get_cloudwatch_events_client(generalutils.get_session(region=self.aws_region))
        json_detail = {'transferManifestId': item['transferManifestId'],
                       'mappingId': item['mappingId'],
                       'status': item['status'],
                       'message': item['statusReason'],
                       'payloadS3Key': item['payloadS3Key'],
                       'payloadS3Bucket': item['payloadS3Bucket']
                       }
        response = cloudwatch_events.put_events(Entries=[
            {
                'Detail': json.dumps(json_detail, cls=generalutils.DecimalEncoder),
                'DetailType': 'Diode Manifest Creation Status',
                'Resources': [],
                'Source': self.cloudwatch_events_source
            }]
        )
        self.logger.debug(f"completed generate cloudwatch event response={response}")
        return

    def __get_size_s3_object(self, bucket, object_name):
        s3resource = generalutils.get_s3_client(generalutils.get_session(region=self.aws_region))
        try:
            response = s3resource.meta.client.head_object(Bucket=bucket, Key=object_name)
        except Exception as e:
            self.logger.info(f"Could not find object with name {object_name}, "
                             f"may not exist - exception {e}.")
            return -1
        return_code = response['ResponseMetadata']['HTTPStatusCode']
        if return_code == 200:
            return response['ContentLength']
        else:
            self.logger.info(f"response on size query of S3 object is {return_code}")
            return -1


"""
Request after submission
{
    "transferManifestId": "04e66280-d486-4372-9139-5d54e68ca891",
    "mappingId": "346c575a-27b2-441a-a6e2-fb055d00f9f0",
    "status": "CREATE_IN_PROGRESS",
    "statusReason": "The manifest is currently being created.",
    "payloadS3Bucket": "tonydahb-largefiles",
    "payloadS3Key": "3GB.txt",
    "manifestFormat": "TDF"
}

Request when complete
{
    "transferManifestId": "04e66280-d486-4372-9139-5d54e68ca891",
    "mappingId": "346c575a-27b2-441a-a6e2-fb055d00f9f0",
    "status": "CREATE_COMPLETE",
    "statusReason": "The manifest has been created and can be retrieved by calling GetTransferManifest.",
    "payloadS3Bucket": "tonydahb-largefiles",
    "payloadS3Key": "3GB.txt",
    "manifestFormat": "TDF"
}




"""
